<?php
use App\Http\Controllers\Admin\AdsController;
use App\Http\Controllers\Admin\AuditController;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\FoldersController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\Admin\SignedTokensController;
use App\Http\Controllers\Admin\UsersController;
use App\Http\Controllers\Admin\VideoController;
use App\Http\Controllers\EmbedController;
use Illuminate\Support\Facades\Route;

// تسجيل الدخول
Route::get('/admin/login',  [AuthController::class, 'showLogin'])->name('admin.login');
Route::post('/admin/login', [AuthController::class, 'login'])->name('admin.login.post');
Route::get('/admin/logout', [AuthController::class, 'logout'])->name('admin.logout');

// لوحة التحكم
Route::prefix('admin')->name('admin.')->middleware('admin.auth')->group(function () {

    // ── الرئيسية (كل الأدوار) ──────────────────────────────────────────────
    Route::get('/',          [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index']);

    // ── الفيديوهات: قراءة فقط (viewer+) ────────────────────────────────────
    Route::get('/videos',                    [VideoController::class, 'index'])->name('videos.index');
    Route::get('/videos/{video}/status',     [VideoController::class, 'status'])->name('videos.status');
    Route::get('/videos/{video}/analytics',  [VideoController::class, 'analytics'])->name('videos.analytics');

    // ── الفيديوهات: كتابة (editor+) ─────────────────────────────────────────
    Route::middleware('role:admin,editor')->group(function () {
        Route::get('/videos/create',            [VideoController::class, 'create'])->name('videos.create');
        Route::post('/videos',                  [VideoController::class, 'store'])->name('videos.store');
        Route::post('/videos/bulk',             [VideoController::class, 'bulk'])->name('videos.bulk');
        Route::get('/videos/{video}/edit',      [VideoController::class, 'edit'])->name('videos.edit');
        Route::put('/videos/{video}',           [VideoController::class, 'update'])->name('videos.update');
        Route::delete('/videos/{video}',        [VideoController::class, 'destroy'])->name('videos.destroy');
        Route::get('/videos/{video}/reprocess', [VideoController::class, 'reprocess'])->name('videos.reprocess');
        Route::delete('/subtitles/{subtitle}',  [VideoController::class, 'deleteSubtitle'])->name('subtitles.delete');
    });

    // ── المجلدات (editor+) ────────────────────────────────────────────────────
    Route::middleware('role:admin,editor')->group(function () {
        Route::get('/folders',              [FoldersController::class, 'index'])->name('folders.index');
        Route::post('/folders',             [FoldersController::class, 'store'])->name('folders.store');
        Route::put('/folders/{folder}',     [FoldersController::class, 'update'])->name('folders.update');
        Route::delete('/folders/{folder}',  [FoldersController::class, 'destroy'])->name('folders.destroy');
    });

    // ── إعلانات (admin فقط) ──────────────────────────────────────────────────
    Route::resource('ads', AdsController::class)
         ->except(['show'])
         ->middleware('role:admin');

    // ── روابط موقّعة (admin فقط) ─────────────────────────────────────────────
    Route::middleware('role:admin')->group(function () {
        Route::get('/signed-tokens',           [SignedTokensController::class, 'index'])->name('signed-tokens.index');
        Route::post('/signed-tokens/{token}/revoke', [SignedTokensController::class, 'revoke'])->name('signed-tokens.revoke');
        Route::post('/signed-tokens/ttl',      [SignedTokensController::class, 'updateDefaultTtl'])->name('signed-tokens.ttl');
    });

    // ── إدارة المستخدمين (admin فقط) ─────────────────────────────────────────
    Route::resource('users', UsersController::class)
         ->except(['show'])
         ->middleware('role:admin');

    // ── سجل التدقيق (admin فقط) ──────────────────────────────────────────────
    Route::get('/audit', [AuditController::class, 'index'])->name('audit.index')
         ->middleware('role:admin');

    // ── الإعدادات العامة (admin فقط) ─────────────────────────────────────────
    Route::middleware('role:admin')->group(function () {
        Route::get('/settings',  [SettingsController::class, 'index'])->name('settings.index');
        Route::post('/settings', [SettingsController::class, 'update'])->name('settings.update');
    });
});

// مشغل التضمين (طبّق ميدل وير لإزالة رؤوس تمنع التضمين)
Route::middleware('allow.embed')->group(function () {
    Route::get('/embed/{slug}',                       [EmbedController::class, 'player'])->name('embed.player');
    Route::get('/embed/movie/{tmdb_id}',              [EmbedController::class, 'movieByTmdb'])->name('embed.movie');
    Route::get('/embed/tv/{tmdb_id}/{season}/{episode}', [EmbedController::class, 'tvByTmdb'])->name('embed.tv');
    Route::get('/embed/{slug}/thumbnail.jpg',         [EmbedController::class, 'thumbnail'])->name('embed.thumbnail');
    Route::get('/embed/{slug}/m3u8',                  [EmbedController::class, 'm3u8'])->name('embed.m3u8');
    Route::get('/embed/{slug}/{quality}/index.m3u8',  [EmbedController::class, 'variantPlaylist'])->name('embed.variant');
    Route::get('/embed/{slug}/{quality}/{segment}.ts', [EmbedController::class, 'segment']);
});

// الصفحة الرئيسية
Route::get('/', fn() => redirect()->route('admin.dashboard'));

// API routes
Route::post('/api/adblock-detected', [App\Http\Controllers\Api\AdBlockController::class, 'detected']);
