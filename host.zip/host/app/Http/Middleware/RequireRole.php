<?php
namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Http\Request;

class RequireRole
{
    public function handle(Request $request, Closure $next, string ...$roles): mixed
    {
        // AdminAuth runs first and attaches the DB-loaded user to request attributes.
        // Reading role from the live User object prevents stale-session privilege retention
        // when an admin demotes a currently-logged-in user.
        $user = $request->attributes->get('admin_user');

        if ($user instanceof User) {
            $userRole = $user->role;
        } else {
            // Safety net: AdminAuth should always attach admin_user, but if it
            // hasn't (e.g. middleware order changed), reload from DB directly.
            $userId = session('admin_user_id');
            if (!$userId) {
                abort(403, 'ليس لديك صلاحية للوصول إلى هذه الصفحة.');
            }
            $dbUser = User::find($userId);
            if (!$dbUser || !$dbUser->is_active) {
                abort(403, 'الحساب غير مفعّل.');
            }
            $userRole = $dbUser->role;
        }

        if (!$userRole || !in_array($userRole, $roles)) {
            abort(403, 'ليس لديك صلاحية للوصول إلى هذه الصفحة.');
        }

        return $next($request);
    }
}
