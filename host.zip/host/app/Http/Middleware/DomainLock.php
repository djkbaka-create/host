<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class DomainLock
{
    public function handle(Request $request, Closure $next)
    {
        $allowedDomain = config('streaming.allowed_domain');
        if (!$allowedDomain) return $next($request);

        $referer = $request->headers->get('referer', '');
        $origin  = $request->headers->get('origin', '');
        $check   = $referer ?: $origin;

        if (empty($check)) {
            // السماح بالوصول المباشر (للاختبار)
            return $next($request);
        }

        $host = parse_url($check, PHP_URL_HOST) ?? '';
        $host = preg_replace('/^www\./', '', strtolower($host));
        $allowed = preg_replace('/^www\./', '', strtolower($allowedDomain));

        if ($host !== $allowed) {
            return response()->view('embed.blocked', [], 403);
        }

        return $next($request);
    }
}
