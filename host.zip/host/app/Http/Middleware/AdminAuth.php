<?php
namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Http\Request;

class AdminAuth
{
    public function handle(Request $request, Closure $next)
    {
        $userId = session('admin_user_id');

        if (!$userId) {
            return redirect()->route('admin.login');
        }

        $user = User::find($userId);

        if (!$user || !$user->is_active) {
            session()->forget(['admin_user_id', 'admin_user_name', 'admin_user_role']);
            return redirect()->route('admin.login')
                ->withErrors(['password' => 'تم تعطيل حسابك أو انتهت الجلسة.']);
        }

        $request->attributes->set('admin_user', $user);

        return $next($request);
    }
}
