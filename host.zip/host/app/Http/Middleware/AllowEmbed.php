<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AllowEmbed
{
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);

        // Remove headers that block embedding in an iframe
        if (method_exists($response, 'headers')) {
            $response->headers->remove('X-Frame-Options');
            $response->headers->remove('Content-Security-Policy');
        }

        return $response;
    }
}
