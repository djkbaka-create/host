<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\GlobalSetting;
use App\Models\SignedToken;
use Illuminate\Http\Request;

class SignedTokensController extends Controller
{
    public function index()
    {
        $tokens = SignedToken::where('expires_at', '>', now())
                             ->where('revoked', false)
                             ->latest('created_at')
                             ->paginate(40);

        $defaultTtl = GlobalSetting::get('signed_url_default_ttl', 120);

        return view('admin.signed-tokens.index', compact('tokens', 'defaultTtl'));
    }

    public function revoke(SignedToken $token)
    {
        $token->update(['revoked' => true]);
        AuditLog::record('token.revoke', 'signed_token', $token->id, ['slug' => $token->slug]);
        return back()->with('success', 'تم إلغاء التوكن بنجاح.');
    }

    public function updateDefaultTtl(Request $request)
    {
        $request->validate(['ttl' => 'required|integer|min:5|max:10080']);
        GlobalSetting::set('signed_url_default_ttl', $request->ttl);
        AuditLog::record('settings.signed_ttl', null, null, ['ttl_minutes' => $request->ttl]);
        return back()->with('success', 'تم تحديث مدة الصلاحية الافتراضية.');
    }
}
