<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\GlobalSetting;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index()
    {
        $defaultTtl = (int) GlobalSetting::get('signed_url_default_ttl', 120);

        $rawDomains     = GlobalSetting::get('allowed_domains');
        $domains        = $rawDomains ? (json_decode($rawDomains, true) ?: []) : [];
        $allowedDomains = implode("\n", $domains);

        $antiAdblockEnabled = (bool) GlobalSetting::get('anti_adblock_enabled', false);
        $antiAdblockMode    = GlobalSetting::get('anti_adblock_mode', 'warning'); // 'warning' or 'block'
        $adblockDetectionCount = (int) GlobalSetting::get('adblock_detection_count_today', 0);

        return view('admin.settings.index', compact('defaultTtl', 'allowedDomains', 'antiAdblockEnabled', 'antiAdblockMode', 'adblockDetectionCount'));
    }

    public function update(Request $request)
    {
        $request->validate([
            'signed_url_default_ttl' => 'required|integer|min:5|max:10080',
            'allowed_domains'        => 'nullable|string',
            'anti_adblock_enabled'   => 'nullable|boolean',
            'anti_adblock_mode'      => 'nullable|in:warning,block',
        ]);

        GlobalSetting::set('signed_url_default_ttl', (int) $request->signed_url_default_ttl);

        $domains = array_values(array_filter(
            array_map('trim', preg_split('/[\n\r,]+/', $request->allowed_domains ?? ''))
        ));
        GlobalSetting::set('allowed_domains', empty($domains) ? null : json_encode($domains, JSON_UNESCAPED_UNICODE));

        GlobalSetting::set('anti_adblock_enabled', (bool) $request->input('anti_adblock_enabled', false));
        GlobalSetting::set('anti_adblock_mode', $request->input('anti_adblock_mode', 'warning'));

        AuditLog::record('settings.update', null, null, [
            'ttl_minutes'           => (int) $request->signed_url_default_ttl,
            'domains_count'         => count($domains),
            'anti_adblock_enabled'  => (bool) $request->input('anti_adblock_enabled', false),
            'anti_adblock_mode'     => $request->input('anti_adblock_mode', 'warning'),
        ]);

        return back()->with('success', 'تم حفظ الإعدادات بنجاح.');
    }
}
