<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Jobs\FetchRemoteVideoJob;
use App\Jobs\ProcessVideoJob;
use App\Models\Folder;
use App\Models\Subtitle;
use App\Models\Tag;
use App\Models\Video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class VideoController extends Controller
{
    public function index(Request $request) {
        $query = Video::with(['folder', 'tags'])
            ->when($request->q,      fn($q, $s) => $q->where('title', 'like', "%$s%"))
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->when($request->folder, function ($q, $fid) {
                return $fid === 'none'
                    ? $q->whereNull('folder_id')
                    : $q->where('folder_id', $fid);
            })
            ->when($request->tag, function ($q, $tag) {
                return $q->whereHas('tags', fn($tq) => $tq->where('slug', $tag));
            })
            ->when($request->date_from, fn($q, $d) => $q->whereDate('created_at', '>=', $d))
            ->when($request->date_to,   fn($q, $d) => $q->whereDate('created_at', '<=', $d))
            ->when($request->dur_min,   fn($q, $d) => $q->where('duration', '>=', (int)$d * 60))
            ->when($request->dur_max,   fn($q, $d) => $q->where('duration', '<=', (int)$d * 60));

        $videos  = $query->latest()->paginate(20)->withQueryString();
        $folders = Folder::orderBy('name')->get();
        $tags    = Tag::withCount('videos')->orderByDesc('videos_count')->limit(50)->get();

        return view('admin.videos.index', compact('videos', 'folders', 'tags'));
    }

    public function create() {
        $folders = Folder::orderBy('name')->get();
        $tags    = Tag::orderBy('name')->get();
        return view('admin.videos.create', compact('folders', 'tags'));
    }

    public function store(Request $request) {
        $this->normalizeVideoInput($request);

        $request->validate([
            'title'           => 'required|string|max:255',
            'description'     => 'nullable|string|max:5000',
            'source_type'     => 'required|in:upload,remote',
            'file'            => 'required_if:source_type,upload|file|mimes:mp4,mkv,avi,mov,webm|max:2097152',
            'source_url'      => 'required_if:source_type,remote|nullable|url',
            'tmdb_id'         => 'nullable|numeric|min:1',
            'folder_id'       => 'nullable|numeric|exists:folders,id',
            'signed_url_ttl'  => 'nullable|numeric|min:0',
        ]);

        $video = Video::create([
            'title'           => $request->title,
            'description'     => $request->description,
            'source_type'     => $request->source_type,
            'source_url'      => $request->source_url,
            'tmdb_id'         => $request->tmdb_id,
            'signed_url_ttl'  => $request->signed_url_ttl ?: 0,
            'folder_id'       => $request->folder_id,
            'status'          => 'pending',
        ]);

        if ($request->filled('tags_input')) {
            $video->syncTagsFromString($request->tags_input);
        }

        \App\Models\AuditLog::record('video.create', 'video', $video->id, ['title' => $video->title]);

        if ($request->source_type === 'upload' && $request->hasFile('file')) {
            $file     = $request->file('file');
            $filename = "{$video->slug}.{$file->extension()}";
            $destDir  = storage_path("app/videos/uploads");
            @mkdir($destDir, 0755, true);
            $fullPath = "{$destDir}/{$filename}";
            $file->move($destDir, $filename);
            $path = "videos/uploads/{$filename}";
            $video->update(['original_file' => $path, 'file_size' => filesize($fullPath)]);
            ProcessVideoJob::dispatch($video, $fullPath);
        } else {
            FetchRemoteVideoJob::dispatch($video);
        }

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'success'  => true,
                'video_id' => $video->id,
                'slug'     => $video->slug,
                'redirect' => route('admin.videos.index'),
            ]);
        }

        return redirect()->route('admin.videos.index')
            ->with('success', 'تمت إضافة الفيديو وبدأت المعالجة في الخلفية!');
    }

    public function status(Video $video) {
        return response()->json([
            'id'       => $video->id,
            'status'   => $video->status,
            'ready'    => $video->isReady(),
            'duration' => $video->formatted_duration,
            'size'     => $video->formatted_size,
        ]);
    }

    public function edit(Video $video) {
        $folders = Folder::orderBy('name')->get();
        $video->load('tags');
        return view('admin.videos.edit', compact('video', 'folders'));
    }

    public function update(Request $request, Video $video) {
        $this->normalizeVideoInput($request);

        $request->validate([
            'title'           => 'required|string|max:255',
            'description'     => 'nullable|string|max:5000',
            'tmdb_id'         => 'nullable|numeric|min:1',
            'folder_id'       => 'nullable|numeric|exists:folders,id',
            'signed_url_ttl'  => 'nullable|numeric|min:0',
        ]);

        $video->update([
            'title'           => $request->title,
            'description'     => $request->description,
            'tmdb_id'         => $request->tmdb_id,
            'signed_url_ttl'  => $request->signed_url_ttl !== null ? (int)$request->signed_url_ttl : 0,
            'folder_id'       => $request->folder_id,
        ]);

        if ($request->has('tags_input')) {
            $video->syncTagsFromString($request->tags_input ?? '');
        }

        \App\Models\AuditLog::record('video.update', 'video', $video->id, ['title' => $video->title]);

        if ($request->hasFile('subtitles')) {
            foreach ($request->file('subtitles') as $i => $subFile) {
                $path = $subFile->storeAs("videos/{$video->slug}/subs", $subFile->getClientOriginalName());
                Subtitle::create([
                    'video_id'   => $video->id,
                    'label'      => $request->subtitle_labels[$i] ?? $subFile->getClientOriginalName(),
                    'language'   => $request->subtitle_langs[$i] ?? 'ar',
                    'file_path'  => $path,
                    'is_default' => $i === 0,
                ]);
            }
        }

        return back()->with('success', 'تم تحديث الفيديو!');
    }

    protected function normalizeVideoInput(Request $request): void {
        foreach (['description', 'tmdb_id', 'folder_id', 'signed_url_ttl', 'source_url'] as $field) {
            if ($request->has($field)) {
                $val = $request->input($field);
                if ($val === '' || $val === null || trim((string)$val) === '') {
                    $request->merge([$field => null]);
                }
            }
        }
    }

    public function destroy(Video $video) {
        \App\Models\AuditLog::record('video.delete', 'video', $video->id, ['title' => $video->title]);
        $dir = storage_path("app/videos/{$video->slug}");
        if (is_dir($dir)) exec("rm -rf " . escapeshellarg($dir));
        $video->delete();
        return back()->with('success', 'تم حذف الفيديو.');
    }

    /**
     * Bulk actions: move to folder / add tag / delete.
     * POST /admin/videos/bulk
     * Body: action (move_folder|add_tag|delete), ids[] (array of video IDs),
     *       folder_id (for move_folder), tag_name (for add_tag)
     */
    public function bulk(Request $request) {
        $request->validate([
            'action'    => 'required|in:move_folder,add_tag,delete',
            'ids'       => 'required|array|min:1',
            'ids.*'     => 'integer',
            'folder_id' => 'nullable|exists:folders,id',
        ]);

        $ids    = $request->ids;
        $videos = Video::whereIn('id', $ids)->get();

        switch ($request->action) {
            case 'move_folder':
                $folderId = $request->folder_id ?: null;
                Video::whereIn('id', $ids)->update(['folder_id' => $folderId]);
                $folderName = $folderId
                    ? (Folder::find($folderId)?->name ?? 'مجلد')
                    : 'بدون مجلد';
                $msg = "تم نقل {$videos->count()} فيديو إلى: {$folderName}";
                break;

            case 'add_tag':
                $tagName = trim($request->tag_name ?? '');
                if (!$tagName) {
                    return back()->with('error', 'يرجى إدخال اسم التاج.');
                }
                $tag = Tag::findOrCreateByName($tagName);
                foreach ($videos as $v) {
                    $v->tags()->syncWithoutDetaching([$tag->id]);
                }
                $msg = "تمت إضافة تاج «{$tag->name}» لـ {$videos->count()} فيديو.";
                break;

            case 'delete':
                foreach ($videos as $v) {
                    \App\Models\AuditLog::record('video.delete', 'video', $v->id, ['title' => $v->title]);
                    $dir = storage_path("app/videos/{$v->slug}");
                    if (is_dir($dir)) exec("rm -rf " . escapeshellarg($dir));
                    $v->delete();
                }
                $msg = "تم حذف {$videos->count()} فيديو.";
                break;

            default:
                $msg = '';
        }

        return back()->with('success', $msg);
    }

    public function deleteSubtitle(Subtitle $subtitle) {
        @unlink(storage_path("app/{$subtitle->file_path}"));
        $subtitle->delete();
        return back()->with('success', 'تم حذف الترجمة.');
    }

    public function reprocess(Video $video) {
        $path = storage_path("app/{$video->original_file}");
        if (!file_exists($path)) {
            return back()->with('error', 'الملف الأصلي غير موجود — يرجى رفع الفيديو مجدداً.');
        }
        $video->update(['status' => 'pending']);
        ProcessVideoJob::dispatch($video, $path);
        return back()->with('success', 'تم إعادة جدولة المعالجة.');
    }

    public function analytics(Video $video) {
        $days  = 30;
        $since = now()->subDays($days - 1)->toDateString();

        $rows = DB::table('video_views')
            ->where('video_id', $video->id)
            ->where('date', '>=', $since)
            ->selectRaw('date, COUNT(*) as cnt')
            ->groupBy('date')
            ->orderBy('date')
            ->pluck('cnt', 'date');

        $labels = [];
        $data   = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $date     = now()->subDays($i)->toDateString();
            $labels[] = now()->subDays($i)->format('d/m');
            $data[]   = (int)($rows[$date] ?? 0);
        }

        $topReferrers = DB::table('video_views')
            ->where('video_id', $video->id)
            ->where('date', '>=', $since)
            ->whereNotNull('referer')
            ->where('referer', '!=', '')
            ->selectRaw('referer, COUNT(*) as cnt')
            ->groupBy('referer')
            ->orderByDesc('cnt')
            ->limit(10)
            ->get()
            ->map(fn($r) => ['referer' => $r->referer, 'count' => $r->cnt]);

        return response()->json([
            'labels'        => $labels,
            'data'          => $data,
            'total_views'   => $video->views,
            'period_views'  => array_sum($data),
            'top_referrers' => $topReferrers,
        ]);
    }
}
