<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (session('admin_user_id')) return redirect()->route('admin.dashboard');
        return view('admin.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        $user = User::where('username', $request->username)
                    ->orWhere('email', $request->username)
                    ->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return back()->withErrors(['password' => 'بيانات الدخول غير صحيحة']);
        }

        if (!$user->is_active) {
            return back()->withErrors(['password' => 'حسابك معطّل. تواصل مع المدير.']);
        }

        session([
            'admin_user_id'   => $user->id,
            'admin_user_name' => $user->username ?: $user->name,
            'admin_user_role' => $user->role,
        ]);

        AuditLog::record('auth.login', 'user', $user->id);

        return redirect()->route('admin.dashboard');
    }

    public function logout()
    {
        AuditLog::record('auth.logout', 'user', session('admin_user_id'));
        session()->forget(['admin_user_id', 'admin_user_name', 'admin_user_role']);
        return redirect()->route('admin.login');
    }
}
