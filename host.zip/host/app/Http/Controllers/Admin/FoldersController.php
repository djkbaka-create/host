<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Folder;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class FoldersController extends Controller
{
    public function index()
    {
        $folders = Folder::withCount('videos')->orderBy('name')->get();
        return view('admin.folders.index', compact('folders'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100|unique:folders,name',
        ]);

        $folder = Folder::create([
            'name'        => $request->name,
            'description' => $request->description,
        ]);
        \App\Models\AuditLog::record('folder.create', 'folder', $folder->id, ['name' => $folder->name]);

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'id'   => $folder->id,
                'name' => $folder->name,
                'slug' => $folder->slug,
            ]);
        }

        return back()->with('success', 'تم إنشاء المجلد.');
    }

    public function update(Request $request, Folder $folder)
    {
        $request->validate([
            'name' => "required|string|max:100|unique:folders,name,{$folder->id}",
        ]);

        $folder->update([
            'name'        => $request->name,
            'description' => $request->description,
        ]);
        \App\Models\AuditLog::record('folder.update', 'folder', $folder->id, ['name' => $folder->name]);

        return back()->with('success', 'تم تحديث المجلد.');
    }

    public function destroy(Folder $folder)
    {
        \App\Models\AuditLog::record('folder.delete', 'folder', $folder->id, ['name' => $folder->name]);
        $folder->delete();
        return back()->with('success', 'تم حذف المجلد (الفيديوهات بقيت بدون مجلد).');
    }
}
