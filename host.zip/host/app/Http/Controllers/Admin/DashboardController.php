<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Video;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index() {
        $stats = [
            'total'      => Video::count(),
            'ready'      => Video::where('status', 'ready')->count(),
            'processing' => Video::where('status', 'processing')->count(),
            'failed'     => Video::where('status', 'failed')->count(),
            'views'      => Video::sum('views'),
        ];
        $recent = Video::latest()->limit(8)->get();

        // مشاهدات آخر 30 يوم للـ chart
        $days = 30;
        $rows = DB::table('video_views')
            ->where('date', '>=', now()->subDays($days - 1)->toDateString())
            ->selectRaw('date, COUNT(*) as total')
            ->groupBy('date')
            ->orderBy('date')
            ->pluck('total', 'date');

        $chartLabels = [];
        $chartData   = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $date          = now()->subDays($i)->toDateString();
            $chartLabels[] = now()->subDays($i)->format('d/m');
            $chartData[]   = (int)($rows[$date] ?? 0);
        }

        return view('admin.dashboard', compact('stats', 'recent', 'chartLabels', 'chartData'));
    }
}
