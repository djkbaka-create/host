<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UsersController extends Controller
{
    public function index()
    {
        $users = User::latest()->get();
        return view('admin.users.index', compact('users'));
    }

    public function create()
    {
        return view('admin.users.form', ['user' => null]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'username' => 'required|string|max:64|unique:users,username',
            'name'     => 'required|string|max:128',
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
            'role'     => 'required|in:admin,editor,viewer',
        ]);

        $user = User::create([
            'username'  => $request->username,
            'name'      => $request->name,
            'email'     => $request->email,
            'password'  => Hash::make($request->password),
            'role'      => $request->role,
            'is_active' => $request->boolean('is_active', true),
        ]);

        AuditLog::record('user.create', 'user', $user->id, ['username' => $user->username, 'role' => $user->role]);

        return redirect()->route('admin.users.index')->with('success', 'تم إنشاء المستخدم بنجاح.');
    }

    public function edit(User $user)
    {
        return view('admin.users.form', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $request->validate([
            'username' => ['required','string','max:64', Rule::unique('users','username')->ignore($user->id)],
            'name'     => 'required|string|max:128',
            'email'    => ['required','email', Rule::unique('users','email')->ignore($user->id)],
            'password' => 'nullable|string|min:8|confirmed',
            'role'     => 'required|in:admin,editor,viewer',
        ]);

        $currentAdminId = session('admin_user_id');

        if ($user->id === (int)$currentAdminId && $request->role !== 'admin') {
            return back()->withErrors(['role' => 'لا يمكنك تغيير دورك الخاص.']);
        }

        if ($user->id === (int)$currentAdminId && !$request->boolean('is_active')) {
            return back()->withErrors(['is_active' => 'لا يمكنك تعطيل حسابك الحالي.']);
        }

        $data = [
            'username'  => $request->username,
            'name'      => $request->name,
            'email'     => $request->email,
            'role'      => $request->role,
            'is_active' => $request->boolean('is_active'),
        ];

        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->password);
        }

        $user->update($data);

        AuditLog::record('user.update', 'user', $user->id, ['username' => $user->username, 'role' => $user->role]);

        return redirect()->route('admin.users.index')->with('success', 'تم تحديث المستخدم.');
    }

    public function destroy(User $user)
    {
        $currentAdminId = session('admin_user_id');
        if ($user->id === (int)$currentAdminId) {
            return back()->withErrors(['general' => 'لا يمكنك حذف حسابك الحالي.']);
        }

        $adminCount = User::where('role', 'admin')->where('is_active', true)->count();
        if ($user->role === 'admin' && $adminCount <= 1) {
            return back()->withErrors(['general' => 'يجب أن يبقى مدير واحد على الأقل.']);
        }

        AuditLog::record('user.delete', 'user', $user->id, ['username' => $user->username]);
        $user->delete();

        return redirect()->route('admin.users.index')->with('success', 'تم حذف المستخدم.');
    }
}
