<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdConfig;
use Illuminate\Http\Request;

class AdsController extends Controller
{
    public function index()
    {
        $global  = AdConfig::where('is_global', true)->first();
        $configs = AdConfig::where('is_global', false)->latest()->get();
        return view('admin.ads.index', compact('global', 'configs'));
    }

    public function create()
    {
        return view('admin.ads.form', [
            'config'       => null,
            'videos'       => \App\Models\Video::orderByDesc('id')->get(['id', 'title', 'slug']),
            'assignedIds'  => [],
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validated($request);
        $ad   = AdConfig::create($data);
        $this->syncVideos($ad, $request);
        return redirect()->route('admin.ads.index')->with('success', 'تم إنشاء إعداد الإعلانات.');
    }

    public function edit(AdConfig $ad)
    {
        return view('admin.ads.form', [
            'config'      => $ad,
            'videos'      => \App\Models\Video::orderByDesc('id')->get(['id', 'title', 'slug']),
            'assignedIds' => $ad->videos()->pluck('id')->all(),
        ]);
    }

    public function update(Request $request, AdConfig $ad)
    {
        $data = $this->validated($request, $ad->is_global);
        $ad->update($data);
        $this->syncVideos($ad, $request);
        return redirect()->route('admin.ads.index')->with('success', 'تم تحديث إعداد الإعلانات.');
    }

    public function destroy(AdConfig $ad)
    {
        if ($ad->is_global) {
            return back()->with('error', 'لا يمكن حذف الإعداد العام.');
        }
        // detach videos using this config
        $ad->videos()->update(['ad_config_id' => null]);
        $ad->delete();
        return back()->with('success', 'تم حذف الإعداد.');
    }

    protected function syncVideos(AdConfig $ad, Request $request): void
    {
        if ($ad->is_global) {
            return;
        }
        $ids = collect($request->input('video_ids', []))
            ->map(fn ($i) => (int) $i)
            ->filter()
            ->all();

        // Assign selected videos to this config
        if (!empty($ids)) {
            \App\Models\Video::whereIn('id', $ids)->update(['ad_config_id' => $ad->id]);
        }
        // Detach videos previously on this config but no longer selected
        \App\Models\Video::where('ad_config_id', $ad->id)
            ->whereNotIn('id', $ids ?: [0])
            ->update(['ad_config_id' => null]);
    }

    protected function validated(Request $request, bool $isGlobal = false): array
    {
        $request->validate([
            'name'             => 'required|string|max:255',
            'vast_url'         => 'nullable|url|max:500',
            'popunder_script'  => 'nullable|string',
            'popunder_delay'   => 'integer|min:0|max:300',
            'ad_timer_seconds' => 'integer|min:0|max:120',
            'video_ids'        => 'nullable|array',
            'video_ids.*'      => 'integer|exists:videos,id',
        ]);

        return [
            'name'              => $request->name,
            'vast_url'          => $request->vast_url ?: null,
            'popunder_script'   => $request->popunder_script ?: null,
            'popunder_on_play'  => $request->boolean('popunder_on_play'),
            'popunder_on_seek'  => $request->boolean('popunder_on_seek'),
            'popunder_delay'    => (int)$request->popunder_delay,
            'ad_timer_seconds'  => (int)$request->ad_timer_seconds,
            'is_global'         => $isGlobal,
            'is_active'         => $request->boolean('is_active', true),
        ];
    }
}
