<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\GlobalSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AdBlockController extends Controller
{
    public function detected(Request $request)
    {
        Log::info('ADBLOCK_DETECTED', [
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'timestamp' => now()->toIso8601String(),
        ]);

        // Increment today's count
        $today = now()->toDateString();
        $key = "adblock_detection_count_{$today}";
        $count = (int) GlobalSetting::get($key, 0);
        GlobalSetting::set($key, $count + 1);

        // Also keep 'adblock_detection_count_today' for display
        GlobalSetting::set('adblock_detection_count_today', $count + 1);

        return response()->json(['ok' => true]);
    }
}
