<?php
namespace App\Http\Controllers;

use App\Models\GlobalSetting;
use App\Models\SignedToken;
use App\Models\Video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class EmbedController extends Controller
{
    // ─── Public embed player ────────────────────────────────────────────────

    public function player(Request $request, string $slug)
    {
        $video = Video::where('slug', $slug)->where('status', 'ready')->firstOrFail();

        return $this->renderLocalPlayer($request, $video);
    }

    public function movieByTmdb(Request $request, int $tmdbId)
    {
        Log::info('TMDB_LOOKUP_MOVIE_HIT');

        $video = Video::where('tmdb_id', $tmdbId)->where('status', 'ready')->first();

        // Temporary log: record TMDB lookup & result
        Log::info('TMDB_LOOKUP_MOVIE', [
            'tmdb_id' => $tmdbId,
            'found'   => (bool) $video,
            'video_id'=> $video?->id ?? null,
            'slug'    => $video?->slug ?? null,
        ]);

        if (!$video) {
            return $this->fallbackOrNotFound($request, "movie/{$tmdbId}");
        }

        return $this->renderLocalPlayer($request, $video);
    }

    public function tvByTmdb(Request $request, int $tmdbId, int $season, int $episode)
    {
        Log::info('TMDB_LOOKUP_TV_HIT');

        $video = Video::where('tmdb_id', $tmdbId)->where('status', 'ready')->first();

        // Temporary log: record TMDB lookup & result
        Log::info('TMDB_LOOKUP_TV', [
            'tmdb_id' => $tmdbId,
            'season'  => $season,
            'episode' => $episode,
            'found'   => (bool) $video,
            'video_id'=> $video?->id ?? null,
            'slug'    => $video?->slug ?? null,
        ]);

        if (!$video) {
            return $this->fallbackOrNotFound($request, "tv/{$tmdbId}/{$season}/{$episode}");
        }

        return $this->renderLocalPlayer($request, $video);
    }

    public function thumbnail(Request $request, string $slug)
    {
        $video = Video::where('slug', $slug)->where('status', 'ready')->firstOrFail();
        if (!$video->thumbnail) {
            abort(404);
        }

        if ($video->storage_disk && $video->storage_disk !== 'local') {
            return redirect(Storage::disk($video->storage_disk)->url($video->thumbnail));
        }

        $filePath = storage_path("app/{$video->thumbnail}");
        if (!file_exists($filePath)) {
            abort(404);
        }

        return response()->file($filePath, [
            'Content-Type' => 'image/jpeg',
            'Cache-Control' => 'public, max-age=86400',
        ]);
    }
    // ─── HLS endpoints ──────────────────────────────────────────────────────

    /**
     * Master playlist — validates signed token, rewrites variant playlist
     * URIs to include signed params so the player can request them.
     */
    public function m3u8(Request $request, string $slug)
    {
        $video = Video::where('slug', $slug)->where('status', 'ready')->firstOrFail();

        [$expires, $nonce, $token] = $this->extractToken($request);
        $this->verifyToken($slug, $expires, $nonce, $token);

        $filePath = storage_path("app/{$video->hls_path}");
        if (!file_exists($filePath)) abort(404, 'HLS file not found');

        $content = file_get_contents($filePath);

        // Rewrite relative variant-playlist URIs → absolute signed URLs
        $content = preg_replace_callback(
            '/^([^#\s].+\.m3u8)$/m',
            function ($matches) use ($slug, $expires, $nonce, $token) {
                $quality = explode('/', $matches[1])[0];
                return route('embed.variant', compact('slug', 'quality'))
                    . "?expires={$expires}&nonce={$nonce}&token={$token}";
            },
            $content
        );

        return response($content, 200)
            ->header('Content-Type', 'application/vnd.apple.mpegurl')
            ->header('Access-Control-Allow-Origin', '*');
    }

    /**
     * Variant playlist — validates signed token, rewrites segment URIs to
     * include signed params so the player can request each .ts file.
     */
    public function variantPlaylist(Request $request, string $slug, string $quality)
    {
        $video = Video::where('slug', $slug)->where('status', 'ready')->firstOrFail();

        [$expires, $nonce, $token] = $this->extractToken($request);
        $this->verifyToken($slug, $expires, $nonce, $token);

        $filePath = storage_path("app/videos/{$slug}/{$quality}/index.m3u8");
        if (!file_exists($filePath)) abort(404);

        $content = file_get_contents($filePath);

        // Rewrite relative .ts segment URIs → absolute signed URLs
        $content = preg_replace_callback(
            '/^([^#\s].+\.ts)$/m',
            function ($matches) use ($slug, $quality, $expires, $nonce, $token) {
                $seg = pathinfo($matches[1], PATHINFO_FILENAME);
                return url("/embed/{$slug}/{$quality}/{$seg}.ts")
                    . "?expires={$expires}&nonce={$nonce}&token={$token}";
            },
            $content
        );

        return response($content, 200)
            ->header('Content-Type', 'application/vnd.apple.mpegurl')
            ->header('Access-Control-Allow-Origin', '*');
    }

    /**
     * .ts segment — validates signed token before serving the media chunk.
     */
    public function segment(Request $request, string $slug, string $quality, string $segment)
    {
        $video = Video::where('slug', $slug)->where('status', 'ready')->firstOrFail();

        [$expires, $nonce, $token] = $this->extractToken($request);
        $this->verifyToken($slug, $expires, $nonce, $token);

        $filePath = storage_path("app/videos/{$slug}/{$quality}/{$segment}.ts");
        if (!file_exists($filePath)) abort(404);

        return response()->file($filePath, [
            'Content-Type'                => 'video/mp2t',
            'Access-Control-Allow-Origin' => '*',
        ]);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    /**
     * Extract expires, nonce, and token from request query string.
     * Returns [int expires, string nonce, string token].
     */
    protected function extractToken(Request $request): array
    {
        return [
            (int)$request->get('expires', 0),
            (string)$request->get('nonce', ''),
            (string)$request->get('token', ''),
        ];
    }

    /**
     * Verify HMAC(slug . expires . nonce) and that the token is not revoked.
     * Including the nonce in the HMAC ensures every issued URL is unique even
     * when the same slug is requested multiple times within the same second,
     * which prevents duplicate-key collisions on signed_tokens.token_hash.
     */
    protected function verifyToken(string $slug, int $expires, string $nonce, string $token): void
    {
        $expected = hash_hmac('sha256', $slug . $expires . $nonce, config('streaming.sign_key'));

        if (time() > $expires || !hash_equals($expected, $token)) {
            abort(403, 'رابط منتهي الصلاحية');
        }

        if (!SignedToken::check($token)) {
            abort(403, 'تم إلغاء هذا الرابط');
        }
    }

    protected function domainAllowed(Request $request, Video $video): bool
    {
        // Allowed domains are managed only from the admin settings page.
        $rawDomains = GlobalSetting::get('allowed_domains');
        $domains    = $rawDomains ? (json_decode($rawDomains, true) ?: []) : [];

        if (empty($domains)) {
            return false;
        }

        // If "*" is in allowed domains, allow all sources
        foreach ($domains as $pattern) {
            $pattern = preg_replace('/^www\./', '', strtolower(trim($pattern)));
            if ($pattern === '*') {
                return true;
            }
        }

        // Otherwise, check Referer or Origin header
        $referer = $request->headers->get('referer', '');
        $origin  = $request->headers->get('origin', '');
        $check   = $referer ?: $origin;

        if (empty($check)) {
            return false;
        }

        $host = preg_replace('/^www\./', '', strtolower(parse_url($check, PHP_URL_HOST) ?? ''));
        if ($host === '') {
            return false;
        }

        foreach ($domains as $pattern) {
            $pattern = preg_replace('/^www\./', '', strtolower(trim($pattern)));
            if ($pattern === '') {
                continue;
            }
            if ($pattern === '*') {
                return true;
            }
            if (str_starts_with($pattern, '*.')) {
                $base = substr($pattern, 2);
                if ($host === $base || str_ends_with($host, '.' . $base)) {
                    return true;
                }
            } elseif ($host === $pattern) {
                return true;
            }
        }

        return false;
    }

    /**
     * Generate a signed HLS master URL for the given video.
     * A random nonce is included in the HMAC payload so every call produces a
     * unique token_hash — no duplicate-key collision on rapid concurrent requests.
     */
    protected function generateM3u8Url(Video $video, ?string $ip = null): string
    {
        $ttl     = $video->signed_url_ttl
            ?: (int)GlobalSetting::get('signed_url_default_ttl', 120);

        $expires = time() + ($ttl * 60);
        $nonce   = Str::random(16);
        $token   = hash_hmac('sha256', $video->slug . $expires . $nonce, config('streaming.sign_key'));

        SignedToken::issue($video->slug, $token, $expires, $ip);

        return route('embed.m3u8', ['slug' => $video->slug])
            . "?expires={$expires}&nonce={$nonce}&token={$token}";
    }

    protected function renderLocalPlayer(Request $request, Video $video)
    {
        if (!$this->domainAllowed($request, $video)) {
            return view('embed.blocked');
        }

        $video->increment('views');

        $ipHash  = hash('sha256', $request->ip() . config('app.key'));
        $referer = $request->headers->get('referer', null);
        if ($referer) {
            $host    = parse_url($referer, PHP_URL_HOST) ?: $referer;
            $referer = preg_replace('/^www\./', '', strtolower($host));
        }

        DB::table('video_views')->insert([
            'video_id'  => $video->id,
            'date'      => now()->toDateString(),
            'ip_hash'   => $ipHash,
            'referer'   => $referer,
            'viewed_at' => now(),
        ]);

        $m3u8Url  = $this->generateM3u8Url($video, $request->ip());
        $adConfig = $video->resolvedAdConfig();

        // Detect if the referer is a GitHub domain (Codespaces / github.dev) —
        // these hosts set frame-denying headers outside our control.
        $referer = $request->headers->get('referer', null);
        $shouldForceOpen = false;
        if ($referer) {
            $host = parse_url($referer, PHP_URL_HOST) ?: $referer;
            $host = preg_replace('/^www\./', '', strtolower($host));
            if (str_contains($host, 'github')) $shouldForceOpen = true;
        }

        // Get anti-adblock settings for the view
        $antiAdblockEnabled = (bool) GlobalSetting::get('anti_adblock_enabled', false);
        $antiAdblockMode    = GlobalSetting::get('anti_adblock_mode', 'warning');

        return view('embed.player', compact('video', 'm3u8Url', 'adConfig', 'shouldForceOpen', 'antiAdblockEnabled', 'antiAdblockMode'));
    }

    protected function fallbackOrNotFound(Request $request, string $path)
    {
        $backup = config('streaming.embed_fallback_url');
        if ($backup) {
            $url = rtrim($backup, '/') . '/' . ltrim($path, '/');
            return redirect()->away($url);
        }

        abort(404, 'Not Found');
    }
}
