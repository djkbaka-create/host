<?php
namespace App\Jobs;

use App\Models\Video;
use App\Services\FFmpegService;
use App\Services\StorageService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ProcessVideoJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 7200;
    public int $tries   = 2;

    public function __construct(public Video $video, public string $inputPath) {}

    public function handle(FFmpegService $ffmpeg, StorageService $cloudStorage): void
    {
        $this->video->update(['status' => 'processing']);

logger()->info('VIDEO PATH', [
    'path' => $this->inputPath,
    'exists' => file_exists($this->inputPath),
]);

        try {
            $success = $ffmpeg->process($this->video, $this->inputPath);

            if ($success && config('streaming.cloud_disk')) {
                $hlsLocalDir   = storage_path("app/videos/{$this->video->slug}");
                $hlsRemoteDir  = "videos/{$this->video->slug}";
                $disk          = config('streaming.cloud_disk');

                $cloudStorage->uploadDirectory($hlsLocalDir, $hlsRemoteDir, $disk);

               $this->video->update([
    'status'       => 'ready',
    'storage_disk' => $disk,
    'hls_path'     => "{$hlsRemoteDir}/master.m3u8",
    'thumbnail'    => "{$hlsRemoteDir}/thumbnail.jpg",
]);
            }

            // حذف الملف الأصلي لتوفير المساحة
            if (file_exists($this->inputPath)) {
                @unlink($this->inputPath);
            }

        } catch (\Throwable $e) {
            $this->video->update(['status' => 'failed']);
            logger()->error('ProcessVideoJob failed', [
                'video_id' => $this->video->id,
                'error'    => $e->getMessage(),
            ]);
            throw $e;
        }
    }
}
