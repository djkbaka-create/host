<?php
namespace App\Jobs;

use App\Models\Video;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class FetchRemoteVideoJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 3600;
    public int $tries   = 2;

    public function __construct(public Video $video) {}

    public function handle(): void
    {
        $this->video->update(['status' => 'processing']);

        $url       = $this->video->source_url;
        $tempPath  = storage_path("app/videos/temp_{$this->video->slug}.tmp");

        @mkdir(dirname($tempPath), 0755, true);

        // جلب الملف عبر curl لدعم الملفات الكبيرة
        $fp  = fopen($tempPath, 'w');
        $ch  = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 3600,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; VideoFetcher/1.0)',
            CURLOPT_SSL_VERIFYPEER => false,
        ]);

        $success = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if (!$success || $httpCode >= 400 || !file_exists($tempPath)) {
            $this->video->update(['status' => 'failed']);
            @unlink($tempPath);
            return;
        }

        $fileSize = filesize($tempPath);
        $this->video->update(['file_size' => $fileSize]);

        // إرسال للمعالجة بـ FFmpeg
        ProcessVideoJob::dispatch($this->video, $tempPath);
    }
}
