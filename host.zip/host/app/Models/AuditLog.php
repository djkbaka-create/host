<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Request;

class AuditLog extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id', 'action', 'target_type', 'target_id', 'ip', 'details',
    ];

    protected $casts = [
        'details'    => 'array',
        'created_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function record(
        string $action,
        ?string $targetType = null,
        mixed $targetId = null,
        array $details = []
    ): void {
        static::create([
            'user_id'     => session('admin_user_id'),
            'action'      => $action,
            'target_type' => $targetType,
            'target_id'   => $targetId,
            'ip'          => Request::ip(),
            'details'     => $details ?: null,
        ]);
    }
}
