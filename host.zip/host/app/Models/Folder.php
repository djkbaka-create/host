<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Folder extends Model
{
    protected $fillable = ['name', 'slug', 'description'];

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($folder) {
            if (empty($folder->slug)) {
                $base = Str::slug($folder->name);
                $slug = $base;
                $i    = 1;
                while (static::where('slug', $slug)->exists()) {
                    $slug = $base . '-' . $i++;
                }
                $folder->slug = $slug;
            }
        });
    }

    public function videos()
    {
        return $this->hasMany(Video::class);
    }
}
