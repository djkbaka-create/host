<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subtitle extends Model
{
    protected $fillable = ['video_id','label','language','file_path','is_default'];

    protected $casts = ['is_default' => 'boolean'];

    public function video() {
        return $this->belongsTo(Video::class);
    }
}
