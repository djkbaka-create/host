<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Video extends Model
{
    protected $fillable = [
        'title','description','slug','source_type','source_url','original_file',
        'tmdb_id',
        'status','duration','file_size','thumbnail','qualities','hls_path',
        'storage_disk','vast_url','popunder_script','allowed_domain','allowed_domains',
        'signed_url_ttl','views','ad_config_id','folder_id',
    ];

    protected $casts = [
        'qualities'       => 'array',
        'allowed_domains' => 'array',
        'signed_url_ttl'  => 'integer',
        'views'           => 'integer',
    ];

    public function setTmdbIdAttribute($value) {
        $this->attributes['tmdb_id'] = (empty($value) || trim((string)$value) === '') ? null : (int)$value;
    }

    public function setFolderIdAttribute($value) {
        $this->attributes['folder_id'] = (empty($value) || trim((string)$value) === '') ? null : (int)$value;
    }

    public function subtitles() {
        return $this->hasMany(Subtitle::class);
    }

    public function adConfig() {
        return $this->belongsTo(\App\Models\AdConfig::class, 'ad_config_id');
    }

    public function folder() {
        return $this->belongsTo(Folder::class);
    }

    public function tags() {
        return $this->belongsToMany(Tag::class, 'video_tag');
    }

    public function resolvedAdConfig(): ?\App\Models\AdConfig {
        if ($this->adConfig && $this->adConfig->is_active) {
            return $this->adConfig;
        }
        return \App\Models\AdConfig::where('is_global', true)->where('is_active', true)->first();
    }

    protected static function boot() {
        parent::boot();
        static::creating(function ($video) {
            if (empty($video->slug)) {
                $video->slug = Str::slug($video->title) . '-' . Str::random(6);
            }
        });
    }

    public function isReady(): bool {
        return $this->status === 'ready';
    }

    public function getFormattedDurationAttribute(): string {
        if (!$this->duration) return '—';
        return gmdate('H:i:s', $this->duration);
    }

    public function getFormattedSizeAttribute(): string {
        if (!$this->file_size) return '—';
        $units = ['B','KB','MB','GB','TB'];
        $i = floor(log($this->file_size, 1024));
        return round($this->file_size / pow(1024, $i), 2) . ' ' . $units[$i];
    }

    public function getThumbnailUrlAttribute(): ?string {
        return $this->thumbnail ? route('embed.thumbnail', ['slug' => $this->slug]) : null;
    }

    public function generateSignedM3u8Url(): string {
        $expires   = time() + ($this->signed_url_ttl * 60);
        $token     = hash_hmac('sha256', $this->slug . $expires, config('streaming.sign_key'));
        return route('embed.m3u8', ['slug' => $this->slug]) . "?expires={$expires}&token={$token}";
    }

    /**
     * Sync tags from a comma-separated string.
     */
    public function syncTagsFromString(string $raw): void
    {
        $names  = array_values(array_filter(array_map('trim', explode(',', $raw))));
        $tagIds = [];
        foreach ($names as $name) {
            if ($name === '') continue;
            $tag      = Tag::findOrCreateByName($name);
            $tagIds[] = $tag->id;
        }
        $this->tags()->sync($tagIds);
    }
}
