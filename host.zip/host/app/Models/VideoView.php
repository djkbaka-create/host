<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class VideoView extends Model
{
    public $timestamps = false;

    protected $fillable = ['video_id', 'date', 'ip_hash', 'referer'];

    protected $casts = ['date' => 'date', 'viewed_at' => 'datetime'];

    public function video(): BelongsTo
    {
        return $this->belongsTo(Video::class);
    }
}
