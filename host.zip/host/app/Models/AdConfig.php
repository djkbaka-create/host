<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdConfig extends Model
{
    protected $fillable = [
        'name', 'vast_url', 'popunder_script',
        'popunder_on_play', 'popunder_on_seek', 'popunder_delay',
        'ad_timer_seconds', 'is_global', 'is_active',
    ];

    protected $casts = [
        'popunder_on_play'  => 'boolean',
        'popunder_on_seek'  => 'boolean',
        'is_global'         => 'boolean',
        'is_active'         => 'boolean',
        'popunder_delay'    => 'integer',
        'ad_timer_seconds'  => 'integer',
    ];

    public function videos()
    {
        return $this->hasMany(Video::class, 'ad_config_id');
    }

    public static function globalConfig(): ?self
    {
        return static::where('is_global', true)->where('is_active', true)->first();
    }
}
