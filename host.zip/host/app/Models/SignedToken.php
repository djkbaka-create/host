<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SignedToken extends Model
{
    public $timestamps = false;

    protected $fillable = ['slug', 'token_hash', 'expires_at', 'revoked', 'ip'];

    protected $casts = [
        'expires_at' => 'datetime',
        'created_at' => 'datetime',
        'revoked'    => 'boolean',
    ];

    public function isValid(): bool
    {
        return !$this->revoked && $this->expires_at->isFuture();
    }

    public static function issue(string $slug, string $token, int $expires, ?string $ip = null): void
    {
        $hash = hash('sha256', $token);
        static::where('slug', $slug)
              ->where('expires_at', '<', now())
              ->delete();

        static::create([
            'slug'       => $slug,
            'token_hash' => $hash,
            'expires_at' => \Carbon\Carbon::createFromTimestamp($expires),
            'ip'         => $ip,
        ]);
    }

    public static function check(string $token): bool
    {
        $hash   = hash('sha256', $token);
        $record = static::where('token_hash', $hash)->first();
        return $record && $record->isValid();
    }
}
