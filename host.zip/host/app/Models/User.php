<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'username', 'name', 'email', 'password', 'role', 'is_active',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',
            'is_active'         => 'boolean',
        ];
    }

    public function isAdmin(): bool   { return $this->role === 'admin'; }
    public function isEditor(): bool  { return in_array($this->role, ['admin', 'editor']); }
    public function isViewer(): bool  { return in_array($this->role, ['admin', 'editor', 'viewer']); }

    public function getRoleLabelAttribute(): string
    {
        return match ($this->role) {
            'admin'  => 'مدير',
            'editor' => 'محرر',
            'viewer' => 'مشاهد',
            default  => $this->role,
        };
    }
}
