<?php
namespace App\Services;

use Illuminate\Support\Facades\Storage;

class StorageService
{
    public function uploadToCloud(string $localPath, string $remotePath, string $disk = 's3'): bool
    {
        try {
            $stream = fopen($localPath, 'r');
            Storage::disk($disk)->put($remotePath, $stream, 'public');
            if (is_resource($stream)) fclose($stream);
            return true;
        } catch (\Exception $e) {
            logger()->error('StorageService upload failed', ['error' => $e->getMessage()]);
            return false;
        }
    }

    public function uploadDirectory(string $localDir, string $remoteDir, string $disk = 's3'): bool
    {
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($localDir));
        foreach ($files as $file) {
            if ($file->isDir()) continue;
            $localFile  = $file->getPathname();
            $remoteFile = $remoteDir . '/' . ltrim(str_replace($localDir, '', $localFile), '/');
            if (!$this->uploadToCloud($localFile, $remoteFile, $disk)) return false;
        }
        return true;
    }

    public function getSignedUrl(string $path, int $minutes = 120, string $disk = 's3'): string
    {
        return Storage::disk($disk)->temporaryUrl($path, now()->addMinutes($minutes));
    }

    public function delete(string $path, string $disk = 's3'): bool
    {
        return Storage::disk($disk)->delete($path);
    }
}
