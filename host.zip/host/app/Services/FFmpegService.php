<?php
namespace App\Services;

use App\Models\Video;

class FFmpegService
{
    protected string $ffmpeg;
    protected string $ffprobe;

    public function __construct()
    {
        $this->ffmpeg = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' ? 'C:\\laragon\\bin\\ffmpeg.exe' : 'ffmpeg';
        $this->ffprobe = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' ? 'C:\\laragon\\bin\\ffprobe.exe' : 'ffprobe';
    }
    protected array $qualities = [
        '360p'  => ['width' => 640,  'height' => 360,  'bitrate' => '800k',  'audioBitrate' => '96k'],
        '480p'  => ['width' => 854,  'height' => 480,  'bitrate' => '1400k', 'audioBitrate' => '128k'],
        '720p'  => ['width' => 1280, 'height' => 720,  'bitrate' => '2800k', 'audioBitrate' => '128k'],
        '1080p' => ['width' => 1920, 'height' => 1080, 'bitrate' => '5000k', 'audioBitrate' => '192k'],
    ];

    public function process(Video $video, string $inputPath): bool
    {
        $outputDir = storage_path("app/videos/{$video->slug}");
        @mkdir($outputDir, 0755, true);

        // استخراج مدة الفيديو
        $duration = $this->getDuration($inputPath);
        if ($duration) {
            $video->update(['duration' => $duration]);
        }

        // توليد Thumbnail
        $thumbPath = "{$outputDir}/thumbnail.jpg";
        $this->generateThumbnail($inputPath, $thumbPath, $duration);

        // تحويل لكل جودة وتوليد HLS
        $masterPlaylist = "#EXTM3U\n#EXT-X-VERSION:3\n";
        $availableQualities = [];

        foreach ($this->qualities as $label => $params) {
            $qualityDir = "{$outputDir}/{$label}";
            @mkdir($qualityDir, 0755, true);

            $success = $this->transcodeToHLS($inputPath, $qualityDir, $params, $label);
            if ($success) {
                $availableQualities[] = $label;
                $bandwidth = (int) str_replace('k', '000', $params['bitrate']);
                $masterPlaylist .= "#EXT-X-STREAM-INF:BANDWIDTH={$bandwidth},RESOLUTION={$params['width']}x{$params['height']},NAME=\"{$label}\"\n";
                $masterPlaylist .= "{$label}/index.m3u8\n";
            }
        }

        if (empty($availableQualities)) {
            $video->update(['status' => 'failed']);
            return false;
        }

        // كتابة Master Playlist
        file_put_contents("{$outputDir}/master.m3u8", $masterPlaylist);

        $video->update([
            'status'    => 'ready',
            'hls_path'  => "videos/{$video->slug}/master.m3u8",
            'thumbnail' => "videos/{$video->slug}/thumbnail.jpg",
            'qualities' => $availableQualities,
        ]);

        return true;
    }

    protected function transcodeToHLS(string $input, string $outputDir, array $params, string $label): bool
    {
        $logFile = storage_path("logs/ffmpeg_{$label}.log");
        $cmd = sprintf(
            '%s -y -i %s '
            . '-vf "scale=%d:%d:force_original_aspect_ratio=decrease,pad=%d:%d:(ow-iw)/2:(oh-ih)/2:color=black,format=yuv420p,setsar=1" '
            . '-c:v libx264 -b:v %s -preset fast -profile:v main '
            . '-c:a aac -b:a %s -ar 48000 '
            . '-hls_time 6 -hls_playlist_type vod -hls_segment_filename "%s/seg_%%03d.ts" '
            . '%s/index.m3u8 2>%s',
            escapeshellarg($this->ffmpeg),
            escapeshellarg($input),
            $params['width'], $params['height'],
            $params['width'], $params['height'],
            $params['bitrate'],
            $params['audioBitrate'],
            $outputDir,
            $outputDir,
            escapeshellarg($logFile)
        );

        exec($cmd, $output, $returnCode);
        return $returnCode === 0;
    }

    protected function getDuration(string $inputPath): ?int
    {
        $cmd = sprintf(
            '%s -v quiet -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 %s 2>/dev/null',
            escapeshellarg($this->ffprobe),
            escapeshellarg($inputPath)
        );
        $result = shell_exec($cmd);
        return $result ? (int)trim($result) : null;
    }

    protected function generateThumbnail(string $inputPath, string $outputPath, ?int $duration): void
    {
        $seek = $duration ? min(10, (int)($duration * 0.1)) : 5;
        $cmd  = sprintf(
            '%s -ss %d -i %s -vframes 1 -q:v 2 %s 2>/dev/null',
            escapeshellarg($this->ffmpeg),
            $seek,
            escapeshellarg($inputPath),
            escapeshellarg($outputPath)
        );
        exec($cmd);
    }
}