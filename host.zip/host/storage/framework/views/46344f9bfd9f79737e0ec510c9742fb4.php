<?php $__env->startSection('title', 'إدارة الإعلانات'); ?>
<?php $__env->startSection('breadcrumb', 'StreamHost › إدارة الإعلانات'); ?>

<?php $__env->startSection('topbar_actions'); ?>
<a href="<?php echo e(route('admin.ads.create')); ?>" class="btn-primary btn-sm">
    <i class="fas fa-plus"></i> إعداد جديد
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .toggle-wrap { display:flex; align-items:center; gap:8px; }
    .tog { position:relative; width:36px; height:20px; }
    .tog input { opacity:0; width:0; height:0; }
    .tog-slider {
        position:absolute; inset:0; border-radius:20px;
        background:rgba(255,255,255,.1); transition:.2s;
        cursor:default;
    }
    .tog-slider:before {
        content:''; position:absolute; width:14px; height:14px;
        left:3px; top:3px; border-radius:50%; background:#475569;
        transition:.2s;
    }
    .tog input:checked + .tog-slider { background:#7c3aed; }
    .tog input:checked + .tog-slider:before { transform:translateX(16px); background:#fff; }
    .ads-card { border:1px solid rgba(255,255,255,.07); border-radius:12px; background:rgba(255,255,255,.025); overflow:hidden; }
    .ads-card-head { padding:14px 18px; display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,.055); }
    .ads-card-body { padding:16px 18px; }
    .detail-row { display:flex; align-items:flex-start; gap:10px; padding:7px 0; border-top:1px solid rgba(255,255,255,.04); }
    .detail-row:first-child { border-top:none; padding-top:0; }
    .detail-label { font-size:11px; color:#475569; min-width:130px; flex-shrink:0; padding-top:1px; }
    .detail-val { font-size:12.5px; color:#94a3b8; word-break:break-all; }
    .pill { display:inline-flex; align-items:center; gap:4px; padding:2px 9px; border-radius:99px; font-size:11px; font-weight:600; }
    .pill-on  { background:rgba(34,197,94,.12);  color:#4ade80; }
    .pill-off { background:rgba(100,116,139,.12); color:#475569; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- Global config card -->
<div style="margin-bottom:20px;">
    <div style="font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#334155;margin-bottom:10px;">
        <i class="fas fa-globe" style="margin-left:5px;color:#a78bfa;"></i>
        الإعداد العام (يُطبَّق على الفيديوهات التي لا تحمل إعداداً خاصاً)
    </div>

    <?php if($global): ?>
    <div class="ads-card">
        <div class="ads-card-head">
            <div style="display:flex;align-items:center;gap:9px;">
                <div style="width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,#7c3aed,#ec4899);display:flex;align-items:center;justify-content:center;">
                    <i class="fas fa-globe" style="color:#fff;font-size:13px;"></i>
                </div>
                <div>
                    <div style="font-size:13.5px;color:#e2e8f0;font-weight:600;"><?php echo e($global->name); ?></div>
                    <div style="font-size:10.5px;color:#475569;margin-top:1px;">الإعداد الافتراضي لجميع الفيديوهات</div>
                </div>
            </div>
            <a href="<?php echo e(route('admin.ads.edit', $global)); ?>"
               class="ibtn" style="background:rgba(139,92,246,.12);color:#a78bfa;text-decoration:none;" title="تعديل">
                <i class="fas fa-pen"></i>
            </a>
        </div>
        <div class="ads-card-body">
            <div class="detail-row">
                <span class="detail-label"><i class="fas fa-rectangle-ad" style="margin-left:5px;"></i>VAST URL</span>
                <span class="detail-val"><?php echo e($global->vast_url ?: '—'); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label"><i class="fas fa-arrow-up-right-from-square" style="margin-left:5px;"></i>Popunder</span>
                <span class="detail-val" style="display:flex;flex-wrap:wrap;gap:5px;">
                    <span class="pill <?php echo e($global->popunder_on_play ? 'pill-on' : 'pill-off'); ?>">
                        <i class="fas <?php echo e($global->popunder_on_play ? 'fa-check' : 'fa-xmark'); ?>"></i>
                        عند التشغيل
                    </span>
                    <span class="pill <?php echo e($global->popunder_on_seek ? 'pill-on' : 'pill-off'); ?>">
                        <i class="fas <?php echo e($global->popunder_on_seek ? 'fa-check' : 'fa-xmark'); ?>"></i>
                        عند التقديم
                    </span>
                    <?php if($global->popunder_delay > 0): ?>
                    <span class="pill" style="background:rgba(59,130,246,.12);color:#60a5fa;">
                        <i class="fas fa-clock"></i>
                        تأخير <?php echo e($global->popunder_delay); ?> ث
                    </span>
                    <?php endif; ?>
                    <?php if(!$global->popunder_script): ?>
                    <span class="pill pill-off">بدون سكريبت</span>
                    <?php endif; ?>
                </span>
            </div>
            <div class="detail-row">
                <span class="detail-label"><i class="fas fa-hourglass-half" style="margin-left:5px;"></i>Ad Timer</span>
                <span class="detail-val">
                    <?php if($global->ad_timer_seconds > 0): ?>
                    <span class="pill" style="background:rgba(234,179,8,.12);color:#facc15;">
                        <i class="fas fa-clock"></i>
                        <?php echo e($global->ad_timer_seconds); ?> ثانية قبل التشغيل
                    </span>
                    <?php else: ?>
                    <span style="color:#334155;">معطّل</span>
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Custom configs -->
<div>
    <div style="font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#334155;margin-bottom:10px;">
        <i class="fas fa-sliders" style="margin-left:5px;color:#60a5fa;"></i>
        إعدادات مخصصة للفيديوهات
    </div>

    <?php if($configs->isEmpty()): ?>
    <div class="card" style="padding:40px;text-align:center;color:#334155;">
        <i class="fas fa-rectangle-ad" style="font-size:2rem;display:block;margin-bottom:10px;opacity:.18;"></i>
        <p style="font-size:13.5px;color:#475569;margin-bottom:6px;">لا توجد إعدادات مخصصة بعد</p>
        <p style="font-size:12px;color:#334155;">أنشئ إعداداً مخصصاً لتطبيقه على فيديوهات بعينها</p>
    </div>
    <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:12px;">
        <?php $__currentLoopData = $configs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cfg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="ads-card">
            <div class="ads-card-head">
                <div style="display:flex;align-items:center;gap:9px;">
                    <div style="width:32px;height:32px;border-radius:8px;background:rgba(59,130,246,.15);display:flex;align-items:center;justify-content:center;">
                        <i class="fas fa-sliders" style="color:#60a5fa;font-size:12px;"></i>
                    </div>
                    <div>
                        <div style="font-size:13px;color:#e2e8f0;font-weight:600;"><?php echo e($cfg->name); ?></div>
                        <div style="font-size:10px;color:#475569;margin-top:1px;">
                            <?php echo e($cfg->videos()->count()); ?> فيديو
                            &nbsp;·&nbsp;
                            <span class="<?php echo e($cfg->is_active ? 'pill-on' : 'pill-off'); ?>" style="font-size:10px;">
                                <?php echo e($cfg->is_active ? 'نشط' : 'معطّل'); ?>

                            </span>
                        </div>
                    </div>
                </div>
                <div style="display:flex;gap:5px;">
                    <a href="<?php echo e(route('admin.ads.edit', $cfg)); ?>"
                       class="ibtn" style="background:rgba(139,92,246,.1);color:#a78bfa;text-decoration:none;">
                        <i class="fas fa-pen"></i>
                    </a>
                    <form method="POST" action="<?php echo e(route('admin.ads.destroy', $cfg)); ?>"
                          onsubmit="return confirm('حذف هذا الإعداد؟')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="ibtn" style="background:rgba(239,68,68,.1);color:#f87171;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
            <div class="ads-card-body" style="padding:12px 18px;">
                <div class="detail-row">
                    <span class="detail-label">VAST</span>
                    <span class="detail-val" style="font-size:11.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:180px;">
                        <?php echo e($cfg->vast_url ?: '—'); ?>

                    </span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Popunder</span>
                    <span style="display:flex;gap:4px;flex-wrap:wrap;">
                        <span class="pill <?php echo e($cfg->popunder_on_play ? 'pill-on' : 'pill-off'); ?>">تشغيل</span>
                        <span class="pill <?php echo e($cfg->popunder_on_seek ? 'pill-on' : 'pill-off'); ?>">تقديم</span>
                        <?php if($cfg->popunder_delay > 0): ?>
                        <span class="pill" style="background:rgba(59,130,246,.12);color:#60a5fa;"><?php echo e($cfg->popunder_delay); ?>ث</span>
                        <?php endif; ?>
                    </span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Ad Timer</span>
                    <span class="detail-val" style="font-size:12px;">
                        <?php echo e($cfg->ad_timer_seconds > 0 ? $cfg->ad_timer_seconds . ' ثانية' : 'معطّل'); ?>

                    </span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\StreamHost\resources\views/admin/ads/index.blade.php ENDPATH**/ ?>