<?php $__env->startSection('title', 'المجلدات'); ?>
<?php $__env->startSection('breadcrumb', 'StreamHost › المجلدات'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .folder-card {
        background: rgba(255,255,255,.03);
        border: 1px solid rgba(255,255,255,.07);
        border-radius: 12px;
        padding: 16px 18px;
        transition: border-color .15s, background .15s;
        display: flex;
        align-items: center;
        gap: 14px;
    }
    .folder-card:hover { border-color: rgba(124,58,237,.3); background: rgba(124,58,237,.04); }
    .folder-icon {
        width: 44px; height: 44px;
        background: rgba(124,58,237,.15);
        border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0;
    }
    .inp-sm { font-size: 12.5px; padding: 7px 10px; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('topbar_actions'); ?>
<button onclick="openCreateModal()" class="btn-primary btn-sm">
    <i class="fas fa-folder-plus"></i> مجلد جديد
</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="alert-ok mb-4"><i class="fas fa-check-circle" style="margin-left:6px;"></i><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if($folders->isEmpty()): ?>
<div class="card" style="text-align:center;padding:64px 0;">
    <i class="fas fa-folder-open" style="font-size:3rem;color:#334155;display:block;margin-bottom:14px;"></i>
    <p style="font-size:15px;color:#475569;margin-bottom:6px;">لا توجد مجلدات بعد</p>
    <button onclick="openCreateModal()" style="font-size:13px;color:#7c3aed;background:none;border:none;cursor:pointer;">أنشئ مجلدك الأول →</button>
</div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px;">
<?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="folder-card">
    <div class="folder-icon">
        <i class="fas fa-folder" style="color:#a78bfa;font-size:1.3rem;"></i>
    </div>
    <div style="flex:1;min-width:0;">
        <div style="font-size:14px;font-weight:600;color:#f1f5f9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
            <?php echo e($folder->name); ?>

        </div>
        <div style="font-size:11.5px;color:#475569;margin-top:2px;">
            <?php echo e($folder->videos_count); ?> فيديو
            <?php if($folder->description): ?>
            · <span style="color:#334155;"><?php echo e(Str::limit($folder->description, 40)); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div style="display:flex;gap:4px;flex-shrink:0;">
        <a href="<?php echo e(route('admin.videos.index', ['folder' => $folder->id])); ?>"
           class="ibtn" style="background:rgba(96,165,250,.1);color:#60a5fa;text-decoration:none;" title="عرض الفيديوهات">
            <i class="fas fa-film"></i>
        </a>
        <button onclick="openEditModal(<?php echo e($folder->id); ?>, '<?php echo e(addslashes($folder->name)); ?>', '<?php echo e(addslashes($folder->description ?? '')); ?>')"
                class="ibtn" style="background:rgba(139,92,246,.1);color:#a78bfa;" title="تعديل">
            <i class="fas fa-pen"></i>
        </button>
        <form method="POST" action="<?php echo e(route('admin.folders.destroy', $folder)); ?>"
              onsubmit="return confirm('حذف المجلد «<?php echo e(addslashes($folder->name)); ?>»؟ الفيديوهات لن تُحذف.')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="ibtn" style="background:rgba(239,68,68,.1);color:#f87171;" title="حذف">
                <i class="fas fa-trash"></i>
            </button>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<!-- Create Modal -->
<div id="createModal" style="display:none;position:fixed;inset:0;z-index:60;align-items:center;justify-content:center;background:rgba(0,0,0,.75);">
    <div class="card" style="width:100%;max-width:420px;margin:0 16px;padding:22px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
            <span style="font-size:14px;font-weight:600;"><i class="fas fa-folder-plus" style="color:#a78bfa;margin-left:7px;"></i> مجلد جديد</span>
            <button onclick="closeCreateModal()" class="ibtn" style="background:rgba(255,255,255,.05);color:#64748b;"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST" action="<?php echo e(route('admin.folders.store')); ?>">
            <?php echo csrf_field(); ?>
            <div style="margin-bottom:12px;">
                <label class="field-label">اسم المجلد *</label>
                <input name="name" type="text" required class="inp inp-sm" placeholder="مثال: أفلام الرياضة">
            </div>
            <div style="margin-bottom:18px;">
                <label class="field-label">الوصف (اختياري)</label>
                <input name="description" type="text" class="inp inp-sm" placeholder="وصف مختصر...">
            </div>
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center;">
                <i class="fas fa-folder-plus"></i> إنشاء
            </button>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" style="display:none;position:fixed;inset:0;z-index:60;align-items:center;justify-content:center;background:rgba(0,0,0,.75);">
    <div class="card" style="width:100%;max-width:420px;margin:0 16px;padding:22px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
            <span style="font-size:14px;font-weight:600;"><i class="fas fa-pen" style="color:#a78bfa;margin-left:7px;"></i> تعديل المجلد</span>
            <button onclick="closeEditModal()" class="ibtn" style="background:rgba(255,255,255,.05);color:#64748b;"><i class="fas fa-times"></i></button>
        </div>
        <form id="editForm" method="POST" action="">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div style="margin-bottom:12px;">
                <label class="field-label">اسم المجلد *</label>
                <input id="editName" name="name" type="text" required class="inp inp-sm">
            </div>
            <div style="margin-bottom:18px;">
                <label class="field-label">الوصف</label>
                <input id="editDesc" name="description" type="text" class="inp inp-sm">
            </div>
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center;">
                <i class="fas fa-save"></i> حفظ التغييرات
            </button>
        </form>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function openCreateModal() {
    document.getElementById('createModal').style.display = 'flex';
}
function closeCreateModal() {
    document.getElementById('createModal').style.display = 'none';
}
function openEditModal(id, name, desc) {
    document.getElementById('editName').value = name;
    document.getElementById('editDesc').value = desc;
    document.getElementById('editForm').action = '/admin/folders/' + id;
    document.getElementById('editModal').style.display = 'flex';
}
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}
document.getElementById('createModal').addEventListener('click', e => {
    if (e.target === document.getElementById('createModal')) closeCreateModal();
});
document.getElementById('editModal').addEventListener('click', e => {
    if (e.target === document.getElementById('editModal')) closeEditModal();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\StreamHost\resources\views/admin/folders/index.blade.php ENDPATH**/ ?>