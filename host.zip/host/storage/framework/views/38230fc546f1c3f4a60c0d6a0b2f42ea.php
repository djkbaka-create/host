<?php $__env->startSection('title', 'لوحة التحكم'); ?>
<?php $__env->startSection('breadcrumb', 'StreamHost › لوحة التحكم'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .stat-card {
        background: rgba(255,255,255,.025);
        border: 1px solid rgba(255,255,255,.065);
        border-radius: 14px;
        padding: 18px 20px;
        display: flex;
        align-items: center;
        gap: 14px;
        transition: border-color .2s, transform .2s;
    }
    .stat-card:hover { border-color: rgba(139,92,246,.25); transform: translateY(-2px); }
    .stat-icon {
        width: 44px; height: 44px; border-radius: 11px; flex-shrink: 0;
        display: flex; align-items: center; justify-content: center; font-size: 17px;
    }
    .stat-val  { font-size: 26px; font-weight: 700; color: #f1f5f9; line-height: 1.1; }
    .stat-lbl  { font-size: 11.5px; color: #475569; margin-top: 3px; }

    .quick-link {
        display: flex; align-items: center; gap: 10px;
        padding: 11px 14px; border-radius: 10px; font-size: 13px;
        text-decoration: none; transition: all .15s;
        border: 1px solid transparent;
    }
    .quick-link:hover { filter: brightness(1.1); transform: translateX(-2px); }

    /* chart container */
    #viewsChart { max-height: 220px; }

    /* table row */
    .video-row { display:flex; align-items:center; justify-content:space-between; padding:11px 18px; transition:background .15s; }
    .video-row:hover { background: rgba(255,255,255,.03); }
    .video-row + .video-row { border-top: 1px solid rgba(255,255,255,.045); }
    .thumb { width:56px; height:35px; border-radius:7px; object-fit:cover; flex-shrink:0; }
    .thumb-ph { width:56px; height:35px; border-radius:7px; background:rgba(255,255,255,.05); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- ── Stats ── -->
<div style="display:grid; grid-template-columns:repeat(5,1fr); gap:14px; margin-bottom:22px;">
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(139,92,246,.15);">
            <i class="fas fa-film" style="color:#a78bfa;"></i>
        </div>
        <div>
            <div class="stat-val"><?php echo e($stats['total']); ?></div>
            <div class="stat-lbl">إجمالي الفيديوهات</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(34,197,94,.12);">
            <i class="fas fa-circle-check" style="color:#4ade80;"></i>
        </div>
        <div>
            <div class="stat-val"><?php echo e($stats['ready']); ?></div>
            <div class="stat-lbl">جاهز للتشغيل</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(234,179,8,.12);">
            <i class="fas fa-gear fa-spin" style="color:#facc15;"></i>
        </div>
        <div>
            <div class="stat-val"><?php echo e($stats['processing']); ?></div>
            <div class="stat-lbl">قيد المعالجة</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(239,68,68,.12);">
            <i class="fas fa-circle-xmark" style="color:#f87171;"></i>
        </div>
        <div>
            <div class="stat-val"><?php echo e($stats['failed']); ?></div>
            <div class="stat-lbl">فشلت</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(59,130,246,.12);">
            <i class="fas fa-eye" style="color:#60a5fa;"></i>
        </div>
        <div>
            <div class="stat-val"><?php echo e(number_format($stats['views'])); ?></div>
            <div class="stat-lbl">إجمالي المشاهدات</div>
        </div>
    </div>
</div>

<!-- ── Chart + Recent + Quick ── -->
<div style="display:grid; grid-template-columns:1fr 340px; gap:18px;">

    <!-- Right col: chart + recent -->
    <div style="display:flex; flex-direction:column; gap:16px;">

        <!-- Views chart -->
        <div class="card">
            <div class="card-head">
                <span style="font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;">
                    <i class="fas fa-chart-area" style="color:#a78bfa;"></i>
                    المشاهدات — آخر 30 يوم
                </span>
                <span style="font-size:11px;color:#475569;">
                    <i class="fas fa-calendar-days" style="margin-left:4px;"></i>
                    <?php echo e(now()->subDays(29)->format('d/m')); ?> — <?php echo e(now()->format('d/m')); ?>

                </span>
            </div>
            <div style="padding:18px;">
                <?php if(array_sum($chartData) === 0): ?>
                <div style="text-align:center;padding:40px 0;color:#334155;">
                    <i class="fas fa-chart-line" style="font-size:2rem;display:block;margin-bottom:10px;opacity:.3;"></i>
                    <p style="font-size:13px;">لا توجد مشاهدات مسجّلة بعد</p>
                    <p style="font-size:11px;margin-top:4px;color:#1e293b;">ستظهر البيانات عند مشاهدة الفيديوهات</p>
                </div>
                <?php else: ?>
                <canvas id="viewsChart"></canvas>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent videos -->
        <div class="card" style="overflow:hidden;">
            <div class="card-head">
                <span style="font-size:13px;font-weight:600;display:flex;align-items:center;gap:7px;">
                    <i class="fas fa-clock-rotate-left" style="color:#a78bfa;"></i>
                    أحدث الفيديوهات
                </span>
                <a href="<?php echo e(route('admin.videos.index')); ?>" style="font-size:11.5px;color:#7c3aed;text-decoration:none;">
                    عرض الكل <i class="fas fa-arrow-left" style="font-size:9px;"></i>
                </a>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="video-row">
                <div style="display:flex;align-items:center;gap:11px;min-width:0;flex:1;">
                    <?php if($video->thumbnail): ?>
                    <img src="<?php echo e(Storage::url($video->thumbnail)); ?>" class="thumb">
                    <?php else: ?>
                    <div class="thumb-ph"><i class="fas fa-film" style="color:#334155;font-size:12px;"></i></div>
                    <?php endif; ?>
                    <div style="min-width:0;">
                        <div style="font-size:13px;color:#e2e8f0;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:260px;"><?php echo e($video->title); ?></div>
                        <div style="font-size:11px;color:#475569;margin-top:2px;display:flex;gap:10px;">
                            <span><i class="fas fa-clock" style="margin-left:3px;"></i><?php echo e($video->formatted_duration); ?></span>
                            <span><i class="fas fa-eye" style="margin-left:3px;"></i><?php echo e(number_format($video->views)); ?></span>
                        </div>
                    </div>
                </div>
                <div style="display:flex;align-items:center;gap:7px;flex-shrink:0;">
                    <?php
                    $bc = match($video->status) {
                        'ready'      => 'b-ready',
                        'processing' => 'b-processing',
                        'failed'     => 'b-failed',
                        default      => 'b-pending',
                    };
                    $bt = match($video->status) { 'ready'=>'جاهز','processing'=>'معالجة','failed'=>'فشل',default=>'انتظار' };
                    ?>
                    <span class="status-badge <?php echo e($bc); ?>"><?php echo e($bt); ?></span>
                    <?php if($video->isReady()): ?>
                    <a href="/embed/<?php echo e($video->slug); ?>" target="_blank"
                       class="ibtn" style="background:rgba(34,197,94,.1);color:#4ade80;" title="تشغيل">
                        <i class="fas fa-play"></i>
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.videos.edit',$video)); ?>"
                       class="ibtn" style="background:rgba(139,92,246,.1);color:#a78bfa;" title="تعديل">
                        <i class="fas fa-pen"></i>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div style="text-align:center;padding:44px 0;color:#334155;">
                <i class="fas fa-film" style="font-size:2.2rem;display:block;margin-bottom:10px;opacity:.2;"></i>
                <p style="font-size:13px;">لا توجد فيديوهات</p>
                <a href="<?php echo e(route('admin.videos.create')); ?>" style="font-size:12px;color:#7c3aed;text-decoration:none;display:inline-block;margin-top:8px;">
                    ارفع أول فيديو →
                </a>
            </div>
            <?php endif; ?>
        </div>

    </div>

    <!-- Left col: actions + system -->
    <div style="display:flex;flex-direction:column;gap:14px;">

        <!-- Quick actions -->
        <div class="card" style="padding:16px;">
            <div style="font-size:12.5px;font-weight:700;color:#94a3b8;margin-bottom:12px;display:flex;align-items:center;gap:7px;">
                <i class="fas fa-bolt" style="color:#facc15;"></i> إجراءات سريعة
            </div>
            <div style="display:flex;flex-direction:column;gap:6px;">
                <a href="<?php echo e(route('admin.videos.create')); ?>" class="quick-link"
                   style="background:rgba(124,58,237,.1);border-color:rgba(124,58,237,.2);color:#a78bfa;">
                    <i class="fas fa-upload" style="width:16px;text-align:center;"></i>
                    <span style="font-weight:600;">رفع فيديو جديد</span>
                </a>
                <a href="<?php echo e(route('admin.videos.index', ['status'=>'processing'])); ?>" class="quick-link"
                   style="background:rgba(234,179,8,.05);border-color:rgba(234,179,8,.15);color:#facc15;">
                    <i class="fas fa-gear" style="width:16px;text-align:center;"></i>
                    قيد المعالجة
                    <?php if($stats['processing'] > 0): ?>
                    <span style="margin-right:auto;background:rgba(234,179,8,.2);color:#facc15;font-size:10px;padding:1px 7px;border-radius:99px;font-weight:700;"><?php echo e($stats['processing']); ?></span>
                    <?php endif; ?>
                </a>
                <a href="<?php echo e(route('admin.videos.index', ['status'=>'failed'])); ?>" class="quick-link"
                   style="background:rgba(239,68,68,.05);border-color:rgba(239,68,68,.15);color:#f87171;">
                    <i class="fas fa-triangle-exclamation" style="width:16px;text-align:center;"></i>
                    فيديوهات فاشلة
                    <?php if($stats['failed'] > 0): ?>
                    <span style="margin-right:auto;background:rgba(239,68,68,.2);color:#f87171;font-size:10px;padding:1px 7px;border-radius:99px;font-weight:700;"><?php echo e($stats['failed']); ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>

        <!-- System status -->
        <div class="card" style="padding:16px;">
            <div style="font-size:12.5px;font-weight:700;color:#94a3b8;margin-bottom:12px;display:flex;align-items:center;gap:7px;">
                <i class="fas fa-server" style="color:#60a5fa;"></i> حالة النظام
            </div>
            <?php
if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    $ffmpeg = (bool) shell_exec('where ffmpeg');
} else {
    $ffmpeg = (bool) shell_exec('which ffmpeg 2>/dev/null');
}
?>
            <div style="display:flex;flex-direction:column;gap:9px;font-size:12px;">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:#64748b;">FFmpeg</span>
                    <?php if($ffmpeg): ?>
                    <span style="color:#4ade80;display:flex;align-items:center;gap:4px;"><span style="width:6px;height:6px;background:#4ade80;border-radius:50%;box-shadow:0 0 5px #4ade80;display:inline-block;"></span> متاح</span>
                    <?php else: ?>
                    <span style="color:#f87171;">غير متاح</span>
                    <?php endif; ?>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:#64748b;">Queue Worker</span>
                    <span style="color:#4ade80;display:flex;align-items:center;gap:4px;"><span style="width:6px;height:6px;background:#4ade80;border-radius:50%;box-shadow:0 0 5px #4ade80;display:inline-block;"></span> يعمل</span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:#64748b;">المعالجة</span>
                    <span style="color:#a78bfa;">HLS Multi-Quality</span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:#64748b;">الجودات</span>
                    <span style="color:#94a3b8;">360/480/720/1080p</span>
                </div>
                <div style="height:1px;background:rgba(255,255,255,.05);margin:4px 0;"></div>
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <span style="color:#64748b;">مشاهدات الـ30 يوم</span>
                    <span style="color:#60a5fa;font-weight:600;"><?php echo e(number_format(array_sum($chartData))); ?></span>
                </div>
            </div>
        </div>

        <!-- Top videos -->
        <?php if($stats['ready'] > 0): ?>
        <div class="card" style="padding:16px;">
            <div style="font-size:12.5px;font-weight:700;color:#94a3b8;margin-bottom:12px;display:flex;align-items:center;gap:7px;">
                <i class="fas fa-trophy" style="color:#facc15;"></i> أكثر مشاهدة
            </div>
            <?php $topVideos = \App\Models\Video::where('status','ready')->orderByDesc('views')->limit(5)->get(); ?>
            <div style="display:flex;flex-direction:column;gap:7px;">
                <?php $__empty_1 = true; $__currentLoopData = $topVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="display:flex;align-items:center;gap:8px;">
                    <span style="width:18px;height:18px;border-radius:50%;background:rgba(255,255,255,.06);font-size:10px;color:#64748b;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><?php echo e($i+1); ?></span>
                    <span style="flex:1;font-size:12px;color:#cbd5e1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?php echo e($tv->title); ?></span>
                    <span style="font-size:11px;color:#60a5fa;font-weight:600;flex-shrink:0;"><?php echo e(number_format($tv->views)); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <span style="font-size:12px;color:#334155;">لا توجد بيانات</span>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

<?php $processingCount = $stats['processing'] + ($stats['pending'] ?? 0); ?>
<?php if($processingCount > 0): ?>
<script>setTimeout(() => window.location.reload(), 9000);</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if(array_sum($chartData) > 0): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function() {
    const labels = <?php echo json_encode($chartLabels, 15, 512) ?>;
    const data   = <?php echo json_encode($chartData, 15, 512) ?>;

    const ctx = document.getElementById('viewsChart').getContext('2d');
    const gradient = ctx.createLinearGradient(0, 0, 0, 220);
    gradient.addColorStop(0, 'rgba(139,92,246,0.35)');
    gradient.addColorStop(1, 'rgba(139,92,246,0.01)');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'مشاهدات',
                data,
                borderColor: '#8b5cf6',
                backgroundColor: gradient,
                borderWidth: 2,
                pointRadius: 3,
                pointHoverRadius: 5,
                pointBackgroundColor: '#a78bfa',
                pointBorderColor: '#1e1e35',
                pointBorderWidth: 2,
                fill: true,
                tension: 0.4,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1a1a2e',
                    titleColor: '#94a3b8',
                    bodyColor: '#a78bfa',
                    borderColor: 'rgba(139,92,246,.3)',
                    borderWidth: 1,
                    padding: 10,
                    callbacks: {
                        label: ctx => ' ' + ctx.parsed.y.toLocaleString('ar') + ' مشاهدة',
                    }
                },
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255,255,255,.04)', drawBorder: false },
                    ticks: { color: '#475569', font: { size: 10 }, maxTicksLimit: 8 },
                },
                y: {
                    grid: { color: 'rgba(255,255,255,.04)', drawBorder: false },
                    ticks: { color: '#475569', font: { size: 10 }, precision: 0 },
                    beginAtZero: true,
                }
            }
        }
    });
})();
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\StreamHost\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>