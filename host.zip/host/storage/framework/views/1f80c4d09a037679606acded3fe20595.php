<!DOCTYPE html>
<html lang="ar" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title><?php echo e($video->title); ?></title>
    <style>
        *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
        html,body{width:100%;height:100%;background:#000;overflow:hidden;font-family:system-ui,sans-serif;user-select:none;}

        /* ── container ── */
        #pw{position:relative;width:100%;height:100%;background:#000;display:flex;align-items:center;justify-content:center;overflow:hidden;}
        #pw.hide-cursor{cursor:none;}
        video{width:100%;height:100%;display:block;object-fit:contain;}

        /* ── big play button ── */
        #bigPlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;z-index:10;pointer-events:none;transition:opacity .25s;}
        #bigPlay.hidden{opacity:0;}
        #bigPlay-btn{width:72px;height:72px;border-radius:50%;background:rgba(124,58,237,.85);backdrop-filter:blur(8px);border:2px solid rgba(255,255,255,.3);display:flex;align-items:center;justify-content:center;transition:transform .15s;}
        #pw:hover #bigPlay-btn{transform:scale(1.08);}
        #bigPlay-btn svg{fill:#fff;width:28px;height:28px;margin-left:4px;}

        /* ── ad timer overlay ── */
        #adTimerOverlay{position:absolute;inset:0;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;z-index:30;transition:opacity .3s;}
        #adTimerOverlay.hidden{opacity:0;pointer-events:none;}
        #adTimerBox{text-align:center;}
        #adTimerCount{font-size:56px;font-weight:700;color:#fff;line-height:1;margin-bottom:8px;}
        #adTimerLabel{font-size:14px;color:rgba(255,255,255,.55);}
        #adTimerSkip{margin-top:20px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;padding:9px 24px;border-radius:8px;font-size:13px;cursor:pointer;display:none;transition:background .15s;}
        #adTimerSkip:hover{background:rgba(255,255,255,.22);}

        /* ── controls bar ── */
        #controls{
            position:absolute;bottom:0;left:0;right:0;
            padding:0 14px 10px;
            background:linear-gradient(transparent,rgba(0,0,0,.8) 45%,rgba(0,0,0,.92));
            transform:translateY(0);transition:opacity .28s,transform .28s;
            z-index:20;
        }
        #controls.hidden{opacity:0;transform:translateY(8px);pointer-events:none;}

        /* progress */
        #progWrap{
            position:relative;height:16px;cursor:pointer;display:flex;align-items:center;
            margin-bottom:5px;
        }
        #progBg{
            width:100%;height:4px;background:rgba(255,255,255,.18);border-radius:4px;
            position:relative;overflow:hidden;transition:height .15s;
        }
        #progWrap:hover #progBg{height:6px;}
        #progBuf{position:absolute;left:0;top:0;height:100%;background:rgba(255,255,255,.25);width:0%;}
        #progFill{position:absolute;left:0;top:0;height:100%;background:linear-gradient(90deg,#7c3aed,#a855f7);width:0%;border-radius:4px;}
        #progThumb{
            position:absolute;width:12px;height:12px;border-radius:50%;background:#a855f7;
            top:50%;transform:translate(-50%,-50%);left:0%;
            box-shadow:0 0 6px #a855f7;display:none;pointer-events:none;
        }
        #progWrap:hover #progThumb{display:block;}
        #progTooltip{
            position:absolute;bottom:22px;background:rgba(10,10,20,.9);color:#fff;
            font-size:11px;padding:3px 7px;border-radius:5px;pointer-events:none;
            transform:translateX(-50%);white-space:nowrap;display:none;
        }

        /* bottom row */
        #ctrlRow{display:flex;align-items:center;gap:8px;}
        .cbtn{
            background:none;border:none;cursor:pointer;color:rgba(255,255,255,.85);
            padding:5px;border-radius:6px;transition:color .15s,background .15s;
            display:flex;align-items:center;justify-content:center;flex-shrink:0;
        }
        .cbtn:hover{color:#fff;background:rgba(255,255,255,.1);}
        .cbtn svg{width:18px;height:18px;fill:currentColor;}
        .cbtn.active{color:#a855f7;}

        /* time */
        #timeDisp{font-size:12px;color:rgba(255,255,255,.7);white-space:nowrap;margin:0 2px;}
        #timeDisp span{color:#fff;}

        /* volume */
        #volWrap{display:flex;align-items:center;gap:5px;}
        #volSlider{
            -webkit-appearance:none;appearance:none;width:64px;height:3px;border-radius:3px;
            background:rgba(255,255,255,.25);outline:none;cursor:pointer;
        }
        #volSlider::-webkit-slider-thumb{
            -webkit-appearance:none;width:12px;height:12px;border-radius:50%;
            background:#a855f7;cursor:pointer;
        }

        /* spacer */
        .csp{flex:1;}

        /* menus */
        .menu{
            position:absolute;bottom:46px;right:0;
            background:rgba(14,14,24,.96);border:1px solid rgba(255,255,255,.1);
            border-radius:10px;padding:6px 0;min-width:140px;z-index:50;
            backdrop-filter:blur(12px);box-shadow:0 8px 24px rgba(0,0,0,.6);
        }
        .menu-item{
            padding:8px 14px;font-size:12.5px;color:rgba(255,255,255,.75);cursor:pointer;
            display:flex;align-items:center;justify-content:space-between;gap:8px;
            transition:background .1s,color .1s;
        }
        .menu-item:hover{background:rgba(255,255,255,.07);color:#fff;}
        .menu-item.active{color:#a855f7;}
        .menu-item.active::after{content:'✓';font-size:11px;}
        .menu-sep{height:1px;background:rgba(255,255,255,.07);margin:4px 0;}
        .menu-label{padding:5px 14px;font-size:10px;color:#475569;text-transform:uppercase;letter-spacing:.05em;}

        /* menu wrapper (positions the menu relative to button) */
        .menu-wrap{position:relative;}

        /* captions overlay */
        #captionsDisp{
            position:absolute;bottom:70px;left:50%;transform:translateX(-50%);
            background:rgba(0,0,0,.75);color:#fff;font-size:16px;padding:4px 12px;
            border-radius:6px;text-align:center;max-width:80%;pointer-events:none;z-index:15;
            display:none;
        }

        /* loading spinner */
        #spinner{
            position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
            z-index:25;pointer-events:none;opacity:0;transition:opacity .2s;
        }
        #spinner.visible{opacity:1;}
        #spinner-ring{
            width:42px;height:42px;border:3px solid rgba(255,255,255,.12);
            border-top-color:#a855f7;border-radius:50%;animation:spin .7s linear infinite;
        }
        @keyframes spin{to{transform:rotate(360deg);}}

        /* click-flash */
        #clickFlash{
            position:absolute;inset:0;background:rgba(255,255,255,.06);
            pointer-events:none;opacity:0;transition:opacity .12s;z-index:5;
        }

        /* title bar */
        #titleBar{
            position:absolute;top:0;left:0;right:0;padding:10px 14px;
            background:linear-gradient(rgba(0,0,0,.7),transparent);
            font-size:13px;font-weight:600;color:rgba(255,255,255,.85);
            pointer-events:none;transition:opacity .28s;z-index:20;
        }
        #titleBar.hidden{opacity:0;}
    </style>
</head>
<body>
<div id="pw">
    <!-- Video element -->
    <video id="vid" playsinline preload="metadata"
           poster="<?php echo e($video->thumbnail ? Storage::url($video->thumbnail) : ''); ?>">
        <?php $__currentLoopData = $video->subtitles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <track kind="subtitles"
               src="<?php echo e(Storage::url($sub->file_path)); ?>"
               srclang="<?php echo e($sub->language); ?>"
               label="<?php echo e($sub->label); ?>"
               <?php echo e($sub->is_default ? 'default' : ''); ?>>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </video>

    <!-- Loading spinner -->
    <div id="spinner"><div id="spinner-ring"></div></div>

    <!-- Click flash -->
    <div id="clickFlash"></div>

    <!-- Title bar -->
    <div id="titleBar"><?php echo e($video->title); ?></div>

    <!-- Big play button -->
    <div id="bigPlay">
        <div id="bigPlay-btn">
            <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
        </div>
    </div>

    <!-- Ad Timer Overlay -->
    <div id="adTimerOverlay" class="hidden">
        <div id="adTimerBox">
            <div id="adTimerCount">5</div>
            <div id="adTimerLabel">الإعلان ينتهي خلال</div>
            <button id="adTimerSkip" onclick="skipAdTimer()">تخطّ الإعلان ←</button>
        </div>
    </div>

    <!-- Captions display -->
    <div id="captionsDisp"></div>

    <!-- Controls -->
    <div id="controls">
        <!-- Progress bar -->
        <div id="progWrap">
            <div id="progBg">
                <div id="progBuf"></div>
                <div id="progFill"></div>
            </div>
            <div id="progThumb"></div>
            <div id="progTooltip"></div>
        </div>

        <!-- Bottom row -->
        <div id="ctrlRow">
            <!-- Play/Pause -->
            <button class="cbtn" id="playBtn" onclick="togglePlay()" title="تشغيل/إيقاف (مسطرة)">
                <svg id="icPlay" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                <svg id="icPause" viewBox="0 0 24 24" style="display:none;"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
            </button>

            <!-- Volume -->
            <div id="volWrap">
                <button class="cbtn" id="muteBtn" onclick="toggleMute()" title="صوت (M)">
                    <svg id="icVol" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
                    <svg id="icMute" viewBox="0 0 24 24" style="display:none;"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>
                </button>
                <input id="volSlider" type="range" min="0" max="100" value="100" oninput="setVol(this.value)">
            </div>

            <!-- Time display -->
            <div id="timeDisp"><span id="tCur">0:00</span> / <span id="tDur">0:00</span></div>

            <div class="csp"></div>

            <!-- Quality menu -->
            <div class="menu-wrap" id="qualWrap" style="display:none;">
                <button class="cbtn" id="qualBtn" onclick="toggleMenu('qualMenu')" title="الجودة">
                    <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14H7v-2h5v2zm5-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
                </button>
                <div id="qualMenu" class="menu" style="display:none;">
                    <div class="menu-label">الجودة</div>
                </div>
            </div>

            <!-- Speed menu -->
            <div class="menu-wrap">
                <button class="cbtn" id="speedBtn" onclick="toggleMenu('speedMenu')" title="سرعة التشغيل">
                    <svg viewBox="0 0 24 24"><path d="M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44zm-9.79 6.84a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z"/></svg>
                </button>
                <div id="speedMenu" class="menu" style="display:none;">
                    <div class="menu-label">سرعة التشغيل</div>
                    <?php $__currentLoopData = [0.5, 0.75, 1, 1.25, 1.5, 2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="menu-item <?php echo e($s == 1 ? 'active' : ''); ?>" data-speed="<?php echo e($s); ?>" onclick="setSpeed(<?php echo e($s); ?>)">
                        <?php echo e($s == 1 ? 'عادي' : $s . 'x'); ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Subtitle menu -->
            <?php if($video->subtitles->count() > 0): ?>
            <div class="menu-wrap" id="subWrap">
                <button class="cbtn" id="subBtn" onclick="toggleMenu('subMenu')" title="الترجمة">
                    <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zM4 12h4v2H4v-2zm10 6H4v-2h10v2zm6 0h-4v-2h4v2zm0-4H10v-2h10v2z"/></svg>
                </button>
                <div id="subMenu" class="menu" style="display:none;">
                    <div class="menu-label">الترجمة</div>
                    <div class="menu-item" onclick="setSub(-1)" id="subOff">إيقاف</div>
                    <?php $__currentLoopData = $video->subtitles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="menu-item <?php echo e($sub->is_default ? 'active' : ''); ?>"
                         onclick="setSub(<?php echo e($i); ?>)" data-sub="<?php echo e($i); ?>">
                        <?php echo e($sub->label); ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Fullscreen -->
            <button class="cbtn" onclick="toggleFS()" title="ملء الشاشة (F)">
                <svg id="icFS" viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>
                <svg id="icFSExit" viewBox="0 0 24 24" style="display:none;"><path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/></svg>
            </button>
        </div>
    </div>
</div>

<!-- hls.js -->
<script src="https://cdn.jsdelivr.net/npm/hls.js@1.5.7/dist/hls.min.js"></script>

<?php if(!empty($adConfig?->vast_url)): ?>
<script src="https://imasdk.googleapis.com/js/sdkloader/ima3.js" async></script>
<?php endif; ?>

<script>
(function () {
'use strict';

// ─── Config ────────────────────────────────────────────
const M3U8   = <?php echo json_encode($m3u8Url, 15, 512) ?>;
<?php
$_adCfgData = $adConfig ? [
    'vast_url'          => $adConfig->vast_url,
    'popunder_script'   => $adConfig->popunder_script,
    'popunder_on_play'  => $adConfig->popunder_on_play,
    'popunder_on_seek'  => $adConfig->popunder_on_seek,
    'popunder_delay'    => $adConfig->popunder_delay,
    'ad_timer_seconds'  => $adConfig->ad_timer_seconds,
] : [];
?>
const AD_CFG = <?php echo json_encode($_adCfgData, 15, 512) ?>;
const SUBTITLES = <?php echo json_encode($video->subtitles->values(), 15, 512) ?>;

// ─── Elements ──────────────────────────────────────────
const pw       = document.getElementById('pw');
const vid      = document.getElementById('vid');
const playBtn  = document.getElementById('playBtn');
const icPlay   = document.getElementById('icPlay');
const icPause  = document.getElementById('icPause');
const muteBtn  = document.getElementById('muteBtn');
const icVol    = document.getElementById('icVol');
const icMute   = document.getElementById('icMute');
const volSlider= document.getElementById('volSlider');
const progWrap = document.getElementById('progWrap');
const progFill = document.getElementById('progFill');
const progBuf  = document.getElementById('progBuf');
const progThumb= document.getElementById('progThumb');
const progTip  = document.getElementById('progTooltip');
const tCur     = document.getElementById('tCur');
const tDur     = document.getElementById('tDur');
const controls = document.getElementById('controls');
const bigPlay  = document.getElementById('bigPlay');
const titleBar = document.getElementById('titleBar');
const spinner  = document.getElementById('spinner');
const icFS     = document.getElementById('icFS');
const icFSExit = document.getElementById('icFSExit');
const captDisp = document.getElementById('captionsDisp');

// ─── HLS Setup ─────────────────────────────────────────
let hls = null;
let qualityLevels = [];
let currentLevel  = -1; // -1 = auto

function initHls() {
    if (Hls.isSupported()) {
        hls = new Hls({
            enableWorker: true,
            lowLatencyMode: false,
            backBufferLength: 60,
        });
        hls.loadSource(M3U8);
        hls.attachMedia(vid);

        hls.on(Hls.Events.MANIFEST_PARSED, (_, data) => {
            qualityLevels = data.levels;
            buildQualityMenu();
        });

        hls.on(Hls.Events.LEVEL_SWITCHED, (_, data) => {
            updateQualityActive(data.level);
        });

        hls.on(Hls.Events.BUFFER_APPENDING, updateBuffer);
        hls.on(Hls.Events.ERROR, (_, data) => {
            if (data.fatal) {
                if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
                else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
            }
        });
    } else if (vid.canPlayType('application/vnd.apple.mpegurl')) {
        vid.src = M3U8;
    }
}
initHls();

// ─── Quality menu ──────────────────────────────────────
function buildQualityMenu() {
    if (!qualityLevels.length) return;
    const wrap = document.getElementById('qualWrap');
    const menu  = document.getElementById('qualMenu');
    wrap.style.display = 'block';

    // Auto option
    const auto = document.createElement('div');
    auto.className = 'menu-item active';
    auto.textContent = 'تلقائي';
    auto.setAttribute('data-level', '-1');
    auto.onclick = () => { hls.currentLevel = -1; setMenuActive('qualMenu', '-1', 'data-level'); closeAllMenus(); };
    menu.appendChild(auto);

    const sep = document.createElement('div');
    sep.className = 'menu-sep';
    menu.appendChild(sep);

    qualityLevels.forEach((lvl, i) => {
        const h = lvl.height || Math.round(lvl.bitrate / 150000) * 100;
        const item = document.createElement('div');
        item.className = 'menu-item';
        item.textContent = h ? h + 'p' : (Math.round(lvl.bitrate / 1000) + 'k');
        item.setAttribute('data-level', i);
        item.onclick = () => { hls.currentLevel = i; setMenuActive('qualMenu', i, 'data-level'); closeAllMenus(); };
        menu.appendChild(item);
    });
}

function updateQualityActive(level) {
    setMenuActive('qualMenu', level, 'data-level');
    const btn = document.getElementById('qualBtn');
    if (level >= 0 && qualityLevels[level]) {
        const h = qualityLevels[level].height;
        btn.title = h ? h + 'p' : 'HD';
    }
}

// ─── Play / Pause ──────────────────────────────────────
let firstPlay = true;
let adTimerDone = false;
let adTimerActive = false;

function togglePlay() {
    if (adTimerActive) return;
    if (vid.paused) vid.play();
    else vid.pause();
}
window.togglePlay = togglePlay;

vid.addEventListener('play', () => {
    icPlay.style.display  = 'none';
    icPause.style.display = '';
    bigPlay.classList.add('hidden');
    if (firstPlay) {
        firstPlay = false;
        if (!adTimerDone) triggerAdTimer();
        schedulePopunder('play');
    }
});

vid.addEventListener('pause', () => {
    icPlay.style.display  = '';
    icPause.style.display = 'none';
});

vid.addEventListener('ended', () => {
    icPlay.style.display  = '';
    icPause.style.display = 'none';
    bigPlay.classList.remove('hidden');
});

// ─── Ad Timer ──────────────────────────────────────────
let adTimerInterval = null;
const AD_TIMER_SECS = parseInt(AD_CFG.ad_timer_seconds) || 0;

function triggerAdTimer() {
    if (!AD_TIMER_SECS) return;
    vid.pause();
    adTimerActive = true;
    const overlay = document.getElementById('adTimerOverlay');
    overlay.classList.remove('hidden');
    let remaining = AD_TIMER_SECS;
    document.getElementById('adTimerCount').textContent = remaining;

    const skip = document.getElementById('adTimerSkip');
    if (AD_TIMER_SECS > 5) setTimeout(() => { skip.style.display = 'inline-block'; }, (AD_TIMER_SECS - 5) * 1000);
    else skip.style.display = 'inline-block';

    adTimerInterval = setInterval(() => {
        remaining--;
        document.getElementById('adTimerCount').textContent = remaining;
        if (remaining <= 0) { clearInterval(adTimerInterval); skipAdTimer(); }
    }, 1000);
}

function skipAdTimer() {
    if (adTimerInterval) clearInterval(adTimerInterval);
    adTimerActive = false;
    adTimerDone   = true;
    const overlay = document.getElementById('adTimerOverlay');
    overlay.classList.add('hidden');
    vid.play();
}
window.skipAdTimer = skipAdTimer;

// ─── Popunder ──────────────────────────────────────────
let popunderFired = false;
let popunderCooldown = false;

function firePopunder() {
    const script = AD_CFG.popunder_script;
    if (!script || popunderCooldown) return;
    popunderCooldown = true;
    setTimeout(() => { popunderCooldown = false; }, 5000);

    const delay = parseInt(AD_CFG.popunder_delay) || 0;
    setTimeout(() => {
        const wrap = document.createElement('div');
        wrap.innerHTML = script;
        wrap.querySelectorAll('script').forEach(s => {
            const ns = document.createElement('script');
            if (s.src) { ns.src = s.src; }
            else { ns.textContent = s.textContent; }
            document.body.appendChild(ns);
        });
    }, delay * 1000);
}

function schedulePopunder(trigger) {
    if (!AD_CFG.popunder_script) return;
    if (trigger === 'play' && AD_CFG.popunder_on_play && !popunderFired) {
        popunderFired = true;
        firePopunder();
    }
    if (trigger === 'seek' && AD_CFG.popunder_on_seek) {
        firePopunder();
    }
}

vid.addEventListener('seeked', () => schedulePopunder('seek'));

// ─── VAST / IMA ────────────────────────────────────────
<?php if(!empty($adConfig?->vast_url)): ?>
let imaInit = false;
let adDisplayContainer, adsLoader, adsManager;

function initIMA() {
    if (imaInit || !window.google?.ima) return;
    imaInit = true;
    try {
        adDisplayContainer = new google.ima.AdDisplayContainer(pw, vid);
        adDisplayContainer.initialize();
        adsLoader = new google.ima.AdsLoader(adDisplayContainer);
        adsLoader.addEventListener(google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED, onAdsManagerLoaded, false);
        adsLoader.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR, onAdError, false);
        const req = new google.ima.AdsRequest();
        req.adTagUrl = <?php echo json_encode($adConfig->vast_url, 15, 512) ?>;
        req.linearAdSlotWidth  = pw.clientWidth  || 640;
        req.linearAdSlotHeight = pw.clientHeight || 360;
        adsLoader.requestAds(req);
    } catch(e) { console.warn('IMA init failed', e); }
}

function onAdsManagerLoaded(e) {
    try {
        adsManager = e.getAdsManager(vid);
        adsManager.init(pw.clientWidth, pw.clientHeight, google.ima.ViewMode.NORMAL);
        adsManager.start();
    } catch(e) { vid.play(); }
}

function onAdError() { if (adsManager) adsManager.destroy(); vid.play(); }

// init IMA when google.ima is ready
function waitForIma() {
    if (window.google?.ima) initIMA();
    else setTimeout(waitForIma, 200);
}
waitForIma();
<?php endif; ?>

// ─── Progress bar ──────────────────────────────────────
let scrubbing = false;

vid.addEventListener('timeupdate', () => {
    if (!vid.duration || scrubbing) return;
    const pct = (vid.currentTime / vid.duration) * 100;
    progFill.style.width  = pct + '%';
    progThumb.style.left  = pct + '%';
    tCur.textContent = fmtTime(vid.currentTime);
});

vid.addEventListener('durationchange', () => {
    tDur.textContent = fmtTime(vid.duration);
});

vid.addEventListener('progress', updateBuffer);
function updateBuffer() {
    if (!vid.duration || !vid.buffered.length) return;
    const pct = (vid.buffered.end(vid.buffered.length - 1) / vid.duration) * 100;
    progBuf.style.width = pct + '%';
}

// Scrub
progWrap.addEventListener('mousedown', (e) => {
    scrubbing = true;
    doScrub(e);
    document.addEventListener('mousemove', doScrub);
    document.addEventListener('mouseup', () => {
        scrubbing = false;
        document.removeEventListener('mousemove', doScrub);
    }, { once: true });
});

progWrap.addEventListener('mousemove', (e) => {
    if (!vid.duration) return;
    const rect  = progWrap.getBoundingClientRect();
    const frac  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const secs  = frac * vid.duration;
    const xPct  = frac * 100;
    progTip.style.display = 'block';
    progTip.style.left    = xPct + '%';
    progTip.textContent   = fmtTime(secs);
});
progWrap.addEventListener('mouseleave', () => { progTip.style.display = 'none'; });

function doScrub(e) {
    const rect = progWrap.getBoundingClientRect();
    const frac = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    vid.currentTime = frac * (vid.duration || 0);
    progFill.style.width = (frac * 100) + '%';
    progThumb.style.left = (frac * 100) + '%';
}

// ─── Volume ────────────────────────────────────────────
function setVol(v) {
    vid.volume = v / 100;
    vid.muted  = v == 0;
    volSlider.value = v;
    updateVolIcon();
    localStorage.setItem('sh_vol', v);
}
window.setVol = setVol;

function toggleMute() {
    vid.muted = !vid.muted;
    if (!vid.muted) volSlider.value = vid.volume * 100;
    updateVolIcon();
}
window.toggleMute = toggleMute;

function updateVolIcon() {
    const on = !vid.muted && vid.volume > 0;
    icVol.style.display  = on ? '' : 'none';
    icMute.style.display = on ? 'none' : '';
}

// Restore saved volume
const savedVol = localStorage.getItem('sh_vol');
if (savedVol !== null) { vid.volume = savedVol / 100; volSlider.value = savedVol; }

// ─── Fullscreen ────────────────────────────────────────
function toggleFS() {
    if (document.fullscreenElement) document.exitFullscreen();
    else pw.requestFullscreen();
}
window.toggleFS = toggleFS;

document.addEventListener('fullscreenchange', () => {
    const fs = !!document.fullscreenElement;
    icFS.style.display     = fs ? 'none' : '';
    icFSExit.style.display = fs ? '' : 'none';
});

// ─── Playback speed ────────────────────────────────────
function setSpeed(s) {
    vid.playbackRate = s;
    document.querySelectorAll('#speedMenu .menu-item').forEach(el => {
        el.classList.toggle('active', parseFloat(el.dataset.speed) === s);
    });
    closeAllMenus();
}
window.setSpeed = setSpeed;

// ─── Subtitles ─────────────────────────────────────────
function setSub(idx) {
    const tracks = vid.textTracks;
    for (let i = 0; i < tracks.length; i++) {
        tracks[i].mode = i === idx ? 'showing' : 'hidden';
    }
    document.querySelectorAll('#subMenu .menu-item').forEach(el => {
        const si = el.dataset.sub !== undefined ? parseInt(el.dataset.sub) : -1;
        el.classList.toggle('active', si === idx);
    });
    document.getElementById('subBtn')?.classList.toggle('active', idx >= 0);
    closeAllMenus();
}
window.setSub = setSub;

// Captions text overlay
function setupCaptionsOverlay() {
    const tracks = vid.textTracks;
    for (let i = 0; i < tracks.length; i++) {
        tracks[i].oncuechange = function() {
            const cue = this.activeCues[0];
            captDisp.style.display = cue ? 'block' : 'none';
            if (cue) captDisp.textContent = cue.text;
        };
    }
}
vid.addEventListener('loadedmetadata', setupCaptionsOverlay);

// ─── Menus ─────────────────────────────────────────────
function toggleMenu(id) {
    const menu = document.getElementById(id);
    const wasHidden = menu.style.display === 'none';
    closeAllMenus();
    menu.style.display = wasHidden ? 'block' : 'none';
}
window.toggleMenu = toggleMenu;

function closeAllMenus() {
    document.querySelectorAll('.menu').forEach(m => m.style.display = 'none');
}

function setMenuActive(menuId, val, attr) {
    document.querySelectorAll(`#${menuId} .menu-item`).forEach(el => {
        el.classList.toggle('active', el.getAttribute(attr) == val);
    });
}

// Close menus on outside click
document.addEventListener('click', (e) => {
    if (!e.target.closest('.menu-wrap')) closeAllMenus();
});

// ─── Controls visibility ───────────────────────────────
let hideTimer = null;

function showControls() {
    controls.classList.remove('hidden');
    titleBar.classList.remove('hidden');
    pw.classList.remove('hide-cursor');
    clearTimeout(hideTimer);
    hideTimer = setTimeout(autoHide, 3000);
}

function autoHide() {
    if (!vid.paused) {
        controls.classList.add('hidden');
        titleBar.classList.add('hidden');
        pw.classList.add('hide-cursor');
    }
}

pw.addEventListener('mousemove', showControls);
pw.addEventListener('mouseenter', showControls);
pw.addEventListener('mouseleave', () => { clearTimeout(hideTimer); });

// ─── Click to play/pause ───────────────────────────────
let clickTimer = null;
pw.addEventListener('click', (e) => {
    if (e.target.closest('#controls') || e.target.closest('.menu') || e.target.closest('#adTimerOverlay')) return;
    clearTimeout(clickTimer);
    clickTimer = setTimeout(() => {
        togglePlay();
        // flash
        const f = document.getElementById('clickFlash');
        f.style.opacity = '1';
        setTimeout(() => { f.style.opacity = '0'; }, 120);
    }, 180);
});

// Double-click = fullscreen
pw.addEventListener('dblclick', (e) => {
    if (e.target.closest('#controls') || e.target.closest('.menu')) return;
    clearTimeout(clickTimer);
    toggleFS();
});

// ─── Keyboard shortcuts ────────────────────────────────
document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    switch(e.key) {
        case ' ': case 'k': e.preventDefault(); togglePlay(); break;
        case 'ArrowRight':  e.preventDefault(); vid.currentTime = Math.min(vid.duration, vid.currentTime + 5); break;
        case 'ArrowLeft':   e.preventDefault(); vid.currentTime = Math.max(0, vid.currentTime - 5); break;
        case 'ArrowUp':     e.preventDefault(); setVol(Math.min(100, vid.volume * 100 + 10)); break;
        case 'ArrowDown':   e.preventDefault(); setVol(Math.max(0, vid.volume * 100 - 10)); break;
        case 'f': case 'F': e.preventDefault(); toggleFS(); break;
        case 'm': case 'M': e.preventDefault(); toggleMute(); break;
    }
});

// ─── Spinner ───────────────────────────────────────────
vid.addEventListener('waiting',  () => spinner.classList.add('visible'));
vid.addEventListener('canplay',  () => spinner.classList.remove('visible'));
vid.addEventListener('playing',  () => spinner.classList.remove('visible'));

// ─── Helper ────────────────────────────────────────────
function fmtTime(s) {
    if (!s || isNaN(s)) return '0:00';
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = Math.floor(s % 60);
    return h > 0
        ? `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`
        : `${m}:${String(sec).padStart(2,'0')}`;
}

// ─── Security ──────────────────────────────────────────
document.addEventListener('contextmenu', e => e.preventDefault());

})();
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\StreamHost\resources\views/embed/player.blade.php ENDPATH**/ ?>