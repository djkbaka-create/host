<?php $__env->startSection('title', 'إدارة المستخدمين'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.role-badge {
    display:inline-flex;align-items:center;gap:4px;padding:2px 9px;
    border-radius:99px;font-size:11px;font-weight:600;
}
.role-admin  { background:rgba(239,68,68,.12); color:#f87171; }
.role-editor { background:rgba(245,158,11,.12); color:#fbbf24; }
.role-viewer { background:rgba(100,116,139,.12); color:#94a3b8; }
.status-on  { background:rgba(34,197,94,.12); color:#4ade80; }
.status-off { background:rgba(239,68,68,.12); color:#f87171; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="topbar">
    <div>
        <h1 style="font-size:17px;font-weight:700;margin:0;">إدارة المستخدمين</h1>
        <div style="font-size:11px;color:#334155;margin-top:2px;">StreamHost › المستخدمون</div>
    </div>
    <div style="display:flex;gap:10px;">
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn-primary" style="font-size:13px;padding:8px 16px;">
            <i class="fas fa-user-plus"></i> مستخدم جديد
        </a>
    </div>
</div>

<?php if(session('success')): ?>
<div class="alert-ok mb-4"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert-err mb-4"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div>• <?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
<?php endif; ?>

<div class="card" style="overflow:hidden;">
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <thead>
            <tr style="border-bottom:1px solid rgba(255,255,255,.06);">
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">#</th>
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">المستخدم</th>
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">الدور</th>
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">الحالة</th>
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">تاريخ الإنشاء</th>
                <th style="padding:12px 16px;text-align:center;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">إجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr style="border-bottom:1px solid rgba(255,255,255,.04);transition:background .1s;" onmouseover="this.style.background='rgba(255,255,255,.02)'" onmouseout="this.style.background=''">
                <td style="padding:12px 16px;color:#475569;font-size:12px;"><?php echo e($u->id); ?></td>
                <td style="padding:12px 16px;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#a855f7);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0;">
                            <?php echo e(strtoupper(substr($u->username ?? $u->name, 0, 1))); ?>

                        </div>
                        <div>
                            <div style="font-weight:600;color:#e2e8f0;"><?php echo e($u->username ?? $u->name); ?></div>
                            <div style="font-size:11px;color:#475569;"><?php echo e($u->email); ?></div>
                        </div>
                    </div>
                </td>
                <td style="padding:12px 16px;">
                    <span class="role-badge role-<?php echo e($u->role); ?>">
                        <?php if($u->role === 'admin'): ?> <i class="fas fa-shield-halved"></i>
                        <?php elseif($u->role === 'editor'): ?> <i class="fas fa-pen"></i>
                        <?php else: ?> <i class="fas fa-eye"></i>
                        <?php endif; ?>
                        <?php echo e($u->role_label); ?>

                    </span>
                </td>
                <td style="padding:12px 16px;">
                    <span class="role-badge <?php echo e($u->is_active ? 'status-on' : 'status-off'); ?>">
                        <i class="fas fa-circle" style="font-size:7px;"></i>
                        <?php echo e($u->is_active ? 'نشط' : 'معطّل'); ?>

                    </span>
                </td>
                <td style="padding:12px 16px;color:#475569;font-size:12px;">
                    <?php echo e($u->created_at?->format('Y-m-d') ?? '—'); ?>

                </td>
                <td style="padding:12px 16px;text-align:center;">
                    <div style="display:flex;justify-content:center;gap:6px;">
                        <a href="<?php echo e(route('admin.users.edit', $u)); ?>" class="ibtn" title="تعديل" style="background:rgba(124,58,237,.12);color:#a78bfa;">
                            <i class="fas fa-pen"></i>
                        </a>
                        <?php if($u->id !== session('admin_user_id')): ?>
                        <form method="POST" action="<?php echo e(route('admin.users.destroy', $u)); ?>" style="display:inline;" onsubmit="return confirm('حذف المستخدم <?php echo e(addslashes($u->username)); ?>؟')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="ibtn" title="حذف" style="background:rgba(239,68,68,.1);color:#f87171;">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" style="padding:32px;text-align:center;color:#334155;">لا يوجد مستخدمون حتى الآن.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\StreamHost\resources\views/admin/users/index.blade.php ENDPATH**/ ?>