<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول — StreamHost</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>body { background: #0f0f1a; font-family: 'Segoe UI', sans-serif; }</style>
</head>
<body class="min-h-screen flex items-center justify-center text-white">
<div class="w-full max-w-sm">
    <div class="text-center mb-8">
        <div class="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
        </div>
        <h1 class="text-2xl font-bold">StreamHost</h1>
        <p class="text-gray-400 text-sm mt-1">لوحة تحكم البث</p>
    </div>

    <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)" class="rounded-2xl p-8">
        <form method="POST" action="<?php echo e(route('admin.login.post')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
            <div class="mb-4 bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg px-4 py-3 text-sm">
                <?php echo e($errors->first()); ?>

            </div>
            <?php endif; ?>
            <div class="space-y-4">
                <div>
                    <label class="block text-sm text-gray-400 mb-1.5">اسم المستخدم</label>
                    <input name="username" type="text" required autocomplete="username"
                           value="<?php echo e(old('username')); ?>"
                           class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-purple-500">
                </div>
                <div>
                    <label class="block text-sm text-gray-400 mb-1.5">كلمة المرور</label>
                    <input name="password" type="password" required autocomplete="current-password"
                           class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-purple-500">
                </div>
                <button type="submit"
                        class="w-full bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-lg font-medium transition">
                    دخول
                </button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\StreamHost\resources\views/admin/login.blade.php ENDPATH**/ ?>