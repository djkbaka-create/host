<?php $__env->startSection('title', $user ? 'تعديل مستخدم' : 'مستخدم جديد'); ?>

<?php $__env->startSection('content'); ?>
<div class="topbar">
    <div>
        <h1 style="font-size:17px;font-weight:700;margin:0;"><?php echo e($user ? 'تعديل مستخدم' : 'مستخدم جديد'); ?></h1>
        <div style="font-size:11px;color:#334155;margin-top:2px;">
            <a href="<?php echo e(route('admin.users.index')); ?>" style="color:#7c3aed;text-decoration:none;">المستخدمون</a>
            › <?php echo e($user ? $user->username : 'جديد'); ?>

        </div>
    </div>
</div>

<div class="card" style="max-width:540px;padding:24px;">
    <?php if($errors->any()): ?>
    <div class="alert-err mb-4"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div>• <?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e($user ? route('admin.users.update', $user) : route('admin.users.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($user): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <div style="display:grid;gap:14px;">

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div>
                    <label class="field-label">اسم المستخدم *</label>
                    <input name="username" type="text" required value="<?php echo e(old('username', $user?->username)); ?>"
                           class="inp" placeholder="admin" autocomplete="username">
                </div>
                <div>
                    <label class="field-label">الاسم الكامل *</label>
                    <input name="name" type="text" required value="<?php echo e(old('name', $user?->name)); ?>"
                           class="inp" placeholder="Ahmed Ali">
                </div>
            </div>

            <div>
                <label class="field-label">البريد الإلكتروني *</label>
                <input name="email" type="email" required value="<?php echo e(old('email', $user?->email)); ?>"
                       class="inp" placeholder="user@example.com" autocomplete="email">
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div>
                    <label class="field-label">
                        كلمة المرور <?php echo e($user ? '(اتركها فارغة لعدم التغيير)' : '*'); ?>

                    </label>
                    <input name="password" type="password"
                           <?php echo e($user ? '' : 'required'); ?>

                           minlength="8"
                           class="inp" placeholder="••••••••" autocomplete="new-password">
                </div>
                <div>
                    <label class="field-label">تأكيد كلمة المرور</label>
                    <input name="password_confirmation" type="password"
                           class="inp" placeholder="••••••••" autocomplete="new-password">
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div>
                    <label class="field-label">الدور *</label>
                    <select name="role" class="inp" style="cursor:pointer;"
                            <?php echo e(($user && $user->id === session('admin_user_id')) ? 'disabled' : ''); ?>>
                        <option value="admin"  <?php echo e(old('role', $user?->role) === 'admin'  ? 'selected' : ''); ?>>
                            مدير — وصول كامل
                        </option>
                        <option value="editor" <?php echo e(old('role', $user?->role) === 'editor' ? 'selected' : ''); ?>>
                            محرر — رفع وإدارة فيديوهات
                        </option>
                        <option value="viewer" <?php echo e(old('role', $user?->role) === 'viewer' ? 'selected' : ''); ?>>
                            مشاهد — عرض فقط
                        </option>
                    </select>
                    <?php if($user && $user->id === session('admin_user_id')): ?>
                    <input type="hidden" name="role" value="<?php echo e($user->role); ?>">
                    <p style="font-size:11px;color:#475569;margin-top:4px;">لا يمكنك تغيير دورك الخاص.</p>
                    <?php endif; ?>
                </div>
                <div>
                    <label class="field-label">الحالة</label>
                    <label style="display:flex;align-items:center;gap:10px;cursor:pointer;margin-top:10px;">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" value="1"
                               style="width:16px;height:16px;accent-color:#7c3aed;cursor:pointer;"
                               <?php echo e((old('is_active', $user?->is_active ?? true) ? 'checked' : '')); ?>

                               <?php echo e(($user && $user->id === session('admin_user_id')) ? 'disabled' : ''); ?>>
                        <span style="color:#cbd5e1;font-size:13px;">حساب نشط</span>
                    </label>
                    <?php if($user && $user->id === session('admin_user_id')): ?>
                    <input type="hidden" name="is_active" value="1">
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <div style="display:flex;gap:10px;margin-top:20px;">
            <button type="submit" class="btn-primary">
                <i class="fas fa-save"></i> <?php echo e($user ? 'حفظ التعديلات' : 'إنشاء المستخدم'); ?>

            </button>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn-ghost">إلغاء</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\StreamHost\resources\views/admin/users/form.blade.php ENDPATH**/ ?>