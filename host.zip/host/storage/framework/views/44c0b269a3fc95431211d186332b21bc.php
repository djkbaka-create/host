<?php $__env->startSection('title', 'تعديل الفيديو'); ?>
<?php $__env->startSection('breadcrumb', 'StreamHost › إدارة الفيديوهات › ' . $video->title); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .tabs { display:flex; gap:2px; border-bottom:1px solid rgba(255,255,255,.07); padding:0 18px; }
    .tab-btn {
        padding:10px 16px; font-size:13px; color:#475569; cursor:pointer;
        border:none; background:none; border-bottom:2px solid transparent;
        transition:all .15s; white-space:nowrap; margin-bottom:-1px;
    }
    .tab-btn:hover { color:#94a3b8; }
    .tab-btn.active { color:#a78bfa; border-bottom-color:#7c3aed; font-weight:600; }
    .tab-pane { display:none; padding:20px 18px; }
    .tab-pane.active { display:block; }

    .embed-box {
        background: rgba(0,0,0,.4);
        border: 1px solid rgba(255,255,255,.07);
        border-radius: 9px;
        padding: 12px 14px;
        display: flex; gap: 10px; align-items: flex-start;
    }
    .embed-box code { font-size:12px; color:#4ade80; font-family:monospace; word-break:break-all; flex:1; line-height:1.6; }

    /* analytics chart empty state */
    #analyticsChartWrap { min-height: 200px; display:flex; align-items:center; justify-content:center; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('topbar_actions'); ?>
<?php if($video->isReady()): ?>
<a href="/embed/<?php echo e($video->slug); ?>" target="_blank" class="btn-ghost btn-sm" style="font-size:12px;">
    <i class="fas fa-play"></i> تشغيل
</a>
<?php endif; ?>
<a href="<?php echo e(route('admin.videos.index')); ?>" class="btn-ghost btn-sm" style="font-size:12px;">
    <i class="fas fa-arrow-right"></i> العودة
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Video header -->
<div class="card" style="padding:18px;margin-bottom:18px;display:flex;align-items:center;gap:16px;">
    <?php if($video->thumbnail): ?>
    <img src="<?php echo e(Storage::url($video->thumbnail)); ?>" style="width:80px;height:52px;object-fit:cover;border-radius:9px;flex-shrink:0;">
    <?php else: ?>
    <div style="width:80px;height:52px;background:rgba(255,255,255,.05);border-radius:9px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
        <i class="fas fa-film" style="color:#334155;font-size:18px;"></i>
    </div>
    <?php endif; ?>
    <div style="flex:1;min-width:0;">
        <div style="font-size:16px;font-weight:700;color:#f1f5f9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?php echo e($video->title); ?></div>
        <div style="display:flex;gap:14px;margin-top:5px;font-size:11.5px;color:#475569;">
            <span><i class="fas fa-clock" style="margin-left:4px;"></i><?php echo e($video->formatted_duration); ?></span>
            <span><i class="fas fa-hdd" style="margin-left:4px;"></i><?php echo e($video->formatted_size); ?></span>
            <span><i class="fas fa-eye" style="margin-left:4px;"></i><?php echo e(number_format($video->views)); ?> مشاهدة</span>
            <span><i class="fas fa-code-branch" style="margin-left:4px;"></i><?php echo e($video->slug); ?></span>
        </div>
    </div>
    <?php
    $bc = match($video->status) {'ready'=>'b-ready','processing'=>'b-processing','failed'=>'b-failed',default=>'b-pending'};
    $bt = match($video->status) {'ready'=>'جاهز','processing'=>'معالجة','failed'=>'فشل',default=>'انتظار'};
    ?>
    <span class="status-badge <?php echo e($bc); ?>" style="font-size:12px;padding:4px 12px;"><?php echo e($bt); ?></span>
</div>

<!-- Tabs -->
<div class="card" style="overflow:hidden;">
    <div class="tabs">
        <button class="tab-btn active" onclick="switchTab('general',this)">
            <i class="fas fa-sliders" style="margin-left:6px;"></i> الإعدادات
        </button>
        <button class="tab-btn" onclick="switchTab('embed',this)">
            <i class="fas fa-code" style="margin-left:6px;"></i> التضمين
        </button>
        <button class="tab-btn" onclick="switchTab('subtitles',this)">
            <i class="fas fa-closed-captioning" style="margin-left:6px;"></i>
            الترجمات
            <?php if($video->subtitles->count()): ?>
            <span style="background:rgba(139,92,246,.2);color:#a78bfa;font-size:10px;padding:1px 6px;border-radius:99px;font-weight:700;margin-right:4px;"><?php echo e($video->subtitles->count()); ?></span>
            <?php endif; ?>
        </button>
        <button class="tab-btn" onclick="switchTab('analytics',this)" id="analyticsTab">
            <i class="fas fa-chart-line" style="margin-left:6px;"></i> الإحصائيات
        </button>
    </div>

    <!-- ── General Settings ── -->
    <div class="tab-pane active" id="pane-general">
        <form method="POST" action="<?php echo e(route('admin.videos.update', $video)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <?php if($errors->any()): ?>
            <div class="alert-err mb-4">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div>• <?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">
                <div style="grid-column:1/-1;">
                    <label class="field-label">العنوان *</label>
                    <input name="title" type="text" required value="<?php echo e(old('title', $video->title)); ?>" class="inp">
                </div>
                <div style="grid-column:1/-1;">
                    <label class="field-label">الوصف</label>
                    <textarea name="description" rows="2" class="inp" style="resize:vertical;"><?php echo e(old('description', $video->description)); ?></textarea>
                </div>
                <!-- Folder + Tags -->
                <div>
                    <label class="field-label"><i class="fas fa-folder" style="margin-left:5px;color:#60a5fa;font-size:11px;"></i> المجلد</label>
                    <select name="folder_id" class="inp" style="cursor:pointer;">
                        <option value="">— بدون مجلد —</option>
                        <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($f->id); ?>" <?php echo e(old('folder_id', $video->folder_id) == $f->id ? 'selected' : ''); ?>>📁 <?php echo e($f->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="field-label"><i class="fas fa-tags" style="margin-left:5px;color:#a78bfa;font-size:11px;"></i> التاجات</label>
                    <input name="tags_input" type="text" class="inp"
                           placeholder="رياضة, كرة قدم, ..."
                           value="<?php echo e(old('tags_input', $video->tags->pluck('name')->join(', '))); ?>"
                           autocomplete="off">
                    <p style="font-size:10.5px;color:#334155;margin-top:2px;">مفصولة بفاصلة</p>
                </div>

                <div>
                    <label class="field-label">صلاحية الرابط (دقائق)</label>
                    <input name="signed_url_ttl" type="number" value="<?php echo e(old('signed_url_ttl', $video->signed_url_ttl)); ?>" min="5" class="inp">
                </div>
                <!-- Ads managed independently -->
                <div style="grid-column:1/-1;">
                    <p style="font-size:12px;color:#64748b;background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.2);border-radius:9px;padding:11px 13px;margin:0;">
                        <i class="fas fa-rectangle-ad" style="margin-left:6px;color:#a78bfa;"></i>
                        تُدار إعدادات الإعلانات بشكل مستقل من قسم الإعلانات ·
                        <a href="<?php echo e(route('admin.ads.index')); ?>" style="color:#a78bfa;text-decoration:none;font-weight:600;">إدارة الإعلانات ↗</a>
                    </p>
                </div>

            </div>

            <button type="submit" class="btn-primary">
                <i class="fas fa-save"></i> حفظ التغييرات
            </button>
        </form>
    </div>

    <!-- ── Embed ── -->
    <div class="tab-pane" id="pane-embed">
        <?php if($video->isReady()): ?>
        <div style="margin-bottom:18px;">
            <label class="field-label" style="margin-bottom:8px;">كود التضمين (iframe)</label>
            <div class="embed-box">
                <code id="embedCode">&lt;iframe src="<?php echo e(config('app.url')); ?>/embed/<?php echo e($video->slug); ?>" width="960" height="540" frameborder="0" allowfullscreen allow="autoplay"&gt;&lt;/iframe&gt;</code>
                <button onclick="copyText('embedCode')" class="ibtn" style="background:rgba(139,92,246,.1);color:#a78bfa;flex-shrink:0;" title="نسخ">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
        </div>
        <div>
            <label class="field-label" style="margin-bottom:8px;">رابط المشغّل المباشر</label>
            <div class="embed-box">
                <code id="embedUrl"><?php echo e(config('app.url')); ?>/embed/<?php echo e($video->slug); ?></code>
                <button onclick="copyText('embedUrl')" class="ibtn" style="background:rgba(139,92,246,.1);color:#a78bfa;flex-shrink:0;" title="نسخ">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
        </div>
        <div id="copyToast" style="display:none;margin-top:12px;color:#4ade80;font-size:12px;">
            <i class="fas fa-check" style="margin-left:5px;"></i> تم النسخ!
        </div>
        <?php else: ?>
        <div style="text-align:center;padding:40px 0;color:#334155;">
            <i class="fas fa-hourglass-half" style="font-size:2rem;display:block;margin-bottom:10px;opacity:.3;"></i>
            <p style="font-size:13px;">الفيديو لم يكتمل بعد</p>
            <p style="font-size:11px;margin-top:4px;color:#1e293b;">كود التضمين سيظهر عند اكتمال المعالجة</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- ── Subtitles ── -->
    <div class="tab-pane" id="pane-subtitles">
        <?php if($video->subtitles->count()): ?>
        <div style="margin-bottom:16px;">
            <label class="field-label" style="margin-bottom:8px;">الترجمات الحالية</label>
            <div style="display:flex;flex-direction:column;gap:6px;">
                <?php $__currentLoopData = $video->subtitles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:9px 12px;">
                    <div style="font-size:13px;">
                        <span style="color:#e2e8f0;"><?php echo e($sub->label); ?></span>
                        <span style="color:#475569;font-size:11px;margin-right:6px;">(<?php echo e($sub->language); ?>)</span>
                        <?php if($sub->is_default): ?>
                        <span style="font-size:10px;background:rgba(139,92,246,.15);color:#a78bfa;padding:1px 7px;border-radius:99px;">افتراضية</span>
                        <?php endif; ?>
                    </div>
                    <form method="POST" action="<?php echo e(route('admin.subtitles.delete', $sub)); ?>"
                          onsubmit="return confirm('حذف الترجمة؟')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="ibtn" style="background:rgba(239,68,68,.1);color:#f87171;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.videos.update', $video)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <input type="hidden" name="title" value="<?php echo e($video->title); ?>">
            <label class="field-label" style="margin-bottom:8px;">إضافة ترجمات جديدة</label>
            <div id="subtitleRows" style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px;">
                <div class="subtitle-row" style="display:grid;grid-template-columns:2fr 1fr 80px;gap:8px;">
                    <input name="subtitles[]" type="file" accept=".srt,.vtt" class="inp" style="padding:7px 10px;">
                    <input name="subtitle_labels[]" type="text" placeholder="العربية" class="inp">
                    <input name="subtitle_langs[]" type="text" placeholder="ar" maxlength="5" class="inp">
                </div>
            </div>
            <button type="button" onclick="addSubRow()" style="font-size:12px;color:#7c3aed;background:none;border:none;cursor:pointer;margin-bottom:14px;">
                <i class="fas fa-plus" style="margin-left:4px;"></i> إضافة سطر آخر
            </button>
            <br>
            <button type="submit" class="btn-ghost">
                <i class="fas fa-upload"></i> رفع الترجمات
            </button>
        </form>
    </div>

    <!-- ── Analytics ── -->
    <div class="tab-pane" id="pane-analytics">
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px;">
            <div class="card" style="padding:14px 16px;">
                <div style="font-size:10px;color:#475569;text-transform:uppercase;letter-spacing:.07em;margin-bottom:6px;">إجمالي المشاهدات</div>
                <div style="font-size:26px;font-weight:700;color:#f1f5f9;"><?php echo e(number_format($video->views)); ?></div>
            </div>
            <div class="card" style="padding:14px 16px;" id="periodCard">
                <div style="font-size:10px;color:#475569;text-transform:uppercase;letter-spacing:.07em;margin-bottom:6px;">آخر 30 يوم</div>
                <div style="font-size:26px;font-weight:700;color:#a78bfa;" id="periodViews">—</div>
            </div>
            <div class="card" style="padding:14px 16px;">
                <div style="font-size:10px;color:#475569;text-transform:uppercase;letter-spacing:.07em;margin-bottom:6px;">الجودات المتاحة</div>
                <div style="font-size:16px;font-weight:600;color:#60a5fa;margin-top:5px;">
                    <?php echo e($video->qualities ? implode(' / ', $video->qualities) : '—'); ?>

                </div>
            </div>
        </div>

        <div class="card" style="padding:16px 18px;margin-bottom:14px;">
            <div style="font-size:12.5px;font-weight:600;color:#94a3b8;margin-bottom:14px;display:flex;align-items:center;gap:7px;">
                <i class="fas fa-chart-area" style="color:#a78bfa;"></i>
                المشاهدات — آخر 30 يوم
            </div>
            <div id="analyticsChartWrap">
                <div id="analyticsPlaceholder" style="text-align:center;color:#334155;">
                    <i class="fas fa-spinner fa-spin" style="font-size:1.5rem;margin-bottom:8px;display:block;"></i>
                    <p style="font-size:12px;">جاري التحميل...</p>
                </div>
                <canvas id="analyticsChart" style="display:none;max-height:220px;"></canvas>
            </div>
        </div>

        <!-- Top Referrers -->
        <div class="card" style="padding:16px 18px;" id="referrersCard" style="display:none;">
            <div style="font-size:12.5px;font-weight:600;color:#94a3b8;margin-bottom:12px;display:flex;align-items:center;gap:7px;">
                <i class="fas fa-arrow-pointer" style="color:#60a5fa;"></i>
                أبرز المصادر — آخر 30 يوم
            </div>
            <div id="referrersList">
                <p style="font-size:12px;color:#334155;text-align:center;padding:14px 0;">
                    <i class="fas fa-spinner fa-spin" style="margin-left:5px;"></i> جاري التحميل...
                </p>
            </div>
        </div>
    </div>
</div>

<div id="toast" style="position:fixed;bottom:22px;left:22px;background:#16a34a;color:#fff;padding:8px 16px;border-radius:9px;font-size:13px;display:none;align-items:center;gap:7px;z-index:99;">
    <i class="fas fa-check"></i> تم النسخ!
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const ANALYTICS_URL = '<?php echo e(route("admin.videos.analytics", $video)); ?>';

// Tab switching
function switchTab(name, btn) {
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('pane-' + name).classList.add('active');
    btn.classList.add('active');
    if (name === 'analytics') loadAnalytics();
}

// Copy
function copyText(id) {
    const text = document.getElementById(id).innerText.trim();
    navigator.clipboard.writeText(text).then(() => {
        const t = document.getElementById('toast');
        t.style.display = 'flex';
        setTimeout(() => t.style.display = 'none', 2200);
    });
}

// Subtitle rows
function addSubRow() {
    const row = document.querySelector('.subtitle-row').cloneNode(true);
    row.querySelectorAll('input').forEach(i => { if (i.type !== 'file') i.value = ''; });
    document.getElementById('subtitleRows').appendChild(row);
}

// Analytics chart
let analyticsLoaded = false;
function loadAnalytics() {
    if (analyticsLoaded) return;
    analyticsLoaded = true;

    fetch(ANALYTICS_URL, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(r => r.json())
        .then(d => {
            document.getElementById('periodViews').textContent = d.period_views.toLocaleString('ar');
            document.getElementById('analyticsPlaceholder').style.display = 'none';

            const canvas = document.getElementById('analyticsChart');

            if (d.period_views === 0) {
                document.getElementById('analyticsPlaceholder').innerHTML =
                    '<i class="fas fa-chart-line" style="font-size:2rem;display:block;margin-bottom:8px;opacity:.25;"></i>' +
                    '<p style="font-size:12px;">لا توجد مشاهدات في آخر 30 يوم</p>';
                document.getElementById('analyticsPlaceholder').style.display = 'block';
            } else {
                canvas.style.display = 'block';
                const ctx = canvas.getContext('2d');
                const gradient = ctx.createLinearGradient(0, 0, 0, 220);
                gradient.addColorStop(0, 'rgba(139,92,246,.35)');
                gradient.addColorStop(1, 'rgba(139,92,246,.01)');
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: d.labels,
                        datasets: [{
                            label: 'مشاهدات',
                            data: d.data,
                            backgroundColor: gradient,
                            borderColor: '#8b5cf6',
                            borderWidth: 1,
                            borderRadius: 4,
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: '#1a1a2e',
                                titleColor: '#94a3b8',
                                bodyColor: '#a78bfa',
                                borderColor: 'rgba(139,92,246,.3)',
                                borderWidth: 1,
                                padding: 10,
                                callbacks: { label: ctx => ' ' + ctx.parsed.y.toLocaleString('ar') + ' مشاهدة' }
                            },
                        },
                        scales: {
                            x: { grid: { color: 'rgba(255,255,255,.04)' }, ticks: { color: '#475569', font: { size: 10 }, maxTicksLimit: 10 } },
                            y: { grid: { color: 'rgba(255,255,255,.04)' }, ticks: { color: '#475569', font: { size: 10 }, precision: 0 }, beginAtZero: true }
                        }
                    }
                });
            }

            // Top referrers
            const card = document.getElementById('referrersCard');
            card.style.display = 'block';
            const list = document.getElementById('referrersList');
            if (!d.top_referrers || d.top_referrers.length === 0) {
                list.innerHTML = '<p style="font-size:12px;color:#334155;text-align:center;padding:10px 0;">لا توجد بيانات مصادر بعد</p>';
            } else {
                const maxCount = d.top_referrers[0].count;
                list.innerHTML = d.top_referrers.map((r, i) => `
                    <div style="display:flex;align-items:center;gap:10px;padding:7px 0;${i > 0 ? 'border-top:1px solid rgba(255,255,255,.05);' : ''}">
                        <span style="width:20px;height:20px;border-radius:50%;background:rgba(255,255,255,.06);font-size:10px;color:#475569;display:flex;align-items:center;justify-content:center;flex-shrink:0;">${i+1}</span>
                        <span style="flex:1;font-size:12px;color:#94a3b8;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${r.referer || 'مباشر'}</span>
                        <div style="width:80px;background:rgba(255,255,255,.05);border-radius:99px;height:5px;overflow:hidden;flex-shrink:0;">
                            <div style="height:100%;background:#7c3aed;border-radius:99px;width:${Math.round((r.count/maxCount)*100)}%;"></div>
                        </div>
                        <span style="font-size:11px;color:#60a5fa;font-weight:600;flex-shrink:0;min-width:28px;text-align:left;">${r.count}</span>
                    </div>
                `).join('');
            }
        })
        .catch(() => {
            document.getElementById('analyticsPlaceholder').innerHTML = '<p style="color:#f87171;font-size:12px;">تعذّر تحميل البيانات</p>';
        });
}

// Auto-load analytics if tab=analytics in URL
if (window.location.hash === '#analytics') {
    const btn = document.getElementById('analyticsTab');
    if (btn) switchTab('analytics', btn);
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\StreamHost\resources\views/admin/videos/edit.blade.php ENDPATH**/ ?>