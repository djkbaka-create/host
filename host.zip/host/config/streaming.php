<?php
return [
    'admin_username'      => env('ADMIN_USERNAME', 'admin'),
    'admin_password_hash' => env('ADMIN_PASSWORD_HASH', ''),
    'allowed_domain'      => env('ALLOWED_DOMAIN', 'cimamix.net'),
    'sign_key'            => env('STREAMING_SIGN_KEY', env('APP_KEY', 'changeme')),
    'cloud_disk'          => env('CLOUD_DISK', null),
    'embed_fallback_url' => env('EMBED_FALLBACK_URL', null),
];
