<?php
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'admin.auth' => \App\Http\Middleware\AdminAuth::class,
            'allow.embed' => \App\Http\Middleware\AllowEmbed::class,
            'role'       => \App\Http\Middleware\RequireRole::class,
        ]);

        // Trust all proxies (Replit proxy)
        $middleware->trustProxies(at: '*');

        // Only exclude the login form — all other admin mutations use @csrf
        $middleware->validateCsrfTokens(except: [
            'admin/login',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })
    ->create();
