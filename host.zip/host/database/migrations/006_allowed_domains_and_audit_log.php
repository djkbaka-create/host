<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('videos', function (Blueprint $table) {
            $table->text('allowed_domains')->nullable()->after('allowed_domain');
        });

        DB::table('videos')->whereNotNull('allowed_domain')
            ->where('allowed_domain', '!=', '')
            ->get()->each(function ($video) {
                DB::table('videos')->where('id', $video->id)->update([
                    'allowed_domains' => json_encode([trim($video->allowed_domain)]),
                ]);
            });

        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('action', 80);
            $table->string('target_type', 40)->nullable();
            $table->unsignedBigInteger('target_id')->nullable();
            $table->string('ip', 45)->nullable();
            $table->text('details')->nullable();
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::table('videos', function (Blueprint $table) {
            $table->dropColumn('allowed_domains');
        });
        Schema::dropIfExists('audit_logs');
    }
};
