<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void {
        Schema::create('ad_configs', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('vast_url')->nullable();
            $table->text('popunder_script')->nullable();
            $table->boolean('popunder_on_play')->default(true);
            $table->boolean('popunder_on_seek')->default(false);
            $table->integer('popunder_delay')->default(0);
            $table->integer('ad_timer_seconds')->default(0);
            $table->boolean('is_global')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // seed the default global config
        DB::table('ad_configs')->insert([
            'name'              => 'الإعداد العام',
            'vast_url'          => null,
            'popunder_script'   => null,
            'popunder_on_play'  => 1,
            'popunder_on_seek'  => 0,
            'popunder_delay'    => 0,
            'ad_timer_seconds'  => 0,
            'is_global'         => 1,
            'is_active'         => 1,
            'created_at'        => now(),
            'updated_at'        => now(),
        ]);

        // add ad_config_id FK to videos
        Schema::table('videos', function (Blueprint $table) {
            $table->foreignId('ad_config_id')->nullable()->after('views')
                  ->constrained('ad_configs')->nullOnDelete();
        });
    }

    public function down(): void {
        Schema::table('videos', function (Blueprint $table) {
            $table->dropForeign(['ad_config_id']);
            $table->dropColumn('ad_config_id');
        });
        Schema::dropIfExists('ad_configs');
    }
};
