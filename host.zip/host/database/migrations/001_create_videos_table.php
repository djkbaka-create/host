<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('videos', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('slug')->unique();
            $table->enum('source_type', ['upload', 'remote'])->default('upload');
            $table->string('source_url')->nullable();
            $table->string('original_file')->nullable();
            $table->enum('status', ['pending', 'processing', 'ready', 'failed'])->default('pending');
            $table->integer('duration')->nullable();
            $table->bigInteger('file_size')->nullable();
            $table->string('thumbnail')->nullable();
            $table->json('qualities')->nullable();
            $table->string('hls_path')->nullable();
            $table->string('storage_disk')->default('local');
            $table->string('vast_url')->nullable();
            $table->text('popunder_script')->nullable();
            $table->string('allowed_domain')->nullable();
            $table->integer('signed_url_ttl')->default(120);
            $table->integer('views')->default(0);
            $table->timestamps();
        });

        Schema::create('subtitles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('video_id')->constrained()->cascadeOnDelete();
            $table->string('label');
            $table->string('language', 10);
            $table->string('file_path');
            $table->boolean('is_default')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('subtitles');
        Schema::dropIfExists('videos');
    }
};
