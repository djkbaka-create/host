<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        // إعادة بناء الجدول لدعم تتبع كل مشاهدة منفردة مع ip_hash و referer
        Schema::dropIfExists('video_views');
        Schema::create('video_views', function (Blueprint $table) {
            $table->id();
            $table->foreignId('video_id')->constrained()->cascadeOnDelete();
            $table->date('date')->index();
            $table->string('ip_hash', 64);
            $table->string('referer', 500)->nullable();
            $table->timestamp('viewed_at')->useCurrent();
        });
    }

    public function down(): void {
        Schema::dropIfExists('video_views');
        Schema::create('video_views', function (Blueprint $table) {
            $table->id();
            $table->foreignId('video_id')->constrained()->cascadeOnDelete();
            $table->date('date');
            $table->unsignedInteger('count')->default(0);
            $table->unique(['video_id', 'date']);
        });
    }
};
