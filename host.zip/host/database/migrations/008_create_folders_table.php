<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('folders', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->timestamps();
        });

        Schema::table('videos', function (Blueprint $table) {
            $table->foreignId('folder_id')->nullable()->after('ad_config_id')
                  ->constrained('folders')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('videos', fn($t) => $t->dropConstrainedForeignId('folder_id'));
        Schema::dropIfExists('folders');
    }
};
