<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('username')->nullable()->after('id');
            $table->string('role')->default('admin')->after('password');
            $table->boolean('is_active')->default(true)->after('role');
        });

        if (DB::table('users')->count() === 0) {
            $initialPassword = env('ADMIN_INITIAL_PASSWORD');
            if (!$initialPassword) {
                $initialPassword = \Illuminate\Support\Str::random(20);
                file_put_contents(
                    storage_path('admin_initial_password.txt'),
                    "Generated admin password (delete after first login): {$initialPassword}\n"
                );
            }
            DB::table('users')->insert([
                'username'   => env('ADMIN_USERNAME', 'admin'),
                'name'       => 'Admin',
                'email'      => env('ADMIN_EMAIL', 'admin@streamhost.local'),
                'password'   => Hash::make($initialPassword),
                'role'       => 'admin',
                'is_active'  => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        } else {
            DB::table('users')->whereNull('username')->update([
                'username'  => config('streaming.admin_username', 'admin'),
                'role'      => 'admin',
                'is_active' => 1,
            ]);
        }
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['username', 'role', 'is_active']);
        });
    }
};
