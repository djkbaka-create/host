<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('signed_tokens', function (Blueprint $table) {
            $table->id();
            $table->string('slug', 255)->index();
            $table->char('token_hash', 64)->unique();
            $table->timestamp('expires_at');
            $table->boolean('revoked')->default(false);
            $table->string('ip', 45)->nullable();
            $table->timestamp('created_at')->useCurrent();
        });

        Schema::create('global_settings', function (Blueprint $table) {
            $table->string('key', 64)->primary();
            $table->text('value')->nullable();
        });

        DB::table('global_settings')->insert([
            ['key' => 'signed_url_default_ttl', 'value' => '120'],
            ['key' => 'allowed_domains',         'value' => null],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('signed_tokens');
        Schema::dropIfExists('global_settings');
    }
};
