<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Artisan;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // توليد hash لكلمة المرور الافتراضية admin123
        $hash = password_hash('admin123', PASSWORD_BCRYPT);

        // حفظه في .env
        $envPath = base_path('.env');
        $env     = file_get_contents($envPath);

        if (strpos($env, 'ADMIN_PASSWORD_HASH=') !== false) {
            $env = preg_replace('/^ADMIN_PASSWORD_HASH=.*/m', "ADMIN_PASSWORD_HASH={$hash}", $env);
        } else {
            $env .= "\nADMIN_PASSWORD_HASH={$hash}";
        }

        file_put_contents($envPath, $env);

        // توليد مفتاح التوقيع
        $signKey = bin2hex(random_bytes(32));
        if (strpos($env, 'STREAMING_SIGN_KEY=') !== false) {
            $env = preg_replace('/^STREAMING_SIGN_KEY=.*/m', "STREAMING_SIGN_KEY={$signKey}", $env);
        } else {
            $env .= "\nSTREAMING_SIGN_KEY={$signKey}";
        }
        file_put_contents($envPath, $env);

        Artisan::call('config:clear');

        $this->command->info('✅ Admin account created:');
        $this->command->info('   Username: admin');
        $this->command->info('   Password: admin123  ← غيّرها فوراً!');
    }
}
