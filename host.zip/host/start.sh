#!/bin/bash
set -e
cd /home/runner/workspace/StreamHost

# Start queue worker in background
php artisan queue:work --daemon --timeout=7200 --tries=2 --memory=512 &
QUEUE_PID=$!

# Trap to kill queue worker on exit
trap "kill $QUEUE_PID 2>/dev/null" EXIT

# Start web server (foreground)
php -d upload_max_filesize=2G \
    -d post_max_size=2G \
    -d memory_limit=512M \
    -d max_execution_time=0 \
    artisan serve --host=0.0.0.0 --port=8000
