@extends('admin.layout')
@section('title', 'رفع فيديو جديد')
@section('breadcrumb', 'StreamHost › رفع فيديو جديد')

@push('styles')
<style>
    .src-option input[type="radio"] { display:none; }
    .src-label {
        display: block;
        text-align: center;
        padding: 14px 10px;
        border-radius: 10px;
        border: 1px solid rgba(255,255,255,.1);
        color: #475569;
        font-size: 13px;
        cursor: pointer;
        transition: all .15s;
    }
    .src-option input[type="radio"]:checked + .src-label {
        border-color: rgba(124,58,237,.6);
        background: rgba(124,58,237,.12);
        color: #a78bfa;
    }
    .src-label:hover { border-color: rgba(139,92,246,.35); color: #94a3b8; }
    #dropZone {
        border: 2px dashed rgba(255,255,255,.1);
        border-radius: 12px;
        padding: 36px 20px;
        text-align: center;
        cursor: pointer;
        transition: border-color .15s, background .15s;
    }
    #dropZone:hover, #dropZone.drag-over { border-color: #7c3aed; background: rgba(124,58,237,.05); }
</style>
@endpush

@section('content')
<div style="max-width:640px;">
<div class="card" style="padding:24px;">
    <form id="uploadForm" enctype="multipart/form-data">
        @csrf

        <div id="validationError" class="alert-err mb-4" style="display:none;"></div>

        <!-- Title -->
        <div style="margin-bottom:14px;">
            <label class="field-label">عنوان الفيديو *</label>
            <input name="title" id="titleInput" type="text" required class="inp" placeholder="أدخل عنوان الفيديو">
        </div>

        <!-- Description -->
        <div style="margin-bottom:14px;">
            <label class="field-label">الوصف <span style="font-weight:400;text-transform:none;font-size:10px;">(اختياري)</span></label>
            <textarea name="description" rows="2" class="inp" style="resize:vertical;"></textarea>
        </div>

        <div style="margin-bottom:14px;">
            <label class="field-label">TMDB ID <span style="font-weight:400;text-transform:none;font-size:10px;">(اختياري)</span></label>
            <input name="tmdb_id" type="number" min="1" class="inp" value="{{ old('tmdb_id') }}">
            <p style="font-size:10.5px;color:#334155;margin-top:2px;">استخدم هذا الحقل لتوافق الفيديو مع TMDB.</p>
        </div>

        <!-- Source type -->
        <div style="margin-bottom:14px;">
            <label class="field-label">مصدر الفيديو *</label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                <div class="src-option">
                    <input type="radio" name="source_type" id="src_upload" value="upload" checked>
                    <label for="src_upload" class="src-label">
                        <i class="fas fa-upload" style="font-size:1.4rem;display:block;margin-bottom:6px;"></i>
                        رفع من الجهاز
                    </label>
                </div>
                <div class="src-option">
                    <input type="radio" name="source_type" id="src_remote" value="remote">
                    <label for="src_remote" class="src-label">
                        <i class="fas fa-link" style="font-size:1.4rem;display:block;margin-bottom:6px;"></i>
                        جلب من رابط
                    </label>
                </div>
            </div>
        </div>

        <!-- Upload zone -->
        <div id="uploadSection" style="margin-bottom:14px;">
            <div id="dropZone" onclick="document.getElementById('fileInput').click()">
                <i class="fas fa-cloud-upload-alt" style="font-size:2rem;color:#334155;display:block;margin-bottom:10px;"></i>
                <p style="font-size:13.5px;color:#64748b;">اسحب الملف هنا أو <span style="color:#7c3aed;font-weight:600;">اختر من جهازك</span></p>
                <p style="font-size:11.5px;color:#334155;margin-top:5px;">MP4, MKV, AVI, MOV, WebM — حتى 2GB</p>
            </div>
            <input id="fileInput" name="file" type="file" accept="video/*" style="display:none;" onchange="onFileSelect(this)">
            <div id="fileName" style="display:none;margin-top:8px;color:#a78bfa;font-size:12.5px;display:flex;align-items:center;gap:6px;">
                <i class="fas fa-file-video"></i>
                <span id="fileNameText"></span>
            </div>
        </div>

        <!-- Remote URL -->
        <div id="remoteSection" style="margin-bottom:14px;display:none;">
            <label class="field-label">رابط الفيديو المباشر</label>
            <input name="source_url" type="url" placeholder="https://example.com/video.mp4"
                   class="inp" style="font-family:monospace;">
        </div>

        <!-- Divider -->
        <div style="height:1px;background:rgba(255,255,255,.07);margin:18px 0;"></div>

        <!-- Folder + Tags -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
            <div>
                <label class="field-label"><i class="fas fa-folder" style="margin-left:5px;color:#60a5fa;font-size:11px;"></i> المجلد</label>
                <select name="folder_id" class="inp" style="cursor:pointer;">
                    <option value="">— بدون مجلد —</option>
                    @foreach($folders as $f)
                    <option value="{{ $f->id }}" {{ old('folder_id') == $f->id ? 'selected' : '' }}>📁 {{ $f->name }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="field-label"><i class="fas fa-tags" style="margin-left:5px;color:#a78bfa;font-size:11px;"></i> التاجات</label>
                <input name="tags_input" type="text" class="inp"
                       placeholder="رياضة, كرة قدم, ..."
                       value="{{ old('tags_input') }}"
                       autocomplete="off">
                <p style="font-size:10.5px;color:#334155;margin-top:2px;">مفصولة بفاصلة</p>
            </div>
        </div>

        <button type="submit" id="submitBtn" class="btn-primary" style="width:100%;justify-content:center;padding:12px;">
            <i class="fas fa-upload"></i> رفع وبدء المعالجة
        </button>
    </form>
</div>
</div>

<!-- Overlay -->
<div id="overlay" style="position:fixed;inset:0;z-index:60;display:none;flex-direction:column;align-items:center;justify-content:center;background:rgba(8,8,18,.93);backdrop-filter:blur(10px);">
    <div style="width:100%;max-width:360px;margin:0 16px;">
        <div style="text-align:center;margin-bottom:28px;">
            <div id="overlaySpinner" style="width:64px;height:64px;margin:0 auto 16px;">
                <div style="width:56px;height:56px;border:4px solid rgba(139,92,246,.3);border-top-color:#7c3aed;border-radius:50%;animation:spin 0.8s linear infinite;"></div>
            </div>
            <p id="overlayTitle" style="color:#f1f5f9;font-size:17px;font-weight:600;margin-bottom:5px;">جاري رفع الفيديو...</p>
            <p id="overlaySubtitle" style="color:#64748b;font-size:13px;">لا تغلق هذه النافذة</p>
        </div>

        <!-- Upload progress -->
        <div id="uploadProgressWrap" style="margin-bottom:16px;">
            <div style="display:flex;justify-content:space-between;font-size:12px;color:#64748b;margin-bottom:7px;">
                <span>رفع الملف</span>
                <span id="uploadPercent">0%</span>
            </div>
            <div style="background:rgba(255,255,255,.06);border-radius:99px;height:6px;overflow:hidden;">
                <div id="uploadBar" style="background:linear-gradient(90deg,#7c3aed,#a855f7);height:100%;border-radius:99px;transition:width .2s;width:0%;"></div>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:11px;color:#334155;margin-top:5px;">
                <span id="uploadSpeed"></span>
                <span id="uploadEta"></span>
            </div>
        </div>

        <!-- Processing progress -->
        <div id="processProgressWrap" style="display:none;margin-bottom:16px;">
            <div style="display:flex;justify-content:space-between;font-size:12px;color:#64748b;margin-bottom:7px;">
                <span>معالجة FFmpeg</span>
                <span style="color:#facc15;animation:blink 1.4s infinite;">جارٍ...</span>
            </div>
            <div style="background:rgba(255,255,255,.06);border-radius:99px;height:6px;overflow:hidden;">
                <div style="background:linear-gradient(90deg,#d97706,#f59e0b);height:100%;border-radius:99px;width:100%;animation:blink 1.4s infinite;"></div>
            </div>
            <p style="font-size:11px;color:#334155;text-align:center;margin-top:6px;">تحويل HLS بجودات متعددة</p>
        </div>

        <!-- Success -->
        <div id="successWrap" style="display:none;text-align:center;">
            <div style="width:56px;height:56px;background:rgba(34,197,94,.15);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;">
                <i class="fas fa-check" style="color:#4ade80;font-size:22px;"></i>
            </div>
            <p style="color:#4ade80;font-weight:600;font-size:15px;margin-bottom:4px;">الفيديو جاهز!</p>
            <p style="color:#475569;font-size:12px;">جاري التحويل لقائمة الفيديوهات...</p>
        </div>
    </div>
</div>

@push('scripts')
<style>
@keyframes spin { to { transform: rotate(360deg); } }
</style>
<script>
const CSRF = document.querySelector('input[name="_token"]').value;

// Source toggle
document.querySelectorAll('input[name="source_type"]').forEach(r => {
    r.addEventListener('change', function() {
        document.getElementById('uploadSection').style.display = this.value === 'upload' ? 'block' : 'none';
        document.getElementById('remoteSection').style.display = this.value === 'remote' ? 'block' : 'none';
    });
});

// Drag & drop
const dropZone = document.getElementById('dropZone');
dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) {
        document.getElementById('fileInput').files = e.dataTransfer.files;
        onFileSelect({ files: [file] });
    }
});

function onFileSelect(input) {
    const f = input.files[0];
    if (!f) return;
    const mb = (f.size / 1024 / 1024).toFixed(1);
    document.getElementById('fileNameText').textContent = f.name + ' (' + mb + ' MB)';
    document.getElementById('fileName').style.display = 'flex';
}

function showOverlay() {
    document.getElementById('overlay').style.display = 'flex';
}
function hideOverlay() {
    document.getElementById('overlay').style.display = 'none';
}

let uploadStartTime;

function updateUploadProgress(loaded, total) {
    const pct = Math.round((loaded / total) * 100);
    document.getElementById('uploadBar').style.width = pct + '%';
    document.getElementById('uploadPercent').textContent = pct + '%';
    const elapsed = (Date.now() - uploadStartTime) / 1000;
    if (elapsed > 0.5) {
        const speed = loaded / elapsed;
        const remaining = (total - loaded) / speed;
        document.getElementById('uploadSpeed').textContent = formatBytes(speed) + '/s';
        document.getElementById('uploadEta').textContent = remaining > 0 ? 'متبقي ' + formatTime(remaining) : '';
    }
}

function formatBytes(b) {
    return b > 1048576 ? (b/1048576).toFixed(1) + ' MB' : (b/1024).toFixed(0) + ' KB';
}
function formatTime(s) {
    return s < 60 ? Math.round(s) + ' ث' : Math.round(s/60) + ' د';
}

function switchToProcessing(videoId) {
    document.getElementById('uploadProgressWrap').style.display = 'none';
    document.getElementById('processProgressWrap').style.display = 'block';
    document.getElementById('overlayTitle').textContent = 'FFmpeg يعالج الفيديو في الخلفية...';
    document.getElementById('overlaySubtitle').textContent = 'يمكنك متابعة العمل — ستُنقل تلقائياً عند الانتهاء';
    pollStatus(videoId);
}

function pollStatus(videoId) {
    const iv = setInterval(async () => {
        try {
            const r = await fetch('/admin/videos/' + videoId + '/status', { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const d = await r.json();
            if (d.status === 'ready') {
                clearInterval(iv);
                document.getElementById('processProgressWrap').style.display = 'none';
                document.getElementById('successWrap').style.display = 'block';
                document.getElementById('overlaySpinner').style.display = 'none';
                document.getElementById('overlayTitle').textContent = '';
                document.getElementById('overlaySubtitle').textContent = '';
                setTimeout(() => { window.location.href = '/admin/videos'; }, 1600);
            } else if (d.status === 'failed') {
                clearInterval(iv);
                hideOverlay();
                showErr('فشلت المعالجة — تحقق من الفيديو وأعد المحاولة');
                document.getElementById('submitBtn').disabled = false;
            }
        } catch(e) {}
    }, 3000);
}

function showErr(msg) {
    const e = document.getElementById('validationError');
    e.textContent = msg;
    e.style.display = 'flex';
}

document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const title = document.getElementById('titleInput').value.trim();
    if (!title) { showErr('يرجى إدخال عنوان الفيديو'); return; }

    const src = document.querySelector('input[name="source_type"]:checked').value;
    const fi  = document.getElementById('fileInput');
    if (src === 'upload' && (!fi.files || !fi.files[0])) { showErr('يرجى اختيار ملف فيديو'); return; }

    document.getElementById('validationError').style.display = 'none';
    document.getElementById('submitBtn').disabled = true;
    showOverlay();

    const fd = new FormData(this);
    fd.append('_token', CSRF);
    uploadStartTime = Date.now();

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '{{ route("admin.videos.store") }}');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    xhr.upload.addEventListener('progress', e => {
        if (e.lengthComputable) updateUploadProgress(e.loaded, e.total);
    });
    xhr.upload.addEventListener('load', () => {
        document.getElementById('uploadBar').style.width = '100%';
        document.getElementById('uploadPercent').textContent = '100%';
        document.getElementById('overlayTitle').textContent = 'اكتمل الرفع — جاري بدء المعالجة...';
    });
    xhr.addEventListener('load', () => {
        try {
            const d = JSON.parse(xhr.responseText);
            if (xhr.status === 200 || xhr.status === 201) {
                if (d.success) switchToProcessing(d.video_id);
                else { hideOverlay(); showErr(d.message || 'حدث خطأ'); document.getElementById('submitBtn').disabled = false; }
            } else if (xhr.status === 422) {
                hideOverlay();
                const errors = d.errors || {};
                const errMsg = Object.values(errors)[0]?.[0] || d.message || 'خطأ في التحقق من البيانات';
                showErr(errMsg);
                document.getElementById('submitBtn').disabled = false;
            } else {
                hideOverlay();
                showErr(d.message || 'حدث خطأ');
                document.getElementById('submitBtn').disabled = false;
            }
        } catch(ex) { hideOverlay(); showErr('حدث خطأ في الاتصال'); document.getElementById('submitBtn').disabled = false; }
    });
    xhr.addEventListener('error', () => { hideOverlay(); showErr('فشل الاتصال بالسيرفر'); document.getElementById('submitBtn').disabled = false; });
    xhr.send(fd);
});
</script>
@endpush
@endsection
