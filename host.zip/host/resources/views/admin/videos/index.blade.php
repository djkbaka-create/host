@extends('admin.layout')
@section('title', 'إدارة الفيديوهات')
@section('breadcrumb', 'StreamHost › إدارة الفيديوهات')

@section('topbar_actions')
<a href="{{ route('admin.videos.create') }}" class="btn-primary btn-sm">
    <i class="fas fa-plus"></i> رفع فيديو
</a>
@endsection

@push('styles')
<style>
    .filter-inp {
        background: rgba(10,10,22,.9);
        border: 1px solid rgba(255,255,255,.1);
        border-radius: 8px;
        padding: 7px 11px;
        color: #e2e8f0;
        font-size: 12.5px;
        outline: none;
        transition: border-color .15s;
    }
    .filter-inp:focus { border-color: #7c3aed; }
    .filter-inp::placeholder { color: #334155; }
    .vrow { transition: background .12s; }
    .vrow:hover { background: rgba(255,255,255,.025); }
    .vrow + .vrow { border-top: 1px solid rgba(255,255,255,.05); }
    .col-th { font-size: 10px; text-transform: uppercase; letter-spacing: .07em; color: #334155; font-weight: 700; padding: 10px 16px; }
    .col-td { padding: 10px 16px; font-size: 13px; color: #94a3b8; }

    .tag-chip {
        display: inline-flex; align-items: center;
        background: rgba(139,92,246,.12);
        color: #a78bfa;
        font-size: 10px;
        padding: 1px 7px;
        border-radius: 99px;
        text-decoration: none;
        transition: background .12s;
        white-space: nowrap;
    }
    .tag-chip:hover { background: rgba(139,92,246,.25); }
    .folder-chip {
        display: inline-flex; align-items: center; gap: 4px;
        background: rgba(96,165,250,.1);
        color: #60a5fa;
        font-size: 10px;
        padding: 1px 7px;
        border-radius: 6px;
        text-decoration: none;
        white-space: nowrap;
    }

    .adv-filter-panel { display: none; }
    .adv-filter-panel.open { display: block; }

    /* Bulk bar */
    #bulkBar {
        position: sticky; bottom: 16px; z-index: 50;
        background: rgba(17,17,35,.95);
        border: 1px solid rgba(139,92,246,.4);
        border-radius: 12px;
        padding: 11px 16px;
        display: none;
        align-items: center;
        gap: 10px;
        backdrop-filter: blur(12px);
        box-shadow: 0 4px 24px rgba(0,0,0,.5);
        margin-top: 12px;
    }
    #bulkBar.visible { display: flex; }
    .vrow.selected { background: rgba(124,58,237,.06); }
    .vrow.selected input[type=checkbox] { accent-color: #7c3aed; }
</style>
@endpush

@section('content')

@if(session('success'))
<div class="alert-ok mb-4"><i class="fas fa-check-circle" style="margin-left:6px;"></i>{{ session('success') }}</div>
@endif

<!-- Basic Filters Row -->
<form method="GET" id="filterForm" style="margin-bottom:10px;">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
        <div style="position:relative;flex:0 0 auto;">
            <i class="fas fa-search" style="position:absolute;right:9px;top:50%;transform:translateY(-50%);color:#334155;font-size:11px;pointer-events:none;"></i>
            <input name="q" value="{{ request('q') }}" placeholder="بحث بالعنوان..."
                   class="filter-inp" style="padding-right:28px;width:200px;">
        </div>
        <select name="status" onchange="this.form.submit()" class="filter-inp" style="cursor:pointer;">
            <option value="">كل الحالات</option>
            <option value="ready"      {{ request('status')==='ready'      ?'selected':'' }}>✓ جاهز</option>
            <option value="processing" {{ request('status')==='processing' ?'selected':'' }}>⚙ معالجة</option>
            <option value="pending"    {{ request('status')==='pending'    ?'selected':'' }}>⏳ انتظار</option>
            <option value="failed"     {{ request('status')==='failed'     ?'selected':'' }}>✕ فشل</option>
        </select>
        <select name="folder" onchange="this.form.submit()" class="filter-inp" style="cursor:pointer;">
            <option value="">كل المجلدات</option>
            <option value="none" {{ request('folder')==='none' ?'selected':'' }}>— بدون مجلد</option>
            @foreach($folders as $f)
            <option value="{{ $f->id }}" {{ request('folder')==(string)$f->id ?'selected':'' }}>📁 {{ $f->name }}</option>
            @endforeach
        </select>

        <button type="button" onclick="toggleAdvFilter()"
                style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:8px;padding:6px 12px;color:#64748b;font-size:12px;cursor:pointer;display:flex;align-items:center;gap:6px;transition:all .15s;"
                id="advToggleBtn">
            <i class="fas fa-sliders" style="font-size:11px;"></i> فلاتر متقدمة
            @if(request()->anyFilled(['tag','date_from','date_to','dur_min','dur_max']))
            <span style="width:6px;height:6px;background:#a78bfa;border-radius:50%;display:inline-block;"></span>
            @endif
        </button>

        @if(request()->anyFilled(['q','status','folder','tag','date_from','date_to','dur_min','dur_max']))
        <a href="{{ route('admin.videos.index') }}" style="font-size:12px;color:#475569;text-decoration:none;padding:6px 10px;">
            <i class="fas fa-times" style="margin-left:4px;"></i> مسح الكل
        </a>
        @endif
        <span style="font-size:11px;color:#334155;margin-right:auto;">{{ $videos->total() }} فيديو</span>
    </div>

    <!-- Advanced filter panel -->
    <div class="adv-filter-panel {{ request()->anyFilled(['tag','date_from','date_to','dur_min','dur_max']) ? 'open' : '' }}"
         id="advFilterPanel"
         style="margin-top:10px;padding:14px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.07);border-radius:10px;">
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">

            <!-- Tag filter -->
            <div>
                <div style="font-size:10.5px;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.06em;">تاج</div>
                <select name="tag" class="filter-inp" style="min-width:140px;cursor:pointer;">
                    <option value="">كل التاجات</option>
                    @foreach($tags as $t)
                    <option value="{{ $t->slug }}" {{ request('tag')===$t->slug ?'selected':'' }}>
                        {{ $t->name }} ({{ $t->videos_count }})
                    </option>
                    @endforeach
                </select>
            </div>

            <!-- Date range -->
            <div>
                <div style="font-size:10.5px;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.06em;">من تاريخ</div>
                <input name="date_from" type="date" value="{{ request('date_from') }}" class="filter-inp">
            </div>
            <div>
                <div style="font-size:10.5px;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.06em;">إلى تاريخ</div>
                <input name="date_to" type="date" value="{{ request('date_to') }}" class="filter-inp">
            </div>

            <!-- Duration range -->
            <div>
                <div style="font-size:10.5px;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.06em;">مدة من (دقيقة)</div>
                <input name="dur_min" type="number" min="0" value="{{ request('dur_min') }}" placeholder="0" class="filter-inp" style="width:90px;">
            </div>
            <div>
                <div style="font-size:10.5px;color:#475569;margin-bottom:5px;text-transform:uppercase;letter-spacing:.06em;">مدة إلى (دقيقة)</div>
                <input name="dur_max" type="number" min="0" value="{{ request('dur_max') }}" placeholder="∞" class="filter-inp" style="width:90px;">
            </div>

            <button type="submit" class="btn-primary btn-sm" style="margin-bottom:1px;">
                <i class="fas fa-search"></i> بحث
            </button>
        </div>
    </div>
</form>

@php $hasProcessing = $videos->contains(fn($v) => in_array($v->status, ['processing','pending'])); @endphp

<!-- Videos table -->
<form method="POST" action="{{ route('admin.videos.bulk') }}" id="bulkForm">
    @csrf
    <input type="hidden" name="action" id="bulkAction">
    <input type="hidden" name="folder_id" id="bulkFolderId">
    <input type="hidden" name="tag_name" id="bulkTagName">

    <div class="card" style="overflow:hidden;">
        @if($videos->isEmpty())
        <div style="text-align:center;padding:64px 0;color:#334155;">
            <i class="fas fa-film" style="font-size:3rem;display:block;margin-bottom:14px;opacity:.18;"></i>
            <p style="font-size:15px;color:#475569;margin-bottom:6px;">لا توجد فيديوهات</p>
            <a href="{{ route('admin.videos.create') }}" style="font-size:13px;color:#7c3aed;text-decoration:none;">ارفع فيديوهك الأول →</a>
        </div>
        @else
        <!-- Table header -->
        <div style="display:grid;grid-template-columns:32px 2fr 130px 90px 90px 90px 140px;align-items:center;border-bottom:1px solid rgba(255,255,255,.06);">
            <div class="col-th" style="padding-right:10px;">
                <input type="checkbox" id="checkAll" title="تحديد الكل" style="cursor:pointer;accent-color:#7c3aed;">
            </div>
            <div class="col-th">الفيديو</div>
            <div class="col-th" style="text-align:center;">الحالة / المجلد</div>
            <div class="col-th" style="text-align:center;">المدة</div>
            <div class="col-th" style="text-align:center;">الحجم</div>
            <div class="col-th" style="text-align:center;">مشاهدات</div>
            <div class="col-th" style="text-align:center;">إجراءات</div>
        </div>

        @foreach($videos as $video)
        <div class="vrow" style="display:grid;grid-template-columns:32px 2fr 130px 90px 90px 90px 140px;align-items:center;"
             data-id="{{ $video->id }}" data-status="{{ $video->status }}">

            <!-- Checkbox -->
            <div class="col-td" style="padding-right:10px;">
                <input type="checkbox" name="ids[]" value="{{ $video->id }}"
                       class="row-check" style="cursor:pointer;accent-color:#7c3aed;"
                       onchange="onCheckChange()">
            </div>

            <!-- Video info -->
            <div class="col-td" style="display:flex;align-items:center;gap:11px;">
                <div style="position:relative;flex-shrink:0;">
                    @if($video->thumbnail)
                    <img src="{{ $video->thumbnail_url }}"
                         style="width:70px;height:44px;object-fit:cover;border-radius:8px;display:block;">
                    @else
                    <div style="width:70px;height:44px;background:rgba(255,255,255,.04);border-radius:8px;display:flex;align-items:center;justify-content:center;">
                        <i class="fas fa-film" style="color:#334155;font-size:13px;"></i>
                    </div>
                    @endif
                    @if($video->isReady())
                    <a href="/embed/{{ $video->slug }}" target="_blank"
                       style="position:absolute;inset:0;background:rgba(0,0,0,.5);border-radius:8px;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .15s;text-decoration:none;"
                       onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0">
                        <i class="fas fa-play" style="color:#fff;font-size:12px;"></i>
                    </a>
                    @endif
                </div>
                <div style="min-width:0;">
                    <div style="font-size:13.5px;color:#e2e8f0;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:260px;">{{ $video->title }}</div>
                    <div style="font-size:10px;color:#334155;font-family:monospace;margin-top:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ $video->slug }}</div>
                    <!-- Tags row -->
                    @if($video->tags->count())
                    <div style="display:flex;gap:3px;margin-top:4px;flex-wrap:wrap;">
                        @foreach($video->tags as $tag)
                        <a href="{{ route('admin.videos.index', ['tag' => $tag->slug]) }}" class="tag-chip">
                            #{{ $tag->name }}
                        </a>
                        @endforeach
                    </div>
                    @endif
                    <!-- Qualities -->
                    @if($video->qualities)
                    <div style="display:flex;gap:3px;margin-top:3px;flex-wrap:wrap;">
                        @foreach($video->qualities as $q)
                        <span style="font-size:9px;background:rgba(255,255,255,.04);color:#475569;padding:1px 4px;border-radius:3px;">{{ $q }}</span>
                        @endforeach
                    </div>
                    @endif
                </div>
            </div>

            <!-- Status + Folder -->
            <div class="col-td" style="text-align:center;">
                @php
                $bc = match($video->status) {'ready'=>'b-ready','processing'=>'b-processing','failed'=>'b-failed',default=>'b-pending'};
                $bt = match($video->status) {'ready'=>'جاهز','processing'=>'معالجة','failed'=>'فشل',default=>'انتظار'};
                @endphp
                <span class="status-badge {{ $bc }}">{{ $bt }}</span>
                @if($video->folder)
                <div style="margin-top:5px;">
                    <a href="{{ route('admin.videos.index', ['folder' => $video->folder_id]) }}" class="folder-chip">
                        <i class="fas fa-folder" style="font-size:9px;"></i>{{ $video->folder->name }}
                    </a>
                </div>
                @endif
            </div>

            <!-- Duration -->
            <div class="col-td" style="text-align:center;font-family:monospace;font-size:12px;">{{ $video->formatted_duration }}</div>

            <!-- Size -->
            <div class="col-td" style="text-align:center;font-size:12px;">{{ $video->formatted_size }}</div>

            <!-- Views -->
            <div class="col-td" style="text-align:center;font-size:12px;color:#60a5fa;font-weight:500;">{{ number_format($video->views) }}</div>

            <!-- Actions -->
            <div class="col-td" style="display:flex;align-items:center;justify-content:center;gap:4px;">
                @if($video->isReady())
                <button type="button" onclick="showEmbed('{{ $video->slug }}')"
                        title="كود التضمين" class="ibtn" style="background:rgba(59,130,246,.1);color:#60a5fa;">
                    <i class="fas fa-code"></i>
                </button>
                <a href="/embed/{{ $video->slug }}" target="_blank"
                   title="تشغيل" class="ibtn" style="background:rgba(34,197,94,.1);color:#4ade80;text-decoration:none;">
                    <i class="fas fa-play"></i>
                </a>
                @endif
                <a href="{{ route('admin.videos.edit', $video) }}"
                   title="تعديل" class="ibtn" style="background:rgba(139,92,246,.1);color:#a78bfa;text-decoration:none;">
                    <i class="fas fa-pen"></i>
                </a>
                @if($video->status === 'failed')
                <a href="{{ route('admin.videos.reprocess', $video) }}"
                   title="إعادة معالجة" class="ibtn" style="background:rgba(234,179,8,.1);color:#facc15;text-decoration:none;">
                    <i class="fas fa-rotate"></i>
                </a>
                @endif
                <button type="button"
                        onclick="deleteVideo('{{ route('admin.videos.destroy', $video) }}')"
                        title="حذف" class="ibtn" style="background:rgba(239,68,68,.1);color:#f87171;">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        @endforeach

        @if($videos->hasPages())
        <div style="padding:10px 16px;border-top:1px solid rgba(255,255,255,.055);display:flex;align-items:center;justify-content:space-between;">
            <span style="font-size:11.5px;color:#334155;">
                عرض {{ $videos->firstItem() }}–{{ $videos->lastItem() }} من {{ $videos->total() }}
            </span>
            <div style="display:flex;gap:4px;align-items:center;">
                @if($videos->onFirstPage())
                <span style="padding:5px 10px;border-radius:6px;font-size:12px;color:#1e293b;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);"><i class="fas fa-chevron-right"></i></span>
                @else
                <a href="{{ $videos->previousPageUrl() }}" style="padding:5px 10px;border-radius:6px;font-size:12px;color:#94a3b8;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);text-decoration:none;"><i class="fas fa-chevron-right"></i></a>
                @endif
                @foreach($videos->getUrlRange(1, $videos->lastPage()) as $page => $url)
                <a href="{{ $url }}" style="padding:5px 10px;border-radius:6px;font-size:12px;text-decoration:none;{{ $page == $videos->currentPage() ? 'background:rgba(124,58,237,.3);color:#a78bfa;border:1px solid rgba(124,58,237,.4);' : 'color:#94a3b8;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);' }}">{{ $page }}</a>
                @endforeach
                @if($videos->hasMorePages())
                <a href="{{ $videos->nextPageUrl() }}" style="padding:5px 10px;border-radius:6px;font-size:12px;color:#94a3b8;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);text-decoration:none;"><i class="fas fa-chevron-left"></i></a>
                @else
                <span style="padding:5px 10px;border-radius:6px;font-size:12px;color:#1e293b;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);"><i class="fas fa-chevron-left"></i></span>
                @endif
            </div>
        </div>
        @endif
        @endif
    </div>

    <!-- Bulk action bar -->
    <div id="bulkBar">
        <span id="bulkCount" style="font-size:12.5px;color:#94a3b8;flex-shrink:0;"></span>
        <div style="height:16px;width:1px;background:rgba(255,255,255,.08);flex-shrink:0;"></div>

        <!-- Move to folder -->
        <select id="bulkFolderSelect" class="filter-inp" style="font-size:12px;cursor:pointer;min-width:130px;">
            <option value="">— نقل إلى مجلد —</option>
            <option value="0">بدون مجلد</option>
            @foreach($folders as $f)
            <option value="{{ $f->id }}">📁 {{ $f->name }}</option>
            @endforeach
        </select>
        <button type="button" onclick="bulkMoveFolder()"
                style="background:rgba(96,165,250,.1);color:#60a5fa;border:1px solid rgba(96,165,250,.2);border-radius:7px;padding:6px 12px;font-size:12px;cursor:pointer;white-space:nowrap;">
            <i class="fas fa-folder-arrow-up" style="margin-left:5px;"></i> نقل
        </button>

        <div style="height:16px;width:1px;background:rgba(255,255,255,.08);flex-shrink:0;"></div>

        <!-- Add tag -->
        <input id="bulkTagInput" type="text" placeholder="اسم التاج..." class="filter-inp" style="width:120px;font-size:12px;">
        <button type="button" onclick="bulkAddTag()"
                style="background:rgba(139,92,246,.1);color:#a78bfa;border:1px solid rgba(139,92,246,.2);border-radius:7px;padding:6px 12px;font-size:12px;cursor:pointer;white-space:nowrap;">
            <i class="fas fa-tag" style="margin-left:5px;"></i> إضافة تاج
        </button>

        <div style="height:16px;width:1px;background:rgba(255,255,255,.08);flex-shrink:0;"></div>

        <!-- Delete -->
        <button type="button" onclick="bulkDelete()"
                style="background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2);border-radius:7px;padding:6px 12px;font-size:12px;cursor:pointer;white-space:nowrap;">
            <i class="fas fa-trash" style="margin-left:5px;"></i> حذف المحدد
        </button>

        <button type="button" onclick="clearSelection()" style="margin-right:auto;font-size:11px;color:#475569;background:none;border:none;cursor:pointer;">
            <i class="fas fa-times" style="margin-left:3px;"></i> إلغاء
        </button>
    </div>
</form>

<!-- Embed Modal -->
<div id="embedModal" style="position:fixed;inset:0;z-index:60;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.75);">
    <div class="card" style="width:100%;max-width:500px;margin:0 16px;padding:20px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
            <span style="font-size:14px;font-weight:600;display:flex;align-items:center;gap:8px;">
                <i class="fas fa-code" style="color:#a78bfa;"></i> كود التضمين
            </span>
            <button onclick="closeEmbed()" class="ibtn" style="background:rgba(255,255,255,.05);color:#64748b;"><i class="fas fa-times"></i></button>
        </div>
        <div style="font-size:11px;color:#475569;margin-bottom:6px;">iframe</div>
        <div style="background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.07);border-radius:9px;padding:12px;display:flex;gap:8px;align-items:flex-start;margin-bottom:12px;">
            <code id="embedCodeText" style="flex:1;font-size:11.5px;color:#4ade80;font-family:monospace;word-break:break-all;line-height:1.6;"></code>
            <button onclick="copyEmbed()" class="ibtn" style="flex-shrink:0;background:rgba(139,92,246,.1);color:#a78bfa;" title="نسخ"><i class="fas fa-copy"></i></button>
        </div>
        <div style="font-size:11px;color:#475569;margin-bottom:6px;">رابط المشغّل</div>
        <div style="background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.07);border-radius:9px;padding:12px;display:flex;gap:8px;align-items:center;">
            <code id="embedUrlText" style="flex:1;font-size:11.5px;color:#60a5fa;font-family:monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"></code>
            <button onclick="copyUrl()" class="ibtn" style="flex-shrink:0;background:rgba(139,92,246,.1);color:#a78bfa;" title="نسخ"><i class="fas fa-copy"></i></button>
        </div>
        <div id="copyToast" style="display:none;margin-top:10px;color:#4ade80;font-size:12px;text-align:center;">
            <i class="fas fa-check" style="margin-left:4px;"></i> تم النسخ!
        </div>
    </div>
</div>

@push('scripts')
<script>
const APP_URL = '{{ config("app.url") }}';

// ── Advanced filter toggle ──
function toggleAdvFilter() {
    const panel = document.getElementById('advFilterPanel');
    panel.classList.toggle('open');
}

// ── Single-row delete (standalone form outside bulkForm — no nested forms) ──
const _delForm = document.createElement('form');
_delForm.method = 'POST';
_delForm.style.display = 'none';
const _delToken  = document.createElement('input');
_delToken.type   = 'hidden';
_delToken.name   = '_token';
_delToken.value  = '{{ csrf_token() }}';
const _delMethod = document.createElement('input');
_delMethod.type  = 'hidden';
_delMethod.name  = '_method';
_delMethod.value = 'DELETE';
_delForm.appendChild(_delToken);
_delForm.appendChild(_delMethod);
document.body.appendChild(_delForm);

function deleteVideo(action) {
    if (!confirm('حذف هذا الفيديو نهائياً؟')) return;
    _delForm.action = action;
    _delForm.submit();
}

// ── Embed modal ──
function showEmbed(slug) {
    document.getElementById('embedCodeText').textContent =
        `<iframe src="${APP_URL}/embed/${slug}" width="960" height="540" frameborder="0" allowfullscreen allow="autoplay"></iframe>`;
    document.getElementById('embedUrlText').textContent = `${APP_URL}/embed/${slug}`;
    document.getElementById('embedModal').style.display = 'flex';
}
function closeEmbed() { document.getElementById('embedModal').style.display = 'none'; }
function copyEmbed() { navigator.clipboard.writeText(document.getElementById('embedCodeText').textContent); flashToast(); }
function copyUrl()   { navigator.clipboard.writeText(document.getElementById('embedUrlText').textContent);  flashToast(); }
function flashToast() {
    const t = document.getElementById('copyToast');
    t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 2000);
}
document.getElementById('embedModal').addEventListener('click', e => {
    if (e.target === document.getElementById('embedModal')) closeEmbed();
});

// ── Bulk selection ──
function onCheckChange() {
    const checked = document.querySelectorAll('.row-check:checked');
    const bar = document.getElementById('bulkBar');
    const rows = document.querySelectorAll('.vrow');
    rows.forEach(r => {
        const cb = r.querySelector('.row-check');
        r.classList.toggle('selected', cb && cb.checked);
    });
    if (checked.length > 0) {
        bar.classList.add('visible');
        document.getElementById('bulkCount').textContent = checked.length + ' مختار';
    } else {
        bar.classList.remove('visible');
    }
}

document.getElementById('checkAll').addEventListener('change', function() {
    document.querySelectorAll('.row-check').forEach(c => {
        c.checked = this.checked;
    });
    onCheckChange();
});

function clearSelection() {
    document.querySelectorAll('.row-check, #checkAll').forEach(c => c.checked = false);
    onCheckChange();
}

function getSelectedIds() {
    return [...document.querySelectorAll('.row-check:checked')].map(c => c.value);
}

function bulkMoveFolder() {
    const ids = getSelectedIds();
    if (!ids.length) return;
    const fv = document.getElementById('bulkFolderSelect').value;
    if (fv === '') { alert('يرجى اختيار مجلد'); return; }
    document.getElementById('bulkAction').value   = 'move_folder';
    document.getElementById('bulkFolderId').value = fv === '0' ? '' : fv;
    document.getElementById('bulkForm').submit();
}

function bulkAddTag() {
    const ids = getSelectedIds();
    if (!ids.length) return;
    const tag = document.getElementById('bulkTagInput').value.trim();
    if (!tag) { alert('يرجى إدخال اسم التاج'); return; }
    document.getElementById('bulkAction').value  = 'add_tag';
    document.getElementById('bulkTagName').value = tag;
    document.getElementById('bulkForm').submit();
}

function bulkDelete() {
    const ids = getSelectedIds();
    if (!ids.length) return;
    if (!confirm('حذف ' + ids.length + ' فيديو نهائياً؟')) return;
    document.getElementById('bulkAction').value = 'delete';
    document.getElementById('bulkForm').submit();
}

@if($hasProcessing)
(function() {
    const rows = [...document.querySelectorAll('[data-status="processing"],[data-status="pending"]')];
    if (!rows.length) return;
    setInterval(async () => {
        for (const row of rows) {
            try {
                const r = await fetch(`/admin/videos/${row.dataset.id}/status`, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
                const d = await r.json();
                if (d.status !== row.dataset.status) window.location.reload();
            } catch(e) {}
        }
    }, 5000);
})();
@endif
</script>
@endpush
@endsection
