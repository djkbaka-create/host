@extends('admin.layout')
@section('title', 'إدارة المستخدمين')

@push('styles')
<style>
.role-badge {
    display:inline-flex;align-items:center;gap:4px;padding:2px 9px;
    border-radius:99px;font-size:11px;font-weight:600;
}
.role-admin  { background:rgba(239,68,68,.12); color:#f87171; }
.role-editor { background:rgba(245,158,11,.12); color:#fbbf24; }
.role-viewer { background:rgba(100,116,139,.12); color:#94a3b8; }
.status-on  { background:rgba(34,197,94,.12); color:#4ade80; }
.status-off { background:rgba(239,68,68,.12); color:#f87171; }
</style>
@endpush

@section('content')
<div class="topbar">
    <div>
        <h1 style="font-size:17px;font-weight:700;margin:0;">إدارة المستخدمين</h1>
        <div style="font-size:11px;color:#334155;margin-top:2px;">StreamHost › المستخدمون</div>
    </div>
    <div style="display:flex;gap:10px;">
        <a href="{{ route('admin.users.create') }}" class="btn-primary" style="font-size:13px;padding:8px 16px;">
            <i class="fas fa-user-plus"></i> مستخدم جديد
        </a>
    </div>
</div>

@if(session('success'))
<div class="alert-ok mb-4">{{ session('success') }}</div>
@endif
@if($errors->any())
<div class="alert-err mb-4">@foreach($errors->all() as $e)<div>• {{ $e }}</div>@endforeach</div>
@endif

<div class="card" style="overflow:hidden;">
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <thead>
            <tr style="border-bottom:1px solid rgba(255,255,255,.06);">
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">#</th>
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">المستخدم</th>
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">الدور</th>
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">الحالة</th>
                <th style="padding:12px 16px;text-align:right;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">تاريخ الإنشاء</th>
                <th style="padding:12px 16px;text-align:center;color:#475569;font-weight:600;font-size:11px;text-transform:uppercase;">إجراءات</th>
            </tr>
        </thead>
        <tbody>
            @forelse($users as $u)
            <tr style="border-bottom:1px solid rgba(255,255,255,.04);transition:background .1s;" onmouseover="this.style.background='rgba(255,255,255,.02)'" onmouseout="this.style.background=''">
                <td style="padding:12px 16px;color:#475569;font-size:12px;">{{ $u->id }}</td>
                <td style="padding:12px 16px;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#7c3aed,#a855f7);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0;">
                            {{ strtoupper(substr($u->username ?? $u->name, 0, 1)) }}
                        </div>
                        <div>
                            <div style="font-weight:600;color:#e2e8f0;">{{ $u->username ?? $u->name }}</div>
                            <div style="font-size:11px;color:#475569;">{{ $u->email }}</div>
                        </div>
                    </div>
                </td>
                <td style="padding:12px 16px;">
                    <span class="role-badge role-{{ $u->role }}">
                        @if($u->role === 'admin') <i class="fas fa-shield-halved"></i>
                        @elseif($u->role === 'editor') <i class="fas fa-pen"></i>
                        @else <i class="fas fa-eye"></i>
                        @endif
                        {{ $u->role_label }}
                    </span>
                </td>
                <td style="padding:12px 16px;">
                    <span class="role-badge {{ $u->is_active ? 'status-on' : 'status-off' }}">
                        <i class="fas fa-circle" style="font-size:7px;"></i>
                        {{ $u->is_active ? 'نشط' : 'معطّل' }}
                    </span>
                </td>
                <td style="padding:12px 16px;color:#475569;font-size:12px;">
                    {{ $u->created_at?->format('Y-m-d') ?? '—' }}
                </td>
                <td style="padding:12px 16px;text-align:center;">
                    <div style="display:flex;justify-content:center;gap:6px;">
                        <a href="{{ route('admin.users.edit', $u) }}" class="ibtn" title="تعديل" style="background:rgba(124,58,237,.12);color:#a78bfa;">
                            <i class="fas fa-pen"></i>
                        </a>
                        @if($u->id !== session('admin_user_id'))
                        <form method="POST" action="{{ route('admin.users.destroy', $u) }}" style="display:inline;" onsubmit="return confirm('حذف المستخدم {{ addslashes($u->username) }}؟')">
                            @csrf @method('DELETE')
                            <button type="submit" class="ibtn" title="حذف" style="background:rgba(239,68,68,.1);color:#f87171;">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                        @endif
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="padding:32px;text-align:center;color:#334155;">لا يوجد مستخدمون حتى الآن.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
