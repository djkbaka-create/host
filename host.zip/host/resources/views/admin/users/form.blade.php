@extends('admin.layout')
@section('title', $user ? 'تعديل مستخدم' : 'مستخدم جديد')

@section('content')
<div class="topbar">
    <div>
        <h1 style="font-size:17px;font-weight:700;margin:0;">{{ $user ? 'تعديل مستخدم' : 'مستخدم جديد' }}</h1>
        <div style="font-size:11px;color:#334155;margin-top:2px;">
            <a href="{{ route('admin.users.index') }}" style="color:#7c3aed;text-decoration:none;">المستخدمون</a>
            › {{ $user ? $user->username : 'جديد' }}
        </div>
    </div>
</div>

<div class="card" style="max-width:540px;padding:24px;">
    @if($errors->any())
    <div class="alert-err mb-4">@foreach($errors->all() as $e)<div>• {{ $e }}</div>@endforeach</div>
    @endif

    <form method="POST" action="{{ $user ? route('admin.users.update', $user) : route('admin.users.store') }}">
        @csrf
        @if($user) @method('PUT') @endif

        <div style="display:grid;gap:14px;">

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div>
                    <label class="field-label">اسم المستخدم *</label>
                    <input name="username" type="text" required value="{{ old('username', $user?->username) }}"
                           class="inp" placeholder="admin" autocomplete="username">
                </div>
                <div>
                    <label class="field-label">الاسم الكامل *</label>
                    <input name="name" type="text" required value="{{ old('name', $user?->name) }}"
                           class="inp" placeholder="Ahmed Ali">
                </div>
            </div>

            <div>
                <label class="field-label">البريد الإلكتروني *</label>
                <input name="email" type="email" required value="{{ old('email', $user?->email) }}"
                       class="inp" placeholder="user@example.com" autocomplete="email">
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div>
                    <label class="field-label">
                        كلمة المرور {{ $user ? '(اتركها فارغة لعدم التغيير)' : '*' }}
                    </label>
                    <input name="password" type="password"
                           {{ $user ? '' : 'required' }}
                           minlength="8"
                           class="inp" placeholder="••••••••" autocomplete="new-password">
                </div>
                <div>
                    <label class="field-label">تأكيد كلمة المرور</label>
                    <input name="password_confirmation" type="password"
                           class="inp" placeholder="••••••••" autocomplete="new-password">
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div>
                    <label class="field-label">الدور *</label>
                    <select name="role" class="inp" style="cursor:pointer;"
                            {{ ($user && $user->id === session('admin_user_id')) ? 'disabled' : '' }}>
                        <option value="admin"  {{ old('role', $user?->role) === 'admin'  ? 'selected' : '' }}>
                            مدير — وصول كامل
                        </option>
                        <option value="editor" {{ old('role', $user?->role) === 'editor' ? 'selected' : '' }}>
                            محرر — رفع وإدارة فيديوهات
                        </option>
                        <option value="viewer" {{ old('role', $user?->role) === 'viewer' ? 'selected' : '' }}>
                            مشاهد — عرض فقط
                        </option>
                    </select>
                    @if($user && $user->id === session('admin_user_id'))
                    <input type="hidden" name="role" value="{{ $user->role }}">
                    <p style="font-size:11px;color:#475569;margin-top:4px;">لا يمكنك تغيير دورك الخاص.</p>
                    @endif
                </div>
                <div>
                    <label class="field-label">الحالة</label>
                    <label style="display:flex;align-items:center;gap:10px;cursor:pointer;margin-top:10px;">
                        <input type="hidden" name="is_active" value="0">
                        <input type="checkbox" name="is_active" value="1"
                               style="width:16px;height:16px;accent-color:#7c3aed;cursor:pointer;"
                               {{ (old('is_active', $user?->is_active ?? true) ? 'checked' : '') }}
                               {{ ($user && $user->id === session('admin_user_id')) ? 'disabled' : '' }}>
                        <span style="color:#cbd5e1;font-size:13px;">حساب نشط</span>
                    </label>
                    @if($user && $user->id === session('admin_user_id'))
                    <input type="hidden" name="is_active" value="1">
                    @endif
                </div>
            </div>

        </div>

        <div style="display:flex;gap:10px;margin-top:20px;">
            <button type="submit" class="btn-primary">
                <i class="fas fa-save"></i> {{ $user ? 'حفظ التعديلات' : 'إنشاء المستخدم' }}
            </button>
            <a href="{{ route('admin.users.index') }}" class="btn-ghost">إلغاء</a>
        </div>
    </form>
</div>
@endsection
