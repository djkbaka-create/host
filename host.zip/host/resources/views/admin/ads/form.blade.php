@extends('admin.layout')
@section('title', $config ? 'تعديل إعداد الإعلانات' : 'إعداد إعلانات جديد')
@section('breadcrumb', 'StreamHost › الإعلانات › ' . ($config ? 'تعديل' : 'جديد'))

@push('styles')
<style>
    .tog-row {
        display: flex; align-items: center; justify-content: space-between;
        padding: 11px 0; border-top: 1px solid rgba(255,255,255,.05);
    }
    .tog-row:first-child { border-top: none; padding-top: 0; }
    .tog-info { display:flex; flex-direction:column; gap:2px; }
    .tog-title { font-size: 13px; color: #cbd5e1; font-weight: 500; }
    .tog-desc  { font-size: 11px; color: #475569; }
    .switch { position:relative; display:inline-block; width:42px; height:24px; flex-shrink:0; }
    .switch input { opacity:0; width:0; height:0; }
    .sw-slider {
        position:absolute; inset:0; border-radius:24px;
        background:rgba(255,255,255,.08); cursor:pointer; transition:.2s;
        border: 1px solid rgba(255,255,255,.1);
    }
    .sw-slider:before {
        content:''; position:absolute; width:18px; height:18px;
        left:2px; top:2px; border-radius:50%; background:#475569; transition:.2s;
    }
    .switch input:checked + .sw-slider { background:#7c3aed; border-color:#7c3aed; }
    .switch input:checked + .sw-slider:before { transform:translateX(18px); background:#fff; }
    .section-sep { height:1px; background:rgba(255,255,255,.06); margin:20px 0; }
</style>
@endpush

@section('content')
<div style="max-width:600px;">
<div class="card" style="padding:24px;">
    <form method="POST" action="{{ $config ? route('admin.ads.update', $config) : route('admin.ads.store') }}">
        @csrf
        @if($config) @method('PUT') @endif

        @if($errors->any())
        <div class="alert-err" style="margin-bottom:16px;">
            @foreach($errors->all() as $e)<div>• {{ $e }}</div>@endforeach
        </div>
        @endif

        <!-- Name -->
        <div style="margin-bottom:16px;">
            <label class="field-label">اسم الإعداد *</label>
            <input name="name" type="text" class="inp" required
                   value="{{ old('name', $config?->name) }}"
                   placeholder="مثلاً: إعلانات الصفحة الرئيسية"
                   @if($config?->is_global) readonly @endif>
            @if($config?->is_global)
            <p style="font-size:11px;color:#475569;margin-top:4px;">
                <i class="fas fa-lock" style="margin-left:4px;"></i>
                الاسم ثابت للإعداد العام
            </p>
            @endif
        </div>

        <div class="section-sep"></div>

        <!-- VAST -->
        <div style="margin-bottom:16px;">
            <label class="field-label">
                <i class="fas fa-rectangle-ad" style="margin-left:5px;color:#a78bfa;"></i>
                رابط إعلان VAST
            </label>
            <input name="vast_url" type="url" class="inp" style="font-family:monospace;"
                   value="{{ old('vast_url', $config?->vast_url) }}"
                   placeholder="https://ads.example.com/vast.xml">
            <p style="font-size:11px;color:#475569;margin-top:4px;">
                يُستخدم مع Google IMA SDK — اتركه فارغاً لتعطيل إعلانات VAST
            </p>
        </div>

        <!-- Ad Timer -->
        <div style="margin-bottom:16px;">
            <label class="field-label">
                <i class="fas fa-hourglass-half" style="margin-left:5px;color:#facc15;"></i>
                مؤقّت الإعلان (ثواني قبل التشغيل)
            </label>
            <div style="display:flex;align-items:center;gap:10px;">
                <input name="ad_timer_seconds" type="number" class="inp" min="0" max="120"
                       style="width:120px;"
                       value="{{ old('ad_timer_seconds', $config?->ad_timer_seconds ?? 0) }}">
                <span style="font-size:12px;color:#475569;">ثانية (0 = معطّل)</span>
            </div>
        </div>

        <div class="section-sep"></div>

        <!-- Popunder Script -->
        <div style="margin-bottom:16px;">
            <label class="field-label">
                <i class="fas fa-arrow-up-right-from-square" style="margin-left:5px;color:#60a5fa;"></i>
                سكريبت Popunder
            </label>
            <textarea name="popunder_script" rows="3" class="inp"
                      style="font-family:monospace;color:#4ade80;resize:vertical;"
                      placeholder="<script>window.open('https://...')</script>">{{ old('popunder_script', $config?->popunder_script) }}</textarea>
            <p style="font-size:11px;color:#475569;margin-top:4px;">
                سكريبت HTML/JS يُنفَّذ عند تشغيل Popunder — اتركه فارغاً لتعطيله
            </p>
        </div>

        <!-- Popunder Settings -->
        <div class="card" style="padding:14px 18px;margin-bottom:16px;background:rgba(0,0,0,.2);">
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:#334155;margin-bottom:12px;">
                إعدادات تشغيل Popunder
            </div>

            <div class="tog-row">
                <div class="tog-info">
                    <span class="tog-title">تشغيل عند بدء الفيديو</span>
                    <span class="tog-desc">يُفعَّل Popunder عند أول ضغطة تشغيل</span>
                </div>
                <label class="switch">
                    <input type="checkbox" name="popunder_on_play" value="1"
                           {{ old('popunder_on_play', $config?->popunder_on_play ?? true) ? 'checked' : '' }}>
                    <span class="sw-slider"></span>
                </label>
            </div>

            <div class="tog-row">
                <div class="tog-info">
                    <span class="tog-title">تشغيل عند التقديم (Seek)</span>
                    <span class="tog-desc">يُفعَّل Popunder عند تحريك شريط التقدم</span>
                </div>
                <label class="switch">
                    <input type="checkbox" name="popunder_on_seek" value="1"
                           {{ old('popunder_on_seek', $config?->popunder_on_seek ?? false) ? 'checked' : '' }}>
                    <span class="sw-slider"></span>
                </label>
            </div>

            <div class="tog-row">
                <div class="tog-info">
                    <span class="tog-title">تأخير التفعيل</span>
                    <span class="tog-desc">انتظر عدد الثواني هذا قبل تشغيل Popunder</span>
                </div>
                <div style="display:flex;align-items:center;gap:7px;">
                    <input name="popunder_delay" type="number" min="0" max="300"
                           value="{{ old('popunder_delay', $config?->popunder_delay ?? 0) }}"
                           style="width:70px;background:rgba(0,0,0,.3);border:1px solid rgba(255,255,255,.1);border-radius:7px;padding:5px 9px;color:#e2e8f0;font-size:13px;outline:none;text-align:center;">
                    <span style="font-size:12px;color:#475569;">ثانية</span>
                </div>
            </div>
        </div>

        <div class="section-sep"></div>

        @if(!$config?->is_global)
        <!-- Video assignment -->
        <div style="margin-bottom:16px;">
            <label class="field-label">
                <i class="fas fa-clapperboard" style="margin-left:5px;color:#34d399;"></i>
                الفيديوهات المرتبطة بهذا الإعداد
            </label>
            <p style="font-size:11px;color:#475569;margin:4px 0 10px;">
                اختر الفيديوهات التي ستستخدم هذا الإعداد · الفيديوهات غير المحدّدة ستستخدم الإعداد العام
            </p>
            @if($videos->isEmpty())
            <p style="font-size:12px;color:#64748b;padding:10px;">لا توجد فيديوهات بعد.</p>
            @else
            <div style="max-height:240px;overflow-y:auto;border:1px solid rgba(255,255,255,.08);border-radius:9px;padding:6px;background:rgba(0,0,0,.2);">
                @foreach($videos as $v)
                <label style="display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:7px;cursor:pointer;font-size:13px;color:#cbd5e1;"
                       onmouseover="this.style.background='rgba(255,255,255,.04)'" onmouseout="this.style.background='transparent'">
                    <input type="checkbox" name="video_ids[]" value="{{ $v->id }}"
                           style="width:16px;height:16px;accent-color:#7c3aed;cursor:pointer;flex-shrink:0;"
                           {{ in_array($v->id, old('video_ids', $assignedIds)) ? 'checked' : '' }}>
                    <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{{ $v->title }}</span>
                    <span style="margin-inline-start:auto;font-family:monospace;font-size:10px;color:#475569;flex-shrink:0;">{{ $v->slug }}</span>
                </label>
                @endforeach
            </div>
            @endif
        </div>

        <div class="section-sep"></div>

        <!-- Active toggle -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
            <div>
                <div style="font-size:13px;color:#cbd5e1;font-weight:500;">تفعيل هذا الإعداد</div>
                <div style="font-size:11px;color:#475569;">إعدادات معطّلة لن تُطبَّق على الفيديوهات</div>
            </div>
            <label class="switch">
                <input type="checkbox" name="is_active" value="1"
                       {{ old('is_active', $config?->is_active ?? true) ? 'checked' : '' }}>
                <span class="sw-slider"></span>
            </label>
        </div>
        @endif

        <div style="display:flex;gap:10px;">
            <button type="submit" class="btn-primary" style="flex:1;justify-content:center;padding:11px;">
                <i class="fas fa-save"></i>
                {{ $config ? 'حفظ التغييرات' : 'إنشاء الإعداد' }}
            </button>
            <a href="{{ route('admin.ads.index') }}" class="btn-ghost" style="padding:11px 18px;text-decoration:none;">
                إلغاء
            </a>
        </div>
    </form>
</div>
</div>
@endsection
