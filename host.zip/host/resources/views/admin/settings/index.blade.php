@extends('admin.layout')
@section('title', 'الإعدادات العامة')
@section('breadcrumb', 'StreamHost › الإعدادات')

@push('styles')
<style>
    .set-grid { display:grid; gap:18px; }
    .set-card { padding:22px 24px; }
    .set-head { display:flex; align-items:center; gap:11px; margin-bottom:6px; }
    .set-ico {
        width:38px; height:38px; border-radius:10px; flex-shrink:0;
        display:flex; align-items:center; justify-content:center; font-size:16px;
    }
    .set-title { font-size:15px; font-weight:700; color:#e2e8f0; }
    .set-desc  { font-size:12px; color:#475569; margin:0 0 16px; line-height:1.6; }
    .section-sep { height:1px; background:rgba(255,255,255,.06); margin:20px 0; }
</style>
@endpush

@section('content')
<div style="max-width:680px;">

    @if(session('success'))
    <div class="alert-ok mb-4"><i class="fas fa-check-circle"></i> {{ session('success') }}</div>
    @endif
    @if($errors->any())
    <div class="alert-err mb-4">
        @foreach($errors->all() as $e)<div>• {{ $e }}</div>@endforeach
    </div>
    @endif

    <form method="POST" action="{{ route('admin.settings.update') }}">
        @csrf

        <div class="set-grid">

            <!-- Signed URL TTL -->
            <div class="card set-card">
                <div class="set-head">
                    <div class="set-ico" style="background:rgba(124,58,237,.15);color:#a78bfa;">
                        <i class="fas fa-key"></i>
                    </div>
                    <span class="set-title">صلاحية الروابط الموقّعة</span>
                </div>
                <p class="set-desc">
                    المدة الافتراضية لصلاحية روابط البث المؤقّتة قبل انتهائها · تُطبَّق على الفيديوهات
                    التي لم تُحدَّد لها مدة خاصة.
                </p>
                <label class="field-label">المدة الافتراضية (بالدقائق)</label>
                <div style="display:flex;align-items:center;gap:10px;">
                    <input name="signed_url_default_ttl" type="number" class="inp" min="5" max="10080"
                           style="width:160px;" required
                           value="{{ old('signed_url_default_ttl', $defaultTtl) }}">
                    <span style="font-size:12px;color:#475569;">من 5 إلى 10080 دقيقة (أسبوع)</span>
                </div>
            </div>

            <!-- Allowed domains -->
            <div class="card set-card">
                <div class="set-head">
                    <div class="set-ico" style="background:rgba(34,197,94,.15);color:#4ade80;">
                        <i class="fas fa-shield-halved"></i>
                    </div>
                    <span class="set-title">النطاقات المسموحة عامةً</span>
                </div>
                <p class="set-desc">
                    النطاقات المسموح لها بتضمين المشغّل افتراضياً · تُطبَّق على الفيديوهات التي لم تُحدَّد
                    لها نطاقات خاصة · إذا تُركت فارغة يُرجَع إلى النطاق الافتراضي المُهيّأ في الخادم.
                </p>
                <label class="field-label">النطاقات (سطر واحد لكل نطاق)</label>
                <textarea name="allowed_domains" rows="4" class="inp"
                          style="font-family:monospace;font-size:13px;resize:vertical;"
                          placeholder="example.com&#10;*.sub.example.com">{{ old('allowed_domains', $allowedDomains) }}</textarea>
                <p style="font-size:11px;color:#334155;margin-top:6px;">
                    يدعم البدل <code style="color:#7dd3fc;">*.example.com</code> ·
                    أضف <code style="color:#7dd3fc;">*</code> للسماح لجميع النطاقات
                </p>
            </div>

            <!-- Anti-AdBlock -->
            <div class="card set-card">
                <div class="set-head">
                    <div class="set-ico" style="background:rgba(239,68,68,.15);color:#ef4444;">
                        <i class="fas fa-ban"></i>
                    </div>
                    <span class="set-title">حماية ضد مانعات الإعلانات</span>
                </div>
                <p class="set-desc">
                    اكتشاف برامج حجب الإعلانات · الموقع يعتمد على الإعلانات كمصدر دخل.
                </p>

                <div style="margin-bottom:14px;">
                    <label style="display:flex;align-items:center;gap:10px;cursor:pointer;">
                        <input type="checkbox" name="anti_adblock_enabled" value="1" 
                               @if(old('anti_adblock_enabled', $antiAdblockEnabled)) checked @endif
                               style="width:16px;height:16px;cursor:pointer;">
                        <span style="font-size:14px;color:#e2e8f0;">تفعيل حماية ضد مانعات الإعلانات</span>
                    </label>
                </div>

                <div style="margin-bottom:10px;">
                    <label class="field-label">وضع الحماية</label>
                    <select name="anti_adblock_mode" class="inp" style="width:100%;">
                        <option value="warning" @if(old('anti_adblock_mode', $antiAdblockMode) === 'warning') selected @endif>
                            ⚠️ وضع التحذير (عرض رسالة تحذير)
                        </option>
                        <option value="block" @if(old('anti_adblock_mode', $antiAdblockMode) === 'block') selected @endif>
                            🚫 وضع المنع (حظر التشغيل حتى تعطيل AdBlock)
                        </option>
                    </select>
                </div>

                <p style="font-size:11px;color:#334155;margin-top:6px;">
                    <strong>الإحصائيات اليومية:</strong> تم اكتشاف مانعات إعلانات <strong>{{ $adblockDetectionCount }}</strong> مرة اليوم
                </p>
            </div>

        </div>

        <button type="submit" class="btn-primary" style="margin-top:20px;padding:12px 26px;">
            <i class="fas fa-save"></i> حفظ الإعدادات
        </button>
    </form>
</div>
@endsection
