@extends('admin.layout')
@section('title', 'سجل التدقيق')

@push('styles')
<style>
.log-action { font-family: monospace; font-size: 12px; color: #7dd3fc; background: rgba(14,165,233,.08);
              padding: 2px 7px; border-radius: 5px; }
.filter-bar { display:flex;gap:10px;align-items:center;flex-wrap:wrap; }
.filter-bar input, .filter-bar select { background:#0e0e1d;border:1px solid rgba(255,255,255,.08);
    color:#e2e8f0;border-radius:8px;padding:7px 11px;font-size:13px;outline:none; }
.filter-bar input:focus, .filter-bar select:focus { border-color:#7c3aed; }
</style>
@endpush

@section('content')
<div class="topbar">
    <div>
        <h1 style="font-size:17px;font-weight:700;margin:0;">سجل التدقيق</h1>
        <div style="font-size:11px;color:#334155;margin-top:2px;">StreamHost › التدقيق</div>
    </div>
</div>

<form method="GET" class="card mb-4" style="padding:14px 18px;">
    <div class="filter-bar">
        <input type="text" name="action" value="{{ request('action') }}" placeholder="فلترة بالإجراء…" style="flex:1;min-width:160px;">
        <button type="submit" class="btn-primary" style="padding:8px 16px;font-size:13px;">
            <i class="fas fa-filter"></i> فلترة
        </button>
        @if(request()->hasAny(['action','user_id']))
        <a href="{{ route('admin.audit.index') }}" class="btn-ghost" style="padding:8px 14px;font-size:13px;">إعادة ضبط</a>
        @endif
    </div>
</form>

<div class="card" style="overflow:hidden;">
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <thead>
            <tr style="border-bottom:1px solid rgba(255,255,255,.06);">
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">التاريخ</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">المستخدم</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">الإجراء</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">الهدف</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">IP</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">تفاصيل</th>
            </tr>
        </thead>
        <tbody>
            @forelse($logs as $log)
            <tr style="border-bottom:1px solid rgba(255,255,255,.04);">
                <td style="padding:10px 16px;white-space:nowrap;color:#475569;font-size:11px;">
                    {{ $log->created_at->format('Y-m-d H:i:s') }}
                </td>
                <td style="padding:10px 16px;color:#cbd5e1;font-size:12px;">
                    {{ $log->user?->username ?? '—' }}
                </td>
                <td style="padding:10px 16px;">
                    <span class="log-action">{{ $log->action }}</span>
                </td>
                <td style="padding:10px 16px;color:#94a3b8;font-size:12px;">
                    @if($log->target_type)
                        {{ $log->target_type }}:{{ $log->target_id }}
                    @else —
                    @endif
                </td>
                <td style="padding:10px 16px;color:#475569;font-size:11px;font-family:monospace;">
                    {{ $log->ip ?? '—' }}
                </td>
                <td style="padding:10px 16px;color:#475569;font-size:11px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                    @if($log->details)
                        @foreach($log->details as $k => $v)
                            <span style="color:#94a3b8;">{{ $k }}:</span><span style="color:#cbd5e1;">{{ $v }}</span>{{ !$loop->last ? ' · ' : '' }}
                        @endforeach
                    @else —
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="padding:32px;text-align:center;color:#334155;">لا توجد سجلات حتى الآن.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

@if($logs->hasPages())
<div style="margin-top:16px;display:flex;justify-content:center;">
    {{ $logs->links() }}
</div>
@endif
@endsection
