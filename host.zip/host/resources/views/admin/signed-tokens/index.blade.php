@extends('admin.layout')
@section('title', 'إدارة الروابط الموقّعة')

@push('styles')
<style>
.token-hash { font-family:monospace;font-size:11px;color:#7dd3fc;background:rgba(14,165,233,.08);
              padding:2px 7px;border-radius:5px;letter-spacing:.03em; }
.ttl-form { display:flex;align-items:center;gap:10px;flex-wrap:wrap; }
</style>
@endpush

@section('content')
<div class="topbar">
    <div>
        <h1 style="font-size:17px;font-weight:700;margin:0;">إدارة الروابط الموقّعة</h1>
        <div style="font-size:11px;color:#334155;margin-top:2px;">StreamHost › الروابط الموقّعة</div>
    </div>
</div>

@if(session('success'))
<div class="alert-ok mb-4">{{ session('success') }}</div>
@endif

{{-- Default TTL setting --}}
<div class="card mb-4" style="padding:18px 20px;">
    <div style="font-size:13px;font-weight:700;color:#e2e8f0;margin-bottom:12px;">
        <i class="fas fa-clock" style="color:#a78bfa;margin-left:6px;"></i>
        مدة الصلاحية الافتراضية
    </div>
    <form method="POST" action="{{ route('admin.signed-tokens.ttl') }}" class="ttl-form">
        @csrf
        <span style="font-size:13px;color:#94a3b8;">صلاحية الرابط:</span>
        <input type="number" name="ttl" value="{{ $defaultTtl }}" min="5" max="10080"
               class="inp" style="width:110px;text-align:center;">
        <span style="font-size:13px;color:#94a3b8;">دقيقة</span>
        <button type="submit" class="btn-primary" style="padding:7px 16px;font-size:13px;">
            <i class="fas fa-save"></i> حفظ
        </button>
    </form>
    <p style="font-size:11px;color:#334155;margin-top:8px;">
        هذه القيمة تُطبَّق على الفيديوهات التي لا تحمل مدة صلاحية مخصصة · الحد الأدنى 5 دقائق · الحد الأقصى 10080 دقيقة (7 أيام)
    </p>
</div>

{{-- Active tokens --}}
<div class="card" style="overflow:hidden;">
    <div style="padding:14px 18px;border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;justify-content:space-between;">
        <div style="font-size:13px;font-weight:700;color:#e2e8f0;">
            الروابط النشطة
            <span style="background:rgba(124,58,237,.15);color:#a78bfa;border-radius:99px;padding:1px 8px;font-size:11px;margin-right:6px;">
                {{ $tokens->total() }}
            </span>
        </div>
        <span style="font-size:11px;color:#475569;">يعرض الروابط التي لم تنتهِ صلاحيتها ولم تُلغَ</span>
    </div>
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <thead>
            <tr style="border-bottom:1px solid rgba(255,255,255,.06);">
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">الفيديو (slug)</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">التوكن</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">ينتهي في</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">IP</th>
                <th style="padding:10px 16px;text-align:right;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">صدر في</th>
                <th style="padding:10px 16px;text-align:center;color:#475569;font-size:11px;font-weight:700;text-transform:uppercase;">إلغاء</th>
            </tr>
        </thead>
        <tbody>
            @forelse($tokens as $token)
            <tr style="border-bottom:1px solid rgba(255,255,255,.04);">
                <td style="padding:10px 16px;">
                    <a href="{{ route('embed.player', $token->slug) }}" target="_blank"
                       style="color:#7dd3fc;text-decoration:none;font-size:12px;font-family:monospace;">
                        {{ $token->slug }}
                    </a>
                </td>
                <td style="padding:10px 16px;">
                    <span class="token-hash" title="{{ $token->token_hash }}">
                        {{ substr($token->token_hash, 0, 16) }}…
                    </span>
                </td>
                <td style="padding:10px 16px;font-size:12px;color:#94a3b8;">
                    {{ $token->expires_at->diffForHumans() }}
                    <span style="font-size:10px;color:#475569;display:block;">{{ $token->expires_at->format('H:i:s') }}</span>
                </td>
                <td style="padding:10px 16px;font-size:11px;color:#475569;font-family:monospace;">
                    {{ $token->ip ?? '—' }}
                </td>
                <td style="padding:10px 16px;font-size:11px;color:#475569;">
                    {{ $token->created_at->format('Y-m-d H:i') }}
                </td>
                <td style="padding:10px 16px;text-align:center;">
                    <form method="POST" action="{{ route('admin.signed-tokens.revoke', $token) }}"
                          onsubmit="return confirm('إلغاء هذا التوكن؟')">
                        @csrf
                        <button type="submit" class="ibtn" style="background:rgba(239,68,68,.1);color:#f87171;" title="إلغاء الرابط">
                            <i class="fas fa-ban"></i>
                        </button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" style="padding:28px;text-align:center;color:#334155;">لا توجد روابط نشطة حالياً.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

@if($tokens->hasPages())
<div style="margin-top:16px;display:flex;justify-content:center;">{{ $tokens->links() }}</div>
@endif
@endsection
