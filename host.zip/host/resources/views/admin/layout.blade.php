<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'لوحة التحكم') — StreamHost</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root { --sw: 232px; }
        * { box-sizing: border-box; }
        body { background: #080812; font-family: 'Segoe UI', Tahoma, sans-serif; color: #e2e8f0; margin: 0; }

        /* ── Sidebar ── */
        .sidebar {
            width: var(--sw);
            background: #0e0e1d;
            border-left: 1px solid rgba(139,92,246,.1);
            position: fixed; top: 0; right: 0; height: 100vh;
            display: flex; flex-direction: column; z-index: 40;
        }
        .logo-wrap { padding: 18px 14px 14px; border-bottom: 1px solid rgba(255,255,255,.05); }
        .logo-icon {
            width: 34px; height: 34px; flex-shrink: 0;
            background: linear-gradient(135deg,#7c3aed,#a855f7);
            border-radius: 9px;
            display: flex; align-items: center; justify-content: center;
            font-size: 14px; box-shadow: 0 4px 12px rgba(124,58,237,.4);
        }
        .nav-group { padding: 10px 8px 0; }
        .nav-label {
            font-size: 9.5px; text-transform: uppercase; letter-spacing: .09em;
            color: #334155; font-weight: 700; padding: 0 8px; margin-bottom: 4px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 9px;
            padding: 8px 10px; border-radius: 9px; margin-bottom: 2px;
            font-size: 13px; color: #64748b;
            text-decoration: none; transition: all .15s; cursor: pointer;
        }
        .nav-item:hover { background: rgba(139,92,246,.1); color: #c4b5fd; }
        .nav-item.active {
            background: linear-gradient(135deg,rgba(124,58,237,.22),rgba(168,85,247,.12));
            color: #a78bfa;
            border: 1px solid rgba(139,92,246,.18);
        }
        .nav-icon {
            width: 27px; height: 27px; border-radius: 7px; flex-shrink: 0;
            display: flex; align-items: center; justify-content: center; font-size: 12px;
        }
        .nav-item.active .nav-icon { background: rgba(139,92,246,.2); }
        .nav-badge {
            margin-right: auto;
            background: rgba(239,68,68,.18); color: #f87171;
            font-size: 10px; padding: 1px 6px; border-radius: 99px; font-weight: 700;
        }

        /* ── Main ── */
        .main { margin-right: var(--sw); min-height: 100vh; }
        .topbar {
            position: sticky; top: 0; z-index: 30;
            background: rgba(8,8,18,.88); backdrop-filter: blur(14px);
            border-bottom: 1px solid rgba(255,255,255,.055);
            padding: 12px 24px; display: flex; align-items: center; justify-content: space-between;
        }
        .page-body { padding: 22px 24px; }

        /* ── Cards ── */
        .card { background: rgba(255,255,255,.025); border: 1px solid rgba(255,255,255,.065); border-radius: 14px; }
        .card-head { padding: 13px 18px; border-bottom: 1px solid rgba(255,255,255,.055); display: flex; align-items: center; justify-content: space-between; }

        /* ── Alerts ── */
        .alert-ok  { background:rgba(34,197,94,.08); border:1px solid rgba(34,197,94,.2); color:#4ade80; border-radius:10px; padding:10px 14px; font-size:13px; display:flex; align-items:center; gap:8px; }
        .alert-err { background:rgba(239,68,68,.08); border:1px solid rgba(239,68,68,.2); color:#f87171; border-radius:10px; padding:10px 14px; font-size:13px; display:flex; align-items:center; gap:8px; }

        /* ── Status badges ── */
        .b-ready      { background:rgba(34,197,94,.1);  color:#4ade80; border:1px solid rgba(34,197,94,.2); }
        .b-processing { background:rgba(234,179,8,.1);  color:#facc15; border:1px solid rgba(234,179,8,.2); animation:blink 1.4s infinite; }
        .b-failed     { background:rgba(239,68,68,.1);  color:#f87171; border:1px solid rgba(239,68,68,.2); }
        .b-pending    { background:rgba(100,116,139,.1);color:#94a3b8; border:1px solid rgba(100,116,139,.2); animation:blink 2s infinite; }
        .status-badge { font-size:11px; padding:2px 9px; border-radius:99px; font-weight:600; white-space:nowrap; }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:.55} }

        /* ── Form ── */
        .field-label { display:block; font-size:11px; text-transform:uppercase; letter-spacing:.06em; color:#475569; font-weight:700; margin-bottom:6px; }
        .inp {
            width:100%; background:rgba(10,10,22,.9); border:1px solid rgba(255,255,255,.1);
            border-radius:8px; padding:9px 12px; color:#e2e8f0; font-size:13.5px;
            outline:none; transition:border-color .15s;
        }
        .inp:focus { border-color:#7c3aed; }
        .inp::placeholder { color:#334155; }

        /* ── Buttons ── */
        .btn-primary { background:linear-gradient(135deg,#7c3aed,#9333ea); color:#fff; border:none; border-radius:8px; padding:9px 18px; font-size:13.5px; font-weight:600; cursor:pointer; transition:all .15s; display:inline-flex; align-items:center; gap:7px; text-decoration:none; }
        .btn-primary:hover { opacity:.9; transform:translateY(-1px); }
        .btn-sm { padding:6px 12px; font-size:12px; border-radius:7px; }
        .btn-ghost { background:rgba(255,255,255,.05); color:#94a3b8; border:1px solid rgba(255,255,255,.08); border-radius:8px; padding:9px 18px; font-size:13.5px; cursor:pointer; transition:all .15s; display:inline-flex; align-items:center; gap:7px; text-decoration:none; }
        .btn-ghost:hover { background:rgba(255,255,255,.09); color:#e2e8f0; }

        /* ── Icon Btn ── */
        .ibtn { width:29px; height:29px; border-radius:7px; display:flex; align-items:center; justify-content:center; font-size:11px; cursor:pointer; transition:all .15s; border:none; }

        /* ── Scrollbar ── */
        ::-webkit-scrollbar { width:4px; height:4px; }
        ::-webkit-scrollbar-thumb { background:rgba(139,92,246,.25); border-radius:99px; }
    </style>
    @stack('styles')
</head>
<body>

<aside class="sidebar">
    <div class="logo-wrap" style="display:flex;align-items:center;gap:10px;">
        <div class="logo-icon"><i class="fas fa-play"></i></div>
        <div>
            <div style="font-weight:700;font-size:14.5px;color:#e2e8f0;line-height:1.2;">StreamHost</div>
            <div style="font-size:10px;color:#334155;">Video Platform</div>
        </div>
    </div>

    <div style="flex:1;overflow-y:auto;padding-bottom:8px;">
        <div class="nav-group">
            <div class="nav-label">الرئيسية</div>
            <a href="{{ route('admin.dashboard') }}" class="nav-item {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-gauge-high"></i></div>
                لوحة التحكم
            </a>
        </div>
        <div class="nav-group" style="margin-top:6px;">
            <div class="nav-label">المحتوى</div>
            <a href="{{ route('admin.videos.index') }}" class="nav-item {{ request()->routeIs('admin.videos.index') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-film"></i></div>
                إدارة الفيديوهات
                @php $pc = \App\Models\Video::whereIn('status',['processing','pending'])->count(); @endphp
                @if($pc > 0)<span class="nav-badge">{{ $pc }}</span>@endif
            </a>
            <a href="{{ route('admin.videos.create') }}" class="nav-item {{ request()->routeIs('admin.videos.create') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-upload"></i></div>
                رفع فيديو جديد
            </a>
            <a href="{{ route('admin.folders.index') }}" class="nav-item {{ request()->routeIs('admin.folders.*') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-folder-open"></i></div>
                المجلدات
            </a>

            <div class="nav-label" style="margin-top:10px;">الإعلانات</div>
            <a href="{{ route('admin.ads.index') }}" class="nav-item {{ request()->routeIs('admin.ads.*') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-rectangle-ad"></i></div>
                إدارة الإعلانات
            </a>

            @if(session('admin_user_role') === 'admin')
            <div class="nav-label" style="margin-top:10px;">النظام</div>
            <a href="{{ route('admin.users.index') }}" class="nav-item {{ request()->routeIs('admin.users.*') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-users"></i></div>
                إدارة المستخدمين
            </a>
            <a href="{{ route('admin.signed-tokens.index') }}" class="nav-item {{ request()->routeIs('admin.signed-tokens.*') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-key"></i></div>
                الروابط الموقّعة
            </a>
            <a href="{{ route('admin.audit.index') }}" class="nav-item {{ request()->routeIs('admin.audit.*') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-scroll"></i></div>
                سجل التدقيق
            </a>
            <a href="{{ route('admin.settings.index') }}" class="nav-item {{ request()->routeIs('admin.settings.*') ? 'active' : '' }}">
                <div class="nav-icon"><i class="fas fa-gear"></i></div>
                الإعدادات
            </a>
            @endif
        </div>
    </div>

    <div style="padding:8px;border-top:1px solid rgba(255,255,255,.05);">
        <div style="display:flex;align-items:center;gap:9px;padding:8px 10px;margin-bottom:4px;">
            <div style="width:30px;height:30px;background:linear-gradient(135deg,#7c3aed,#ec4899);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0;color:#fff;">
                {{ strtoupper(substr(session('admin_user_name','A'), 0, 1)) }}
            </div>
            <div style="min-width:0;">
                <div style="font-size:12.5px;color:#cbd5e1;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                    {{ session('admin_user_name','Admin') }}
                </div>
                <div style="font-size:10px;color:#475569;">
                    @switch(session('admin_user_role'))
                        @case('admin') مدير النظام @break
                        @case('editor') محرر @break
                        @case('viewer') مشاهد @break
                        @default {{ session('admin_user_role') }}
                    @endswitch
                </div>
            </div>
        </div>
        <a href="{{ route('admin.logout') }}" class="nav-item" style="color:#475569;">
            <div class="nav-icon"><i class="fas fa-arrow-right-from-bracket"></i></div>
            تسجيل الخروج
        </a>
    </div>
</aside>

<div class="main">
    <div class="topbar">
        <div>
            <h1 style="font-size:15.5px;font-weight:700;color:#e2e8f0;margin:0;">@yield('title','لوحة التحكم')</h1>
            <div style="font-size:10.5px;color:#334155;margin-top:1px;">@yield('breadcrumb','StreamHost › لوحة التحكم')</div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;">
            @yield('topbar_actions')
            <span style="font-size:11px;color:#334155;display:flex;align-items:center;gap:5px;">
                <span style="width:7px;height:7px;background:#4ade80;border-radius:50%;box-shadow:0 0 7px #4ade80;display:inline-block;"></span>
                متصل
            </span>
        </div>
    </div>

    <div class="page-body">
        @if(session('success'))
        <div class="alert-ok mb-4"><i class="fas fa-check-circle"></i> {{ session('success') }}</div>
        @endif
        @if(session('error'))
        <div class="alert-err mb-4"><i class="fas fa-triangle-exclamation"></i> {{ session('error') }}</div>
        @endif

        @yield('content')
    </div>
</div>

@stack('scripts')
</body>
</html>
