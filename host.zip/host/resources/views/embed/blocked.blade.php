<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>محظور</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:#000; color:#fff; font-family:'Segoe UI',sans-serif;
               display:flex; align-items:center; justify-content:center; height:100vh; }
        .msg { text-align:center; }
        .msg svg { width:48px; fill:#ef4444; margin-bottom:12px; }
        .msg h2 { font-size:1rem; color:#ef4444; }
        .msg p  { font-size:.8rem; color:#666; margin-top:6px; }
    </style>
</head>
<body>
<div class="msg">
    <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16zm-1-5h2v2h-2zm0-8h2v6h-2z"/></svg>
    <h2>غير مصرح بالتشغيل</h2>
    <p>هذا المشغل مخصص لموقع معين فقط.</p>
</div>
</body>
</html>
